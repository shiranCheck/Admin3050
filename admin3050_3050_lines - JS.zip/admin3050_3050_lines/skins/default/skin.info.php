﻿<?php 
	$skin_name='DEFAULT';
	$skin_description='Default';
	?>