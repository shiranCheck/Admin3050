﻿<?php 
	
	class cShowHandler extends cShowHandlerMain{
		function domain_summarize($_language,$option,$data){
			$Option_tpl['head']=$_language['FORM_NAME'];
			$Option_tpl['val']=$data['domain_name'];
			$Options_tpl.=template($this->Root.'templates/w_sum.tpl',$Option_tpl);
			foreach($this->DataXML['DATA'][0]['GROUPS'][0]['GROUP']as$group_val){
				
				if($group_val['OPTION'][0]!=''){
					foreach($group_val['OPTION']as$option_key=>$option_val){
						
						if(!$this->Wizard->checkformlimit($option_val['ATTRIBUTES']['NAME'])||strtoupper($option_val["ATTRIBUTES"]["DISABLE"])==$_SESSION['ACCOUNT'])continue;
						
						if($option_val['ATTRIBUTES']['VARIABLE']!=''){
							
							if($option_val['ATTRIBUTES']['LABELS']!=''){
								$a_list=explode("|",$_language[$option_val['ATTRIBUTES']['LABELS']]);
								$Option_tpl['head']=$_language[$option_val['ATTRIBUTES']['LABEL']];
								$Option_tpl['val']=$a_list[$data[$option_val['ATTRIBUTES']['NAME']]];
							} else {
								$Option_tpl['head']=$_language[$option_val['ATTRIBUTES']['LABEL']];
								$Option_tpl['val']=$data[$option_val['ATTRIBUTES']['NAME']];
							}

							
							if($option_val['ATTRIBUTES']['TYPE']=='password')$Options_tpl.=template($this->Root.'templates/w_sump.tpl',$Option_tpl); else $Options_tpl.=template($this->Root.'templates/w_sum.tpl',$Option_tpl);
						}

					}

				}

			}

			return$Options_tpl;
		}

	}

	?>