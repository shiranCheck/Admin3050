﻿<?php 
	require_once'inc/include.php';
	class cDataHandler extends cDataHandlerMain{
		function domain_name($data,$page,$_language){
			checkdomainobjects();
			$items=getdomainlist();
			foreach($items as$val){
				
				if($val[DOMAIN]==$data['domain_name']){
					$this->Data['info']=$_language['domain_exist'];
					$this->Data['class']='error_msg';
					$page--;
				}

			}

			return$page;
		}

		
		function domain_save($data,$page,$_language){
			$api=createobject('api');
			checkdomainobjects();
			
			if(!USEAPIEXT)$this->Domain->New($api->UTF8ToIDN($data['domain_name'])); else $this->Domain->New_($api->UTF8ToIDN($data['domain_name']));
			$this->Domain->ApplyTemplate();
			foreach($this->WData['DATA'][0]['GROUPS'][0]['GROUP']as$group_val){
				
				if($group_val['OPTION'][0]!=''){
					foreach($group_val['OPTION']as$option_val){
						
						if($option_val['ATTRIBUTES']['VARIABLE']!='')@$this->set_value($option_val['ATTRIBUTES']['VARIABLE'],$data[$option_val['ATTRIBUTES']['NAME']]);
					}

				}

			}

			$this->Data['info']=sprintf($_language['domain_succes'],'"'.$data['domain_name'].'"');
			$this->Data['class']='info_msg';
			@$this->Domain->Save();
			unset($api);
		}

		
		function set_value($variable,$value){
			switch($variable){
				default:
					$this->Domain->SetProperty($variable,$value);
					break;
		}

	}

	
	function get_value($variable){
		switch($variable){
			default:
				$value=$this->Domain->GetProperty($variable);
				break;
	}

	return$value;
}

}

?>