﻿<?php 
	require_once'inc/include.php';
	require_once'inc/accounts.php';
	class cDataHandler extends cDataHandlerMain{
		function account_name($data,$page,$_language){
			$domain=$data['domain_name'];
			$items=getaccountlist($domain);
			foreach($items as$val){
				
				if($val[SORT]==$data['account_name']){
					$this->Data['info']=$_language['account_exists'];
					$this->Data['class']='error_msg';
					$page--;
				}

			}

			return$page;
		}

		
		function account_save($data,$page,$_language){
			global$alang;
			$dom=createobject("domain");
			$api=createobject("api");
			$dom->Open($api->UTF8ToIDN($data['domain_name']));
			$limit=$dom->GetProperty("d_accountnumber");
			$count=$dom->GetAccountCount();
			
			if($_SESSION['ACCOUNT']=='DOMAINADMIN'&&$count>=$limit&&$limit!=0){
				$this->Data['info']=$alang['TStrings_cmaxexceeded'];
				$this->Data['class']='error_msg';
			} else {
				
				if(!USEAPIEXT)$this->Account->New($data['account_name'].'@'.$data['domain_name']); else $this->Account->New_($data['account_name'].'@'.$api->UTF8ToIDN($data['domain_name']));
				$this->Account->ApplyTemplate();
				foreach($this->WData['DATA'][0]['GROUPS'][0]['GROUP']as$group_val)
				if($group_val['OPTION'][0]!='')foreach($group_val['OPTION']as$option_val)
				if($option_val['ATTRIBUTES']['VARIABLE']!='')$this->set_value($option_val['ATTRIBUTES']['VARIABLE'],$data[$option_val['ATTRIBUTES']['NAME']]);
				
				if($this->Account->Save()){
					$this->Data['info']=sprintf($_language['account_succes'],'"'.$data['account_name'].'@'.$data['domain_name'].'"');
					$this->Data['class']='info_msg';
				} else {
					$errorMsg=getErrorMsg($this->Account);
					
					if(!$errorMsg)$errorMsg=$_language['account_fail'];
					$this->Data['info']=$errorMsg;
					$this->Data['class']='error_msg';
				}

			}

		}

		
		function set_value($variable,$value){
			switch($variable){
				case'u_permissions':
					switch($value){
						case 1:
							
							if($_SESSION['ACCOUNT']=='ADMIN')$this->Account->SetProperty('U_Admin',true);
							break;
						case 2:
							
							if($_SESSION['ACCOUNT']=='DOMAINADMIN')$this->Account->SetProperty('U_DomainAdmin',true);
						}

						break;
					default:
						$this->Account->SetProperty($variable,$value);
						break;
			}

		}

		
		function get_value($variable){
			switch($variable){
				case'u_permissions':
					
					if($this->Account->GetProperty('U_Admin'))$value=1; else
					if($this->Account->GetProperty('U_DomainAdmin'))$value=2; else $value=0;
					break;
				default:
					$value=$this->Account->GetProperty($variable);
					break;
		}

		return$value;
	}

}

?>