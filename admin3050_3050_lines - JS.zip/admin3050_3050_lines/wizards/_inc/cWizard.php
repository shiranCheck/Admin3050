﻿<?php 
	require_once'function.php';
	require_once'cShowHandler.php';
	require_once'cDataHandler.php';
	require_once'inc/clsparsexml.php';
	class cWizard{
		var$WData;
		var$Root;
		var$DataHandler;
		var$ShowHandler;
		var$Name;
		var$Folder;
		var$Steps;
		var$_Language;
		var$Lang_id;
		function cWizard($folder,$wroot,$id){
			require_once($folder.'_inc/cDataHandler.php');
			require_once($folder.'_inc/cShowHandler.php');
			$folder=securepath($folder);
			$wroot=securepath($wroot);
			$this->getuserrights($rights,$limits);
			$this->rights=$rights;
			$this->limits=$limits;
			$this->Id=$id;
			$this->Root="wizards/";
			$this->configPath=$_SESSION["CONFIGPATH"];
			$parser=&new ParseXML;
			$this->WData=$parser->GetXMLTree($folder.'_xml/data.xml');
			$parser=NULL;
			$this->Lang_id=$_COOKIE['LANGID']?$_COOKIE['LANGID']:
			"en";
			
			if(!file_exists($this->Root.'lang/'.strtolower($this->Lang_id).'/lang.xml'))$this->Lang_id="en";
			$this->Folder=$folder;
			$this->Label=$this->get_language();
			$this->Steps=0;
			foreach($this->WData['DATA'][0]['GROUPS'][0]['GROUP']as$val)$this->Steps++;
			$this->Name=$this->_Language[$this->WData['DATA'][0]['ATTRIBUTES']['NAME']];
			$this->DataHandler=new cDataHandler($this->WData,$this);
			$this->ShowHandler=new cShowHandler($wroot,$folder,$this->WData,$this);
		}

		
		function get_language(){
			$parser=&new ParseXML;
			$langXML=$parser->GetXMLTree($this->Root.'lang/'.strtolower($this->Lang_id).'/lang.xml');
			$parser=NULL;
			foreach($langXML['LANGUAGES'][0]['LANGUAGE']as$lang_key=>$lang_val){
				
				if($lang_val['ATTRIBUTES']['ID']==$this->Id){
					$label=$lang_val['ATTRIBUTES']['VALUE'];
					foreach($lang_val['ITEM']as$cl_key=>$cl_val)$this->_Language[$cl_val['ATTRIBUTES']['ID']]=$cl_val['ATTRIBUTES']['VALUE'];
				}

			}

			return$label;
		}

		
		function execute_step($stp,$data){
			$this->DataHandler->handle_page($stp,$data,$this->_Language);
			$handlerdata=$this->DataHandler->show_data();
			$head['head']=$this->_Language['step'].' '.$stp.'/'.$this->Steps;
			$stepinfo['step_info']=parse_info($this->_Language['FORM_STEP'.$stp],$this->Folder);
			$pom=parse_info($this->_Language['FORM_STEP'.$stp.'_INFO'],$this->Folder);
			
			if($pom!='')$stepinfo['step_descr']=$pom;
			$Template_html['options']=$this->ShowHandler->show_page($stp,$this->_Language,$data);
			
			if($Template_html['options']==""&&$stp!=$this->Steps){
				$this->execute_step($stp+1,$data);
				$wizard_step++;
				return;
			}

			$Template_html['name']=$this->Name;
			$Template_html['root']=$this->Root;
			$Template_html['head']=template($this->Root.'templates/w_head.tpl',$head);
			$Template_html['stepinfo']=template($this->Root.'templates/w_stepinfo.tpl',$stepinfo);
			
			if(($handlerdata['class']!='')&&($handlerdata['info']!=''))$info=template($this->Root.'templates/w_info.tpl',$handlerdata);
			
			if($info!='')$Template_html['infomsg']=$info;
			$Template_html['hidden_tags']=$handlerdata['inputs'];
			$handlerdata['inputs'];
			
			if($this->ShowHandler->FirstInputId!='')$Template_html['first_id']=$this->ShowHandler->FirstInputId.'_id';
			
			if($this->ShowHandler->JavaScript!='')$Template_html['javascript']=$this->Root.'javascript/'.$this->ShowHandler->JavaScript;
			$Template_html['wizard_step']=(string)$stp;
			$Template_html['wizard_next_label']=str_replace(">","&gt;",$this->_Language['wizard_next']);
			$Template_html['wizard_previous_label']=str_replace("<","&lt;",$this->_Language['wizard_prev']);
			$Template_html['wizard_cancel_label']=$this->_Language['wizard_cancel'];
			$wizard_previous=true;
			$wizard_cancel=true;
			$Template_html['wizard_next_js']='Next();';
			
			if($stp==($this->Steps)){
				$wizard_previous=true;
				$wizard_cancel=false;
				$Template_html['wizard_next_js']='Cancel();';
				$Template_html['wizard_next_label']=$this->_Language['wizard_finish'];
			}

			
			if($stp==1)$wizard_previous=false;
			
			if($wizard_previous!=true)$Template_html['wizard_prev_off']='1'; else unset($Template_html['wizard_prev_off']);
			
			if($wizard_cancel!=true)$Template_html['wizard_cancel_off']='1'; else unset($Template_html['wizard_cancel_off']);
			echo template($this->Root.'templates/wizard.tpl',$Template_html);
			return$stp;
		}

		
		function getobjectaccounttype($object){
			switch($object){
				case"user":
					return 0;
					case"list":
						return 1;
						case"exec":
							return 2;
							case"notify":
								return 3;
								case"route":
									return 4;
									case"catalog":
										return 5;
										case"listserv":
											return 6;
											case"group":
												return 7;
										}

									}

									
									function parsedomainfile($file,&$rights,&$optionlimits){
										
										if(file_exists($file)){
											$list=file($file);
											
											if(eregi("RIGHTS=(.*)",$list[0],$arr))$rights=strtoupper($arr[1]);
											for($i=0;$i<count($list);$i++){
												
												if(eregi("OPTION=(.*)[:](.*)",$list[$i],$option))$optionlimits[strtolower($option[1])]=$option[2];
											}

										}

									}

									
									function getuserrights(&$rights,&$optionlimits){
										
										if($_SESSION["ACCOUNT"]=='ADMIN')return"*";
										$rights='DEFAULTRIGHTS';
										$optionlimits=array();
										parsedomainfile($_SESSION["CONFIGPATH"]."domain.dat",$rights,$optionlimits);
										parsedomainfile(getfilevarpath($_SESSION["MAILPATH"],$_SESSION["USERPATH"])."domain.dat",$rights,$optionlimits);
									}

									
									function getfilevarpath($filename,$relative){
										
										if(!($filename[1]==":")&&!($filename[0]=="\\")&&!($filename[0]=="/"))return$relative.$filename; else return$filename;
									}

									
									function checkformlimit($name){
										$result=true;
										$name=strtolower($name);
										
										if(@$this->limits)
										if(isset($this->limits[$name]))$result=intval($this->limits[$name]);
										return$result;
									}

								}

								?>