﻿<?php
	
	if(file_exists('inc/include.php')){
		require_once'inc/include.php';
	} else {
		die('XSS Attack?');
	}

	abstract
	class cDataHandlerMain{
		var$COMObject;
		var$Domain;
		var$Account;
		var$Data;
		var$Inputs;
		var$_Language;
		var$WData;
		function cDataHandlerMain($wd,$wizard){
			$this->Wizard=$wizard;
			$api_object=$wd["DATA"][0]["ATTRIBUTES"]["APIOBJECT"];
			switch($api_object){
				case"user":
					case"list":
						case"exec":
							case"notify":
								case"route":
									case"catalog":
										case"listserv":
											case"group":
												$this->Account=createobject("account");
												$this->Account->setProperty("u_type",$this->Wizard->getobjectaccounttype($object));
												$this->Account->ApplyTemplate();
												break;
											case"domain":
												$this->Domain=createobject("domain");
												$this->Domain->ApplyTemplate();
												break;
									}

									$this->COMObject=createobject("api");
									$this->Data='';
									$this->Inputs='';
									$this->WData=$wd;
								}

								
								function store_variables($data,$page,$step_vals){
									foreach($data as$data_key=>$data_val){
										$print_val=true;
										
										if($data_key=='wizard_step')$print_val=false;
										
										if(is_array($step_vals))foreach($step_vals as$s_key=>$s_val)
										if($s_val==$data_key)$print_val=false;
										
										if($print_val)$this->Inputs.='<input type="hidden" name="'.$data_key.'" value="'.$data_val.'" />';
									}

								}

								
								function handle_page(&$page,$data,$_language){
									$_err='';
									foreach($this->WData['DATA'][0]['GROUPS'][0]['GROUP']as$group_val){
										
										if(($group_val['ATTRIBUTES']['STEP']==$page)&&($group_val['OPTION'][0]!=NULL))foreach($group_val['OPTION']as$option_key=>$option_val){
											$stepvals[$option_key]=$option_val['ATTRIBUTES']['NAME'];
										}

										
										if($group_val['ATTRIBUTES']['STEP']==($page-1)){
											foreach($group_val['OPTION']as$option_key=>$option_val){
												
												if($option_val['ATTRIBUTES']['REQUIRED']=='yes'){
													
													if($data[$option_val['ATTRIBUTES']['NAME']]==''){
														$this->Data['info']=$_language['missing_values'];
														$this->Data['class']='error_msg';
														$page--;
														break;
													}

												}

												
												if($option_val['ATTRIBUTES']['COMPARE']!=''){
													
													if($data[$option_val['ATTRIBUTES']['NAME']]!=$data[$option_val['ATTRIBUTES']['COMPARE']]){
														$this->Data['info']=$_language['missing_values'];
														$this->Data['class']='error_msg';
														$page--;
														break;
													}

												}

												
												if($option_val['ATTRIBUTES']['FUNCTION']!=''){
													$page=call_user_method_array($option_val['ATTRIBUTES']['FUNCTION'],$this,array($data,$page,$_language));
												}

											}

										}

										
										if($group_val['ATTRIBUTES']['STEP']==($page)){
											
											if($group_val['ATTRIBUTES']['FUNCTION']!=''){
												call_user_method_array($group_val['ATTRIBUTES']['FUNCTION'],$this,array($data,$page,$_language));
											}

										}

									}

									$this->store_variables($data,$page,$stepvals);
								}

								
								function show_data(){
									$this->Data['inputs']=$this->Inputs;
									return$this->Data;
								}

								abstract
								function set_value($variable,$value);
								abstract
								function get_value($variable);
							}

							?>