﻿<?php 
	require_once'function.php';
	class cShowHandlerMain{
		var$Steps;
		var$Root;
		var$Folder;
		var$DataXML;
		var$Lang;
		var$InputCount;
		var$FirstInputId;
		var$JavaScript;
		function cShowHandlerMain($root,$fold,$data,$wizard){
			$this->Root=$root;
			$this->Folder=$fold;
			$this->DataXML=$data;
			$this->InputCount=0;
			$this->Wizard=$wizard;
		}

		
		function value_function(&$data,$option_val){
			
			if(isset($data[$option_val['ATTRIBUTES']['NAME']]))return$data[$option_val['ATTRIBUTES']['NAME']]; else
			if(substr($option_val['ATTRIBUTES']['VARIABLE'],0,2)=='d_'){
				
				if($value=$this->Wizard->DataHandler->get_value($option_val['ATTRIBUTES']['VARIABLE'])){
					$data[$option_val['ATTRIBUTES']['NAME']]=$value;
					return$value;
				}

			} else
			if(substr($option_val['ATTRIBUTES']['VARIABLE'],0,2)=='u_'){
				
				if($value=$this->Wizard->DataHandler->get_value($option_val['ATTRIBUTES']['VARIABLE'])){
					$data[$option_val['ATTRIBUTES']['NAME']]=$value;
					return$value;
				}

			} else
			if(isset($option_val['ATTRIBUTES']['VALUE']))return$option_val['ATTRIBUTES']['VALUE'];
		}

		
		function GetOptions($step,$data,$_language){
			foreach($this->DataXML['DATA'][0]['GROUPS'][0]['GROUP']as$group_key=>$group_val){
				
				if($group_val['ATTRIBUTES']['STEP']==$step){
					
					if(!checkItemEnable($_SESSION["ACCOUNT"],$group_val['ATTRIBUTES']['DISABLE'])){
						$Options_tpl["option_list"]="Disabled for ".$group_val['ATTRIBUTES']['DISABLE'];
						continue;
					}

					for($it=0;$it<count($group_val['OPTION']);$it++){
						$option_val=$group_val['OPTION'][$it];
						
						if(!checkItemEnable($_SESSION["ACCOUNT"],$option_val['ATTRIBUTES']['DISABLE']))continue;
						
						if(!$this->Wizard->checkformlimit($option_val['ATTRIBUTES']['NAME'])){
							
							if($option_val['ATTRIBUTES']['NAME']!='domain_name')continue;
						}

						unset($Option_tpl);
						unset($temp);
						$js='';
						$dis='';
						$name=$option_val['ATTRIBUTES']['NAME'];
						
						if($option_val['ATTRIBUTES']['REQUIRED']=='yes')$class=' class="input_required"'; else $class=' class="input"';
						
						if($option_val['ATTRIBUTES']['JAVASCRIPT']!=''){
							$this->JavaScript=$option_val['ATTRIBUTES']['JAVASCRIPT'];
							$js=' onchange="'.$option_val['ATTRIBUTES']['JSFUNCTION'].'"';
						}

						
						if($option_val['ATTRIBUTES']['DISABLED']=='yes')$dis=' disabled="disabled"';
						
						if($this->InputCount==0)$this->FirstInputId=$name;
						$this->InputCount++;
						$temp['heading']=parse_info($_language[$option_val['ATTRIBUTES']['LABEL']],$this->Folder);
						$temp['info']=parse_info($_language[$option_val['ATTRIBUTES']['LABEL'].'INFO'],$this->Folder);
						$Option_tpl['name']=$name;
						$Option_tpl['value']=$this->value_function($data,$option_val);
						$Option_tpl['id']=$name.'_id';
						$Option_tpl['more']=$class.$js.$dis;
						switch($option_val['ATTRIBUTES']['TYPE']){
							case'hidden':
								echo"ASDF";
								$temp['option']=template($this->Root.'templates/w_hidden.tpl',$Option_tpl);
								$Options_tpl['option_list'].=template($this->Root.'templates/w_option.tpl',$temp);
								break;
							case'edit':
								$temp['option']=template($this->Root.'templates/w_edit.tpl',$Option_tpl);
								$Options_tpl['option_list'].=template($this->Root.'templates/w_option.tpl',$temp);
								break;
							case'password':
								$temp['option']=template($this->Root.'templates/w_password.tpl',$Option_tpl);
								$Options_tpl['option_list'].=template($this->Root.'templates/w_option.tpl',$temp);
								break;
							case'radio':
								$a_list=explode("|",$_language[$option_val['ATTRIBUTES']['LABELS']]);
								$a_keys=explode("|",$option_val['ATTRIBUTES']['VALUE']);
								$i=0;
								foreach($a_list as$opt_key=>$opt_val){
									$Option_tpl['more']=$js.$dis;
									$Option_tpl['id']=$name.(($i!=0)?$i:
										'').'_id';
										
										if($a_keys[$i]!=''){
											$Option_tpl['value']=$a_keys[$i];
											
											if($a_keys[$i]==$data[$name])$Option_tpl['more'].=' checked="checked"'; else
											if($a_keys[$i]==$option_val['ATTRIBUTES']['SELECTED']&&!isset($data[$name]))$Option_tpl['more'].=' checked="checked"';
										} else {
											$Option_tpl['value']=$$i;
											
											if($i==$data[$name])$Option_tpl['more'].=' checked="checked"'; else
											if($i==$option_val['ATTRIBUTES']['SELECTED']&&!isset($data[$name]))$Option_tpl['more'].=' checked="checked"';
										}

										$Option_tpl['label']=$opt_val;
										$i++;
										$temp['option'].=template($this->Root.'templates/w_radio.tpl',$Option_tpl);
									}

									$Options_tpl['option_list'].=template($this->Root.'templates/w_option.tpl',$temp);
									break;
								case'checkbox':
									$Option_tpl['type']='checkbox';
									
									if($option_val['ATTRIBUTES']['SELECTED']==true||$data[$name]==1)$Option_tpl['more'].=' checked="checked"';
									$temp['option']=template($this->Root.'templates/w_checkbox.tpl',$Option_tpl);
									$Options_tpl['option_list'].=template($this->Root.'templates/w_option.tpl',$temp);
									break;
								case'listbox':
									$Option_tpl['type']='listbox';
									$a_list=explode("|",$_language[$option_val['ATTRIBUTES']['LABELS']]);
									$a_keys=explode("|",$option_val['ATTRIBUTES']['VALUE']);
									$temp['option']='<select name="'.$name.'" id="'.$name.'_id" '.$class.$js.$dis.' >';
									$i=0;
									$value=$Option_tpl['value'];
									foreach($a_list as$opt_key=>$opt_val){
										$Option_tpl['more']=$class.$js.$dis;
										
										if($a_keys[$i]!=''){
											$Option_tpl['value']=$a_keys[$i];
											
											if($data[$name]==$a_keys[$i])$Option_tpl['more'].=' selected'; else
											if($a_keys[$i]==$option_val['ATTRIBUTES']['SELECTED']&&!isset($data[$name]))$Option_tpl['more'].=' selected'; else
											if($value==$a_keys[$i])$Option_tpl['more'].=' selected';
										} else {
											$Option_tpl['value']=$i;
											
											if($data[$name]==$i)$Option_tpl['more'].=' selected'; else
											if(($i+1)==$option_val['ATTRIBUTES']['SELECTED']&&!isset($data[$name]))$Option_tpl['more'].=' selected'; else
											if(($i+1)==$value)$Option_tpl['more'].=' selected';
										}

										$Option_tpl['label']=$opt_val;
										$temp['option'].=template($this->Root.'templates/w_select.tpl',$Option_tpl);
										$i++;
									}

									$temp['option'].='</select>';
									$Options_tpl['option_list'].=template($this->Root.'templates/w_option.tpl',$temp);
									break;
								case'special':
									$tmp['option']=call_user_method_array($option_val['ATTRIBUTES']['SPECIAL'],$this,array($_language,$option_val,$data));
									$Options_tpl['option_list'].=template($this->Root.'templates/w_optionspec.tpl',$tmp);
									break;
								case'info':
									$tmp['info']=$_language[$option_val['ATTRIBUTES']['LABEL']];
									$tmp['class']='info_msg';
									$Options_tpl['option_list'].=template($this->Root.'templates/w_info.tpl',$tmp);
									break;
						}

					}

				}

			}

			return$Options_tpl;
		}

		
		function show_page($step,$_language,$data){
			$Options_tpl=$this->GetOptions($step,$data,$_language);
			
			if($Options_tpl['option_list']!='')$options=template($this->Root.'templates/w_options.tpl',$Options_tpl);
			return$options;
		}

	}

	?>