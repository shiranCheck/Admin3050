﻿<?php
	
	function getframepath($fileid){
		switch($fileid){
			case"services":
				$tpath="services.html";
				break;
	}

	return$tpath;
}

?>