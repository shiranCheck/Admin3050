﻿<?php
	
	class cCertificatesGrid extends cStdGrid{
		public
		function getBuffer(){
			$api=IcewarpAPI::instance('WebAdmin');
			$this->Buffer=$api->ManageConfig('system/certificates/server certificates','list');
		}

		public
		function loadFromBuffer(){
			$buffer=explode(CRLF,$this->Buffer);
			
			if(is_array($buffer)&&!empty($buffer)){
				foreach($buffer as$line){
					
					if($line){
						$this->Data[]=self::parseLine($line);
					}

				}

			}

		}

		public
		function Save(){
			$toSave=$this->Data;
			$this->getBuffer();
			$this->loadFromBuffer();
			$current=$this->Data;
			
			if(is_array($current)&&!empty($current)){
				foreach($current as$key=>$val){
					
					if(isset($val['id'])){
						$existing[$val['id']]=$val;
					}

				}

			}

			
			if(is_array($toSave)&&!empty($toSave)){
				foreach($toSave as$key=>$val){
					
					if(isset($val['id'])){
						
						if(isset($existing[$val['id']])){
							
							if($this->isChanged($existing[$val['id']],$val)){
								$edit[$val['id']]=$val;
							}

							unset($existing[$val['id']]);
						} else {
							$add[$val['id']]=$val;
						}

					} else {
						$add[$val['id']]=$val;
					}

				}

			}

			
			if(is_array($edit)&&!empty($edit)){
				foreach($edit as$key=>$val){
					$this->editItem($key,$val);
				}

			}

			
			if(is_array($existing)&&!empty($existing)){
				foreach($existing as$key=>$val){
					$this->deleteItem($key);
				}

			}

			
			if(is_array($add)&&!empty($add)){
				foreach($add as$key=>$val){
					$this->addItem($val);
				}

			}

		}

		public
		function addItem($item){
			$item=$this->createLine($item);
			$api=IcewarpAPI::instance('WebAdmin');
			$this->Buffer=$api->ManageConfig('system/certificates/server certificates','add',$item);
		}

		public
		function editItem($id,$item){
			$item=$this->createLine($item);
			$api=IcewarpAPI::instance('WebAdmin');
			$this->Buffer=$api->ManageConfig('system/certificates/server certificates','edit',$item);
		}

		public
		function deleteItem($id){
			$item=$this->createLine(array('id'=>$id));
			$api=IcewarpAPI::instance('WebAdmin');
			$this->Buffer=$api->ManageConfig('system/certificates/server certificates','delete',$item);
		}

		public
		function isChanged($old,$new){
			
			if($old['cert']!=$new['cert']){
				return true;
			} else {
				return false;
			}

		}

		public
		function parseLine($line){
			$variables=explode('&',$line);
			
			if(is_array($variables)&&!empty($variables)){
				foreach($variables as$varpart){
					$data=explode('=',$varpart);
					
					if($data[0]){
						$result[rawurldecode($data[0])]=rawurldecode($data[1]);
					}

				}

			}

			return$result;
		}

		public
		function createLine($line){
			$result='';
			
			if(is_array($line)&&!empty($line)){
				foreach($line as$key=>$val){
					$result.='&'.rawurlencode($key).'='.rawurlencode($val);
				}

			}

			return$result;
		}

	}

	?>