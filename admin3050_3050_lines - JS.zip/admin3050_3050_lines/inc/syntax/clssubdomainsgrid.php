﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	require_once"inc/syntax/clsitem.php";
	require_once"inc/include.php";
	class cSubdomainsGrid extends cStdGrid{
		function cSubdomainsGrid($option,$name){
			@$item=$option["SYNTAX"][0]["OBJECT"][0];
			@$length=$item["ATTRIBUTES"]["LENGTH"];
			@$seps=$item["SEPS"][0]["VALUE"];
			@$this->showFunction=$item["ATTRIBUTES"]["SHOW"];
			
			if(!$this->showFunction)$this->showFunction=false;
			$this->Item=new cStdItem($length,$seps);
			$filename=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"];
			$commentfile=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["COMMENT"];
			
			if($commentfile){
				$this->commentFile=$commentfile;
			}

			
			if(strpos($filename,'config/')!==false){
				$filename=str_replace('config/',$_SESSION['CONFIGPATH'],$filename);
			} else
			if(strpos($filename,'spam/')!==false){
				$filename=str_replace('spam/',$_SESSION['SPAMPATH'],$filename);
			} else {
				$filename=$_SESSION['INSTALLPATH'].$filename;
			}

			$this->Filename=$filename;
			@$this->Name=$option["ATTRIBUTES"]["NAME"];
			
			if($option['DEFAULT'][0]['ITEM']){
				foreach($option['DEFAULT'][0]['ITEM']as$key=>$val){
					$this->DefaultData[$key][$val['FIELD'][0]['ATTRIBUTES']['INDEX']]=$val['FIELD'][0]['VALUE'];
				}

			}

		}

		
		function loadFromBuffer(){
			global$formapi;
			
			if($this->Buffer){
				$ic=0;
				$lines=explode(CRLF,$this->Buffer);
				for($i=0;$i<count($lines);$i++){
					$item=array();
					
					if($lines[$i]=="")continue;
					
					if($this->Item->Length==1)$item[0]=$lines[$i]; else {
						$pom=$lines[$i];
						for($j=0;$j<$this->Item->Length-1;$j++){
							$pom=explode($this->Item->Seps[$j],$pom,2);
							$item[$j]=$pom[0];
							$pom=$pom[1];
						}

						$item[$j]=$pom;
					}

					$items[$ic++]=$item;
				}

				$this->Data=$items;
			} else {
				$this->Data=$this->DefaultData;
			}

			$api=createobject('api');
			$this->Domain=$formapi->Name;
			
			if(is_array($this->Data)&&!empty($this->Data))foreach($this->Data as$nr=>$item){
				
				if($item[1]!=$this->Domain){
					$this->otherData[]=$item;
					unset($this->Data[$nr]);
				} else {
					$this->Data[$nr][0]=$api->IDNToUTF8($item[0]);
				}

			}

			@$this->Data=array_values($this->Data);
		}

		
		function saveToBuffer(){
			global$formapi;
			$api=createobject('api');
			$buffer="";
			
			if($this->Data)foreach($this->Data as$i=>$val){
				
				if($this->Item->Length==1)$buffer.=$this->Data[$i][0].CRLF; else {
					$this->Data[$i][0]=$api->UTF8ToIDN($this->Data[$i][0]);
					$this->Data[$i][1]=$this->Domain;
					for($j=0;$j<$this->Item->Length-1;$j++){
						$buffer.=$this->Data[$i][$j].$this->Item->Seps[$j];
					}

					$buffer.=$this->Data[$i][$j].CRLF;
				}

			}

			
			if($this->otherData)foreach($this->otherData as$i=>$val){
				
				if($this->Item->Length==1)$buffer.=$this->otherData[$i][0].CRLF; else {
					for($j=0;$j<$this->Item->Length-1;$j++){
						$buffer.=$this->otherData[$i][$j].$this->Item->Seps[$j];
					}

					$buffer.=$this->otherData[$i][$j].CRLF;
				}

			}

			$this->Buffer=$buffer;
			return$buffer;
		}

		
		function loadFromSession(){
			$this->Domain=$_SESSION["griddata"]["grids"][$this->uid][$this->Name.'_domain'];
			$this->Data=$_SESSION["griddata"]["grids"][$this->uid][$this->Name];
			$this->otherData=$_SESSION["griddata"]["grids"][$this->uid][$this->Name.'_other'];
		}

		
		function saveToSession(){
			$_SESSION["griddata"]["grids"][$this->uid][$this->Name.'_domain']=$this->Domain;
			$_SESSION["griddata"]["grids"][$this->uid][$this->Name]=$this->Data;
			$_SESSION["griddata"]["grids"][$this->uid][$this->Name.'_other']=$this->otherData;
		}

	}

	?>