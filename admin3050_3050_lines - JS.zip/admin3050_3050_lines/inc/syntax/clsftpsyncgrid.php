﻿<?php 
	require_once"inc/syntax/clswebservicegrid.php";
	class cFTPSyncGrid extends cWebserviceGrid{
		function cFTPSyncGrid($option){
			$this->Name="ftpsync";
			$this->Filename=$_SESSION["INSTALLPATH"].$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"];
		}

		
		function LoadFromXML(){
			
			if(file_exists($this->Filename)){
				$parser=new ParseXML();
				$this->xml=$parser->GetXMLTree($this->Filename);
				$items=$this->xml["FTP"][0]["SYNC"][0]["ITEM"];
				unset($parser);
			}

			
			if($items)foreach($items as$index=>$host)
			if($host)foreach($host as$var=>$value)
			if($var!="OPTIONS"&&$var!="SCHEDULE"&&$var!="DESTINATION"&&$var!="SOURCE"&&$var!="VALUE")$return[strtolower($index)][strtolower($var)]=$this->xml2arr($value,$var); else
			if($var!="VALUE"){
				$pom=$this->xml2arr($value,$var);
				
				if($pom)foreach($pom as$pomkey=>$pomval)$return[strtolower($index)][$pomkey]=$pomval;
			}

			$this->Data=$return;
		}

		
		function saveToXML(){
			
			if($this->Data[0])foreach($this->Data as$index=>$host)foreach($host as$var=>$value){
				
				if(strpos($var,'schedule_')!==false)$return[$index]['SCHEDULE'][0]['ATTRIBUTES'][strtoupper(str_replace('schedule_','',$var))]=strtoupper(str_replace('schedule_','',$var))!='AT'?intval($value):
				$value; else
				if(strpos($var,'source_')!==false){
					$return[$index]['SOURCE'][0]['ATTRIBUTES'][strtoupper(str_replace('source_','',$var))]=(strtoupper(str_replace('source_','',$var))=='RECURSIVE'||strtoupper(str_replace('source_','',$var))=='CLONE')?intval($value):
					$value;
				} else
				if(strpos($var,'destination_')!==false){
					$return[$index]['DESTINATION'][0]['ATTRIBUTES'][strtoupper(str_replace('destination_','',$var))]=$value;
				} else
				if(!($var=='value'&&!isset($value[0]["VALUE"])))$return[$index][strtoupper($var)]=$this->arr2xml($value,strtolower($var));
			}

			return$return;
		}

		
		function Save(){
			$arr=$this->SaveToXML();
			$parser=new ParseXML();
			
			if(file_exists($this->Filename))$this->xml=$parser->GetXMLTree($this->Filename);
			$this->xml["FTP"]=self::htmlspecialchars_array($this->xml["FTP"]);
			$this->xml["FTP"][0]["SYNC"][0]["ITEM"]=$arr;
			$parser=new ParseXML();
			$xmlstr=$parser->Array2XML($this->xml,true);
			
			if($xmlstr!=""){
				$fp=@fopen($this->Filename,'w');
				fwrite($fp,trim($xmlstr));
				@fclose($fp);
			} else @unlink($this->Filename);
		}

		static public
		function htmlspecialchars_array($array){
			
			if($array){
				foreach($array as$key=>$val){
					
					if(is_array($val)){
						$return[$key]=self::htmlspecialchars_array($val);
					} else {
						$return[$key]=htmlspecialchars($val);
					}

				}

			} else {
				return$value;
			}

			return$return;
		}

		
		function xml2arr($item,$key){
			switch(strtolower($key)){
				case'attributes':
					$return=$item["ATTRRIBUTES"];
					break;
				case'permissions':
					case'ipaccess':
						case'alias':
							
							if(isset($item[0]["ITEM"])){
								foreach($item[0]["ITEM"]as$k=>$v)
								if(is_array($v["ATTRIBUTES"]))foreach($v["ATTRIBUTES"]as$k2=>$v2)$return[$k][strtolower($k2)]=$v2;
							}

							break;
						case'groups':
							case'access':
								case'sync':
									
									if(isset($item[0]["ITEM"]))foreach($item[0]["ITEM"]as$ik=>$iv){
										foreach($iv as$k=>$v){
											
											if($k!="OPTIONS"&&$k!="SCHEDULE"&&$k!="SOURCE"&&$k!="DESTINATION"&&$k!="VALUE")$return[strtolower($ik)][strtolower($k)]=$this->xml2arr($v,$k); else
											if($k!="VALUE"){
												$pom=$this->xml2arr($v,$k);
												$return[strtolower($ik)]=@array_merge($pom,$return[strtolower($ik)]);
											}

										}

									}

									break;
								case'destination':
									case'source':
										case'schedule':
											
											if($item[0]["ATTRIBUTES"])foreach($item[0]["ATTRIBUTES"]as$ok=>$ov)$return[strtolower($key)."_".strtolower($ok)]=$ov;
											break;
										default:
											
											if(is_array($item)&&trim($item[0]["VALUE"])!="")$return=$item[0]["VALUE"];
											break;
								}

								return$return;
							}

							
							function arr2xml($value,$key){
								$option_list=array(0=>"downloadspeedlimit","uploadspeedlimit","downloadamountlimit","uploadamountlimit","uploaddownloadratio");
								switch(strtolower($key)){
									case"attributes":
										foreach($value as$k=>$v)$return[0]["ATTRRIBUTES"][strtoupper($k)]=htmlspecialchars($v);
										break;
									case'ipaccess':
										case'alias':
											
											if(is_array($value))foreach($value as$k=>$v)foreach($v as$k2=>$v2)$return[0]['ITEM'][$k]['ATTRIBUTES'][$k2]=htmlspecialchars($v2);
											break;
										case'sync':
											
											if(is_array($value))foreach($value as$k=>$v){
												foreach($v as$k2=>$v2){
													
													if(substr_count($k2,"schedule")>0){
														$return[0]["ITEM"][$k]['SCHEDULE'][0]["ATTRIBUTES"][str_replace("schedule_","",$k2)]=htmlspecialchars($v2);
													} else
													if(substr_count($k2,"source")>0){
														$return[0]["ITEM"][$k]['SOURCE'][0]["ATTRIBUTES"][str_replace("source_","",$k2)]=htmlspecialchars($v2);
													} else
													if(substr_count($k2,"destination")>0)$return[0]["ITEM"][$k]['DESTINATION'][0]["ATTRIBUTES"][str_replace("source_","",$k2)]=htmlspecialchars($v2);
												}

											}

											break;
										case'groups':
											case'access':
												
												if(is_array($value))foreach($value as$k=>$v){
													foreach($v as$k2=>$v2){
														
														if(in_array($k2,$option_list))$options[0][strtoupper($k2)][0]["VALUE"]=htmlspecialchars($v2); else $return[0]["ITEM"][$k][strtoupper($k2)]=$this->arr2xml($v2,strtoupper($k2));
														
														if(count($options[0])==5)$return[0]["ITEM"][$k]["OPTIONS"]=htmlspecialchars($options);
													}

												}

												break;
											case'ip':
												$ips=explode(";",$value);
												unset($ips[count($ips)-1]);
												foreach($ips as$key=>$ip)$return[0]['ITEM'][$key]['VALUE']=htmlspecialchars($ip);
												break;
											case'permissions':
												
												if($value)foreach($value as$k=>$v)foreach($v as$k2=>$v2)$return[0]["ITEM"][$k]["ATTRIBUTES"][strtoupper($k2)]=htmlspecialchars($v2);
												break;
											default:
												$return[0]['VALUE']=htmlspecialchars($value);
												break;
									}

									return$return;
								}

							}

							?>