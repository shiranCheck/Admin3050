﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	class cSharedFolderGrid extends cStdGrid{
		function cSharedFolderGrid($option,$name){
			global$api;
			@$item=$option["SYNTAX"][0]["OBJECT"][0];
			@$length=$item["ATTRIBUTES"]["LENGTH"];
			@$seps=$item["SEPS"][0]["VALUE"];
			$this->Name=$name;
			$this->Option=$option;
			$this->Item=new cStdItem($length,$seps);
			$this->Filename=$_SESSION["INSTALLPATH"].securepath($option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"]);
		}

		
		function loadFromBuffer(){
			
			if($this->Buffer){
				$ic=0;
				$lines=explode(CRLF,$this->Buffer);
				for($i=0;$i<count($lines);$i++){
					$item=array();
					
					if($lines[$i]=="")continue;
					
					if(preg_match("/([a-z0-9\.\+_@-]{0,})\/?([^;]{0,})?;([^;]{0,})/i",$lines[$i],$regs2)){
						$item[0]=$regs2[1];
						$item[2]=mb_convert_encoding($regs2[3],'UTF-8','UTF7-IMAP');
						$item[1]=iconv("","UTF-8",$regs2[2]);
						$item[3]=$regs2[4];
					} else {
						eregi("(.*);(.*);(.*)",$lines[$i],$regs);
						$item[2]=mb_convert_encoding($regs[2],'UTF-8','UTF7-IMAP');
						$item[0]=$regs[1];
						$item[3]=$regs[3];
					}

					$items[$ic++]=$item;
				}

				$this->Data=$items;
			}

		}

		
		function saveToBuffer(){
			$buffer="";
			
			if($this->Data)foreach($this->Data as$i=>$val){
				
				if(count($this->Data[$i])==3)$buffer.=$val[0].";".mb_convert_encoding($val[2],'UTF7-IMAP','UTF-8').";".$val[3].CRLF; else $buffer.=$val[0]."\\".iconv("UTF-8","",$val[1]).";".mb_convert_encoding($val[2],'UTF7-IMAP','UTF-8').";".$val[3].CRLF;
			}

			$this->Buffer=$buffer;
			return$buffer;
		}

	}

	?>