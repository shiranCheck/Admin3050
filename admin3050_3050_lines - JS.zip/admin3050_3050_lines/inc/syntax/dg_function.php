﻿<?php
	
	function processdatagrid($object,$value,&$gObj_out,&$skindata_out){
		global$loc,$pname,$pitem,$sGridItem;
		@$location=$_REQUEST['location'];
		
		if(@!$_REQUEST['location'])$sep=""; else $sep="|";
		
		if(!$editform)$loc=$location.$sep.@$_REQUEST['pname'].'-'.@$_REQUEST['pitem'].'-'.$REQUEST['puid']; else $loc=@$_REQUEST['loc'];
		$pname=$_REQUEST['pname'];
		$pitem=$_REQUEST['pitem'];
		$puid=$_REQUEST['puid'];
		
		if($object=="datagrid"){
			$gObj=&new cGridHandler(true,$pitem,$pname,$puid,$loc);
			$gObj->Dialogname='dialog/'.$value;
		} else $gObj=&new cGridHandler(false,$pitem,$pname,$puid,$loc);
		$gObj->ProcessGridButtons(@$_REQUEST['menulink'],@$_REQUEST['gridval'],@$_REQUEST['gridaction'],$object);
		
		if($object=="datagrid"||$object=="schedule"){
			$skindata['datagrid']=1;
			$skindata['pname']=$pname;
			$skindata['pitem']=$pitem;
			$skindata['puid']=$puid;
			$skindata['loc']=$loc;
			$skindata['location']=$location;
			$skindata["title"]=$alang["TConfigForm"].": ".$value;
			@$skindata['subgrid']=$subgrid;
			
			if($object=="schedule"){
				@$skindata['cfileid']=$_REQUEST['cfileid'];
				@$skindata['fileid']=$_REQUEST['fileid'];
			}

		}

		$gObj_out=$gObj;
		$skindata_out=$skindata;
	}

	?>