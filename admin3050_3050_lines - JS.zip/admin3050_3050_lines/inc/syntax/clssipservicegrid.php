﻿<?php 
	require_once"inc/syntax/clswebservicegrid.php";
	class cSIPRulesGrid extends cWebserviceGrid{
		function cSIPRulesGrid($option){
			$this->Name="sip_service";
			$this->Filename=$_SESSION["CONFIGPATH"].$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"];
		}

		
		function LoadFromXML(){
			
			if(file_exists($this->Filename)){
				$parser=new ParseXML();
				$xml=$parser->GetXMLTree($this->Filename);
				$items=$xml["RULES"][0]["RULE"];
				unset($parser);
			}

			
			if($items)foreach($items as$index=>$host)
			if($host)foreach($host as$var=>$value)
			if(strtolower($var)=="action")$return[$index]=array_merge($return[$index],$this->xml2arr($value,$var)); else $return[$index][strtolower($var)]=$this->xml2arr($value,$var);
			$this->Data=$return;
		}

		
		function saveToXML(){
			foreach($this->Data as$index=>$host)foreach($host as$var=>$value){
				
				if(!($var=='value'&&!isset($value[0]["VALUE"])))$return[$index][strtoupper($var)]=$this->arr2xml($value,strtolower($var));
			}

			return$return;
		}

		
		function Save(){
			$arr=$this->SaveToXML();
			$parser=new ParseXML();
			
			if(file_exists($this->Filename))$this->xml=$parser->GetXMLTree($this->Filename);
			$this->xml["RULES"]=self::htmlspecialchars_array($this->xml["RULES"]);
			$this->xml["RULES"][0]["RULE"]=$arr;
			$xmlstr=$parser->Array2XML($this->xml,true);
			
			if($xmlstr!=""){
				$fp=@fopen($this->Filename,'w');
				fwrite($fp,trim($xmlstr));
				@fclose($fp);
			} else @unlink($this->Filename);
		}

		
		function xml2arr($item,$key){
			switch(strtolower($key)){
				case"action":
					foreach($item[0]as$k=>$v)$return[strtolower($k)]=$v[0]["VALUE"];
					break;
				case'value':
					default:
						
						if(is_array($item)&&trim($item[0]["VALUE"])!="")$return=$item[0]["VALUE"];
						break;
			}

			return$return;
		}

		
		function arr2xml($value,$key){
			$option_list=array(0=>"downloadspeedlimit","uploadspeedlimit","downloadamountlimit","uploadamountlimit","uploaddownloadratio");
			switch(strtolower($key)){
				case"attributes":
					foreach($value as$k=>$v)$return[0]["ATTRRIBUTES"][strtoupper($k)]=$v;
					break;
				case'ipaccess':
					case'alias':
						
						if(is_array($value))foreach($value as$k=>$v)foreach($v as$k2=>$v2)$return[0]['ITEM'][$k]['ATTRIBUTES'][$k2]=$v2;
						break;
					case'sync':
						
						if(is_array($value))foreach($value as$k=>$v){
							foreach($v as$k2=>$v2){
								
								if(substr_count($k2,"schedule")>0){
									$return[0]["ITEM"][$k]['SCHEDULE'][0]["ATTRIBUTES"][str_replace("schedule_","",$k2)]=$v2;
								} else
								if(substr_count($k2,"source")>0){
									$return[0]["ITEM"][$k]['SOURCE'][0]["ATTRIBUTES"][str_replace("source_","",$k2)]=$v2;
								} else $return[0]["ITEM"][$k]['DESTINATION'][0]["ATTRIBUTES"]["DIRECTORY"]=$v2;
							}

						}

						break;
					case'groups':
						case'access':
							
							if(is_array($value))foreach($value as$k=>$v){
								foreach($v as$k2=>$v2){
									
									if(in_array($k2,$option_list))$options[0][strtoupper($k2)][0]["VALUE"]=$v2; else $return[0]["ITEM"][$k][strtoupper($k2)]=$this->arr2xml($v2,strtoupper($k2));
									
									if(count($options[0])==5)$return[0]["ITEM"][$k]["OPTIONS"]=$options;
								}

							}

							break;
						case'destination':
							$return[0]["ATTRIBUTES"]["DIRECTORY"]=$value;
							break;
						case'ip':
							$ips=explode(";",$value);
							unset($ips[count($ips)-1]);
							foreach($ips as$key=>$ip)$return[0]['ITEM'][$key]['VALUE']=$ip;
							break;
						case'permissions':
							
							if($value)foreach($value as$k=>$v)foreach($v as$k2=>$v2)$return[0]["ITEM"][$k]["ATTRIBUTES"][strtoupper($k2)]=$v2;
							break;
						default:
							$return[0]['VALUE']=$value;
							break;
				}

				return$return;
			}

			
			function getObjectJS($selector,$vindex,$aFunction=false,$option){
				global$skin_dir,$sGridItem;
				$arr["dname"]=$this->Name;
				@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
				@$dialog=$files["DIALOG"];
				@$file=$files["NAME"];
				@$comment=$files["COMMENT"];
				@$width=$option["ATTRIBUTES"]["WIDTH"];
				
				if(@!$width)$width=640;
				@$height=$option["ATTRIBUTES"]["HEIGHT"];
				
				if(@!$height)$height=480;
				
				if($this->Data)foreach($this->Data as$key2=>$val2){
					foreach($vindex as$key3=>$val3){
						$val=strtolower($val3);
						$item=eregi_replace("([\\\'\"])","\\\\1",$val2[$val3]);
						$arr["items"]["num"][$key2]['item']["num"][$key3]['value']=str_replace(CRLF,";",$item);
						$arr["items"]["num"][$key2]['item']["num"][$key3]['label']='<a href="javascript:processdatagrid(\\\'edit\\\',\\\''.$dialog.'\\\',\\\''.$this->Name.'\\\',\\\'\\\','.$width.','.$height.',\\\'\\\',\\\''.$this->count.'\\\',0,\\\''.$key2.'\\\',\\\''.$this->uid.'\\\');">'.$arr["items"]["num"][$key2]['item']["num"][$key3]['value'].'</a>';
						$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=$arr["items"]["num"][$key2]['item']["num"][$key3]['value'];
					}

					$arr["items"]["num"][$key2]["cislo"]=$key2;
					
					if($this->Name.$key2==$sGridItem)$arr["items"]["num"][$key2]["selected"]=1;
				}

				$arr["selector"]=$selector;
				return template($skin_dir."dgridjs2.tpl",$arr);
			}

			static public
			function htmlspecialchars_array($array){
				
				if($array){
					foreach($array as$key=>$val){
						
						if(is_array($val)){
							$return[$key]=self::htmlspecialchars_array($val);
						} else {
							$return[$key]=htmlspecialchars($val);
						}

					}

				} else {
					return$value;
				}

				return$return;
			}

		}

		?>