﻿<?php
	require_once"inc/syntax/clsitem.php";
	require_once"inc/include.php";
	class cStdGrid{
		var$Item;
		var$Data;
		var$Itemlength;
		var$Name;
		var$Filename;
		var$Buffer;
		function cStdGrid($option){
			@$item=$option["SYNTAX"][0]["OBJECT"][0];
			@$length=$item["ATTRIBUTES"]["LENGTH"];
			@$seps=$item["SEPS"][0]["VALUE"];
			@$this->showFunction=$item["ATTRIBUTES"]["SHOW"];
			
			if(!$this->showFunction)$this->showFunction=false;
			$this->Item=new cStdItem($length,$seps);
			$filename=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"];
			$commentfile=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["COMMENT"];
			
			if($commentfile){
				$this->commentFile=$commentfile;
			}

			
			if(strpos($filename,'config/')!==false){
				$filename=str_replace('config/',$_SESSION['CONFIGPATH'],$filename);
			} else
			if(strpos($filename,'spam/')!==false){
				$filename=str_replace('spam/',$_SESSION['SPAMPATH'],$filename);
			} else {
				$filename=$_SESSION['INSTALLPATH'].$filename;
			}

			$this->Filename=$filename;
			@$this->Name=$option["ATTRIBUTES"]["NAME"];
			
			if($option['DEFAULT'][0]['ITEM']){
				foreach($option['DEFAULT'][0]['ITEM']as$key=>$val){
					$this->DefaultData[$key][$val['FIELD'][0]['ATTRIBUTES']['INDEX']]=$val['FIELD'][0]['VALUE'];
				}

			}

		}

		
		function getBuffer(){
			$fp=@fopen($this->Filename,'r+');
			$this->Buffer=@fread($fp,filesize($this->Filename));
			@fclose($fp);
		}

		
		function loadFromSession(){
			$this->Data=$_SESSION["griddata"]["grids"][$this->uid][$this->Name];
		}

		
		function saveToSession(){
			$_SESSION["griddata"]["grids"][$this->uid][$this->Name]=$this->Data;
		}

		
		function loadFromBuffer(){
			
			if($this->Buffer){
				$ic=0;
				$lines=explode(CRLF,$this->Buffer);
				for($i=0;$i<count($lines);$i++){
					$item=array();
					
					if($lines[$i]=="")continue;
					
					if($this->Item->Length==1)$item[0]=$lines[$i]; else {
						$pom=$lines[$i];
						for($j=0;$j<$this->Item->Length-1;$j++){
							$pom=explode($this->Item->Seps[$j],$pom,2);
							$item[$j]=$pom[0];
							$pom=$pom[1];
						}

						$item[$j]=$pom;
					}

					$items[$ic++]=$item;
				}

				$this->Data=$items;
			} else {
				$this->Data=$this->DefaultData;
			}

		}

		
		function Load($gObj,$array){
			
			if(!$array)$this->GetBuffer(@$gObj->Buffer);
			$this->loadFromBuffer();
			
			if(!$array)$this->SaveToSession($gObj);
		}

		
		function Save(){
			$return=$this->saveToBuffer();
			
			if($return!=""){
				$fp=fopen($this->Filename,"w");
				fwrite($fp,$return,strlen($return));
				fclose($fp);
			} else @unlink($this->Filename);
		}

		
		function saveToBuffer(){
			$buffer="";
			
			if($this->Data)foreach($this->Data as$i=>$val){
				
				if($this->Item->Length==1)$buffer.=$this->Data[$i][0].CRLF; else {
					for($j=0;$j<$this->Item->Length-1;$j++){
						$buffer.=$this->Data[$i][$j].$this->Item->Seps[$j];
					}

					$buffer.=$this->Data[$i][$j].CRLF;
				}

			}

			$this->Buffer=$buffer;
			return$buffer;
		}

		
		function getObjectJS($selector,$vindex,$function=false,$option){
			global$skin_dir,$sGridItem;
			$arr["dname"]=$this->Name;
			@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
			@$dialog=$files["DIALOG"];
			@$file=$files["NAME"];
			@$comment=$files["COMMENT"];
			@$width=$option["ATTRIBUTES"]["WIDTH"];
			
			if(@!$width)$width=640;
			@$height=$option["ATTRIBUTES"]["HEIGHT"];
			
			if(@!$height)$height=480;
			
			if(is_array($this->Data)&&!empty($this->Data))foreach($this->Data as$key2=>$val2){
				foreach($vindex as$key3=>$val3){
					$item=eregi_replace("([\\\'\"])","\\\\1",$val2[strtolower($val3)]);
					
					if($this->showFunction){
						$func=$this->showFunction;
						$arr["items"]["num"][$key2]['item']["num"][$key3]['value']=$func($item);
					} else $arr["items"]["num"][$key2]['item']["num"][$key3]['value']=str_replace(CRLF,";",$item);
					
					if($function[$val3]){
						$function[$val3]['option']['ATTRIBUTES']['COUNT']=$key3;
						formfunctionvalues($function[$val3]['function'],$arr["items"]["num"][$key2]['item']["num"][$key3]['value'],true,$function[$val3]['option']['ATTRIBUTES']['VINDEX'],$error,$function[$val3]['option']);
					}

					
					if($this->noLink){
						$arr["items"]["num"][$key2]['item']["num"][$key3]['label']=$arr["items"]["num"][$key2]['item']["num"][$key3]['value'];
						$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=$arr["items"]["num"][$key2]['item']["num"][$key3]['value'];
					} else {
						$arr["items"]["num"][$key2]['item']["num"][$key3]["label"]='<a href="javascript:processdatagrid(\\\'edit\\\',\\\''.$dialog.'\\\',\\\''.$this->Name.'\\\',\\\'\\\','.$width.','.$height.',\\\'\\\',\\\''.$this->count.'\\\',0,\\\''.$key2.'\\\',\\\''.$this->uid.'\\\');">'.$arr["items"]["num"][$key2]['item']["num"][$key3]['value'].'</a>';
						$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=$arr["items"]["num"][$key2]['item']["num"][$key3]['value'];
					}

				}

				$arr["items"]["num"][$key2]["cislo"]=$key2;
				
				if($this->Name.$key2==$sGridItem)$arr["items"]["num"][$key2]["selected"]=1;
			}

			$arr["selector"]=$selector;
			return template($skin_dir."dgridjs2.tpl",$arr);
		}

		
		function getGridHead($option,$formid,$dgcount,&$selector){
			global$alang;
			$selector=0;
			$name=$option["ATTRIBUTES"]["NAME"];
			
			if($option["HEAD"][0]["SELECTOR"][0]){
				$selector=1;
				$item["size"]="-20";
				$item["sort"]="0";
				$item["dynam"]="0";
				$item["sortdir"]="0";
				$item["defaultsort"]="1";
				
				if($option["HEAD"][0]["SELECTOR"][0]["ATTRIBUTES"]["NOCHECKALL"]==1)$item["label"]=" "; else $item["label"]="<input type=checkbox name=checkall onclick=\"CheckAllout(\'".$name."\', this);\" />";
				$items[]=$item;
			}

			$labels=$option["ATTRIBUTES"]["LABELS"];
			
			if(substr_count($alang[$labels],"|")>0)$label=explode("|",$alang[$labels]); else $label[0]=$alang[$labels];
			
			if($option["HEAD"][0]["OPTION"][0])foreach($option["HEAD"][0]["OPTION"]as$key=>$val){
				$item["label"]=$label[$key];
				foreach($val["ATTRIBUTES"]as$ikey=>$ival){
					$item[strtolower($ikey)]=$ival;
					
					if(strtolower($ikey)=='label')$item[strtolower($ikey)]=$alang[$ival];
				}

				$items[]=$item;
			}

			return$items;
		}

		
		function getGridBody($option,$selector){
			@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
			@$sfile=$files["SYNTAX"];
			@$file=$files["NAME"];
			@$dialog=$files["DIALOG"];
			$vindex='';
			foreach($option["HEAD"][0]["OPTION"]as$key=>$val){
				
				if($val["ATTRIBUTES"]["SHOW"]){
					$aFunction[strtolower($val["ATTRIBUTES"]["VINDEX"])]['function']=$val["ATTRIBUTES"]["SHOW"];
					$aFunction[strtolower($val["ATTRIBUTES"]["VINDEX"])]['option']=$val;
				}

				$vindex.=strtolower($val["ATTRIBUTES"]["VINDEX"]);
				
				if($key!=count($option["HEAD"][0]["OPTION"])-1)$vindex.='|';
			}

			$vindex=explode('|',$vindex);
			$return=$this->getObjectJS($selector,$vindex,$aFunction,$option);
			return$return;
		}

		
		function getGridButtons($option,$type){
			global$alang,$_REQUEST,$formapi,$value;
			@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
			@$dialog=$files["DIALOG"];
			@$file=$files["NAME"];
			@$comment=$files["COMMENT"];
			
			if($option["BUTTONS"][0]["BUTTON"])foreach($option["BUTTONS"][0]["BUTTON"]as$bk=>$bv){
				unset($item);
				@$item["type"]=$bv["ATTRIBUTES"]["TYPE"];
				@$item["label"]=$alang[$bv["ATTRIBUTES"]["LABEL"]];
				@$width=$option["ATTRIBUTES"]["WIDTH"];
				
				if(@!$width)$width=640;
				@$height=$option["ATTRIBUTES"]["HEIGHT"];
				
				if(@!$height)$height=480;
				$item["onclick"]='processdatagrid("'.$item["type"].'","'.$dialog.'","'.$this->Name.'","",'.$width.','.$height.',"",'.$this->count.',"","","'.$this->uid.'");';
				switch($item["type"]){
					case'removeall':
						case't_refresh':
							case'delete':
								case'up':
									case'ftpsyncnow':
										case'down':
											
											if($type=="datagrid")$nr='document.getElementById("noreload").value=1;'; else $nr='';
											$item["onclick"]=' '.$nr.'document.getElementById("gridval").value="'.$this->Name.'";document.getElementById("gridaction").value="'.$item["type"].'";document.forms[0].submit();';
											break;
										case'addmlistmember':
											$listfile=addslashes($formapi->GetProperty("m_listfile"));
											
											if($_SESSION['ACCOUNT']=='ADMIN'){
												$ljs1='var listfile = document.getElementById("input_list_listfileedit").value;';
												$ljs2='document.getElementById("input_list_listfileedit").value = listfile;';
											} else {
												$ljs1='var listfile = "'.($listfile?$listfile:
													"").'";';
													$ljs2='';
												}

												
												if($listfile)$js=''; else $js='var name = document.getElementById("input_account_name").value;var domain = document.getElementById("input_account_domain").value;'.$ljs1.' if (listfile=="") { if (name==""){  alert("'.$alang['T_ERROR'].$alang['TDomainAdminForm_Group'].$alang['TX_ALIAS'].'");return false; } listfile = domain + "/" + name; }  '.$ljs2.' document.getElementById("value").value = listfile;';
												$item["onclick"]=$js.'if(document.getElementById("input_m_maxmembers")){var limit = document.getElementById("input_m_maxmembers").value;}else{var limit = 0;}processdatagrid("'.$item["type"].'","'.$dialog.'","'.$this->Name.'","",'.$width.','.$height.',"'.$listfile.'",'.$this->count.',limit,"","'.$this->uid.'");';
												break;
											case'addgroupmember':
												$item["onclick"]=' var value = "'.$value.'";var name = document.getElementById("input_group_name").value;if (name=="") {alert("'.$alang['T_ERROR'].$alang['TDomainAdminForm_Group'].$alang['TX_ALIAS'].'");}if (value.indexOf("@")==-1) name = name + "@"+value; else name = value; document.getElementById("value").value = name; processdatagrid("'.$item["type"].'","'.$dialog.'","'.$this->Name.'","",'.$width.','.$height.',name,'.$this->count.',"","","'.$this->uid.'");';
												break;
											case'addresourcemember':
												$item["onclick"]=' var value = "'.$value.'";var name = document.getElementById("input_account_name").value;if (name=="") {alert("'.$alang['T_ERROR'].$alang['TDomainAdminForm_Group'].$alang['TX_ALIAS'].'");}if (value.indexOf("@")==-1) name = name + "@"+value; else name = value; document.getElementById("value").value = name; processdatagrid("'.$item["type"].'","'.$dialog.'","'.$this->Name.'","",'.$width.','.$height.',name,'.$this->count.',"","","'.$this->uid.'");';
												break;
											case'editfile':
												
												if(!$this->Filename)$this->Filename=$file;
												
												if($this->commentFile){
													$commentFile=',"'.$this->commentFile.'"';
												} else {
													$commentFile=',""';
												}

												$item["onclick"]=' buttonedit("textfile","'.$_REQUEST['object'].'","'.urlencode($file).'"'.',"datagrid|'.$this->Name.'|'.$this->uid.'");';
												break;
									}

									$items[]=$item;
								}

								return$items;
							}

						}

						?>