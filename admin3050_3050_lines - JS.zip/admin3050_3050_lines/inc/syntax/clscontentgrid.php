﻿<?php
	require_once"inc/syntax/clswebservicegrid.php";
	require_once"inc/syntax/cfvariablefunctions.php";
	class cContentFiltersGrid extends cWebserviceGrid{
		function cContentFiltersGrid($name,$option){
			$this->Name=$name;
			$file=securepath($option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"]);
			$this->file=$file;
			
			if($file){
				$this->Filename=$_SESSION["INSTALLPATH"].$file;
			} else {
				return false;
			}

		}

		
		function LoadFromXML(){
			
			if(file_exists($this->Filename)){
				$parser=new ParseXML();
				$xml=$parser->GetXMLTree($this->Filename);
				$items=$xml["CONTENTFILTER"][0]["FILTER"];
				unset($parser);
			}

			
			if($items)foreach($items as$index=>$filter)
			if($filter)foreach($filter as$var=>$value)
			if($var!="VALUE"){
				
				if($var=="CONDITION"||$var=="READONLY"||$var=="ACTIVE"||$var=="TITLE")$return[$index][strtolower($var)]=$this->xml2arr($value,$var); else $return[$index]['action'][strtolower($var)]=$this->xml2arr($value,$var);
			}

			$this->Data=$return;
		}

		
		function saveToXML(){
			
			if($this->Data)foreach($this->Data as$index=>$filter)
			if($filter)foreach($filter as$var=>$value){
				
				if(!($var=='value'&&!isset($value[0]["VALUE"]))&&$var!="action")$return[$index][strtoupper($var)]=$this->arr2xml($value,strtolower($var));
				
				if($var=='action')
				if($value)foreach($value as$vkey=>$vval)$return[$index][strtoupper($vkey)]=$this->arr2xml($vval,strtolower($vkey));
			}

			return$return;
		}

		
		function Load($gObj,$array){
			$this->LoadFromXML();
			
			if(!$array)$this->SaveToSession($gObj);
		}

		
		function Save(){
			global$error;
			$arr=$this->SaveToXML();
			$xml["CONTENTFILTER"][0]["FILTER"]=$arr;
			$parser=new ParseXML();
			$xmlstr=$parser->Array2XML($xml,true);
			
			if($xmlstr!=""){
				$fp=@fopen($this->Filename,'w');
				fwrite($fp,trim($xmlstr));
				@fclose($fp);
			} else @unlink($this->Filename);
		}

		
		function arr2xml($item,$key){
			switch(strtolower($key)){
				case'condition':
					
					if($item)foreach($item as$ckey=>$condition)
					if($condition)foreach($condition as$vkey=>$vval)
					if($vkey)$return[strtoupper($ckey)][strtoupper($vkey)]=$this->arr2xml($vval,$vkey);
					break;
				case'header':
					$ret='';
					
					if(is_array($item["val"])){
						foreach($item["val"]as$val){
							
							if($val['regex']){
								$ret.=$val["action"]."^".htmlspecialchars(trim($val["header"])).": ".htmlspecialchars(trim($val["regex_value"]))."|| ".htmlspecialchars(trim($val["header_value"]))."&#13;&#10;";
							} else {
								$ret.=$val["action"].htmlspecialchars(trim($val["header"])).": ".htmlspecialchars(trim($val["header_value"]))."&#13;&#10;";
							}

						}

						
						if($ret!='')$return[0]["VAL"][0]["VALUE"]=$ret;
					} else {
						$return[0]["VAL"][0]["VALUE"]=str_replace("\r\n","&#13;&#10;",$item["val"]);
					}

					break;
				case'headerfooter':
					case'copymessage':
						case'extract':
							case'db':
								case'smartattach':
									
									if($item){
										foreach($item as$vkey=>$vval){
											
											if($vkey){
												$return[0][strtoupper($vkey)]=$this->arr2xml($vval,$vkey);
											}

										}

									} else {
										$return[0]['VALUE']='';
									}

									case'append':
										case'respond':
											case'sendmessage':
												
												if($item)foreach($item as$vkey=>$vval)
												if($vkey)$return[0][strtoupper($vkey)]=$this->arr2xml($vval,$vkey);
												default:
													
													if(!is_array($item))$return[0]["VALUE"]=htmlspecialchars($item);
													break;
										}

										return$return;
									}

									
									function xml2arr($item,$key){
										switch(strtolower($key)){
											case'condition':
												
												if($item)foreach($item as$ckey=>$condition)
												if($condition)foreach($condition as$vkey=>$vval){
													$pom=$this->xml2arr($vval,$vkey);
													
													if($pom!="")$return[strtolower($ckey)][strtolower($vkey)]=$this->xml2arr($vval,$vkey);
												}

												break;
											case'header':
												
												if($item[0])foreach($item[0]as$vkey=>$vval){
													
													if($vkey!="VALUE")$return[strtolower($vkey)]=$this->xml2arr($vval,$vkey);
												}

												break;
											case'headerfooter':
												case'copymessage':
													case'append':
														case'extract':
															case'respond':
																case'sendmessage':
																	case'db':
																		case'smartattach':
																			
																			if($item[0])foreach($item[0]as$vkey=>$vval){
																				
																				if($vkey!="VALUE")$return[strtolower($vkey)]=$this->xml2arr($vval,$vkey);
																			}

																			default:
																				
																				if(is_array($item)&&trim($item[0]["VALUE"])!="")$return=$item[0]["VALUE"];
																				break;
																	}

																	return$return;
																}

																
																function getObjectJS($selector,$vindex,$aFunction=false,$option){
																	global$skin_dir,$sGridItem;
																	$arr["dname"]=$this->Name;
																	@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
																	@$dialog=$files["DIALOG"];
																	@$file=$files["NAME"];
																	@$comment=$files["COMMENT"];
																	@$width=$option["ATTRIBUTES"]["WIDTH"];
																	
																	if(@!$width)$width=640;
																	@$height=$option["ATTRIBUTES"]["HEIGHT"];
																	
																	if(@!$height)$height=480;
																	
																	if($this->Data)foreach($this->Data as$key2=>$val2){
																		foreach($vindex as$key3=>$val3){
																			$val=strtolower($val3);
																			
																			if($val=="active")$item=$val2[$val3]?"Y":
																			"N"; else $item=eregi_replace("([\\\'\"])","\\\\1",$val2[$val3]);
																			$arr["items"]["num"][$key2]['item']["num"][$key3]['value']=str_replace(CRLF,";",$item);
																			$arr["items"]["num"][$key2]['item']["num"][$key3]['label']='<a href="javascript:processdatagrid(\\\'edit\\\',\\\''.$dialog.'\\\',\\\''.$this->Name.'\\\',\\\'\\\','.$width.','.$height.',\\\'\\\',\\\''.$this->count.'\\\',0,\\\''.$key2.'\\\',\\\''.$this->uid.'\\\');">'.$arr["items"]["num"][$key2]['item']["num"][$key3]['value'].'</a>';
																			$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=$arr["items"]["num"][$key2]['item']["num"][$key3]['value'];
																		}

																		$arr["items"]["num"][$key2]["cislo"]=$key2;
																		
																		if($this->Name.$key2==$sGridItem)$arr["items"]["num"][$key2]["selected"]=1;
																	}

																	$arr["selector"]=$selector;
																	return template($skin_dir."dgridjs2.tpl",$arr);
																}

															}

															
															class cCFConditionsGrid extends cStdGrid{
																function cCFConditionsGrid($option,$name){
																	$this->Name=$name;
																}

																
																function Load($gObj,$array){
																	global$alang;
																	$parser=&new ParseXML();
																	$actionXML=$parser->GetXMLTree("xml/cf/conditions.xml");
																	$count=0;
																	$this->HeaderType=array();
																	$this->Expression=array();
																	
																	if($gObj->Base[strtolower($this->Name)])foreach($gObj->Base[strtolower($this->Name)]as$ck=>$cv){
																		
																		if($cv["expression"])$this->Expression[$ck]=$cv["expression"];
																		
																		if($cv["headertype"])$this->HeaderType[$ck]=$cv["headertype"];
																		
																		if(!$cv["headertype"]&&!$cv["expression"])$this->HeaderType[$ck]=0;
																	}

																	foreach($actionXML["CONDITIONS"][0]["CONDITION"]as$akey=>$aval){
																		
																		if(@in_array($aval["ATTRIBUTES"]["HTYPE"],$this->HeaderType)&&isset($aval["ATTRIBUTES"]["HTYPE"])){
																			$item['selected']=1;
																			$item['type']="condition";
																			$item['ctype']="headertype";
																			$item['index']=0;
																			$item['index2']=$aval["ATTRIBUTES"]["HTYPE"];
																		} else
																		if(@in_array($aval["ATTRIBUTES"]["EXPRESSION"],$this->Expression)&&isset($aval["ATTRIBUTES"]["EXPRESSION"])){
																			$item['selected']=1;
																			$item['type']="condition";
																			$item['ctype']="expression";
																			$item['index']=0;
																			$item['index2']=$aval["ATTRIBUTES"]["EXPRESSION"];
																		} else {
																			$item['selected']=0;
																			$item['type']='condition';
																			
																			if(isset($aval["ATTRIBUTES"]["HTYPE"])){
																				$item['ctype']="headertype";
																				$item['index2']=$aval["ATTRIBUTES"]["HTYPE"];
																				$item['index']=-1;
																			} else {
																				$item['ctype']="expression";
																				$item['index2']=$aval["ATTRIBUTES"]["EXPRESSION"];
																				$item['index']=-1;
																			}

																		}

																		$text=str_replace("&lt;a&gt;%s&lt;/a&gt;",$alang[$aval["ATTRIBUTES"]["LINK"]],$alang[$aval["ATTRIBUTES"]["TEXT"]]);
																		$item['action']=$item['selected']?"cfdel":
																		"cfadd";
																		$item['description']='<div id="cf_condition_'.$count.'" onclick="selectcfitem(0,this);" class="unselectedcf" style="width:100%;height:100%;" ondblclick="setCFAction('.$item['index'].','.$item['index2'].',\'cfadd\',\'condition\',\''.$item['ctype'].'\');">'.$text.'</div>';
																		$this->Data[$count++]=$item;
																	}

																}

																
																function getObjectJS($selector,$vindex){
																	global$skin_dir,$sGridItem;
																	$arr["dname"]=$this->Name;
																	
																	if($this->Data)foreach($this->Data as$key2=>$val2){
																		foreach($vindex as$key3=>$val3){
																			$val=strtolower($val3);
																			$item=eregi_replace("([\\\'\"])","\\\\1",$val2[$val3]);
																			$arr["items"]["num"][$key2]['item']["num"][$key3]['label']=str_replace(CRLF,";",$item);
																			$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=str_replace(CRLF,";",$item);
																		}

																		$arr["items"]["num"][$key2]["cislo"]=$key2;
																		$arr["items"]["num"][$key2]["index"]=$val2["index"];
																		$arr["items"]["num"][$key2]["index2"]=$val2["index2"];
																		$arr["items"]["num"][$key2]["type"]=$val2["type"];
																		$arr["items"]["num"][$key2]["ctype"]=$val2["ctype"];
																		$arr["items"]["num"][$key2]["action"]=$val2["action"];
																		
																		if($val2["selected"]==1)$arr["items"]["num"][$key2]["selected"]=1; else $arr["items"]["num"][$key2]["selected"]=0;
																	}

																	$arr["selector"]=$selector;
																	$arr["onclick"]=1;
																	return template($skin_dir."dgridjs2.tpl",$arr);
																}

																
																function Save(){
																}

															}

															
															class cCFActionsGrid extends cStdGrid{
																function cCFActionsGrid($option,$name){
																	$this->Name=$name;
																}

																
																function Load($gObj,$array){
																	global$alang;
																	$parser=&new ParseXML();
																	$actionXML=$parser->GetXMLTree("xml/cf/actions.xml");
																	$count=0;
																	foreach($actionXML["ACTIONS"][0]["ACTION"]as$aval){
																		
																		if($gObj->Base[strtolower($this->Name)][strtolower($aval["ATTRIBUTES"]["NAME"])])$item["selected"]=1; else $item['selected']=cfisselected($aval["ATTRIBUTES"]["NAME"]);
																		$item['action']=$item['selected']?"cfdel":
																		"cfadd";
																		$item['description']=str_replace("&lt;a&gt;%s&lt;/a&gt;",$alang[$aval["ATTRIBUTES"]["LINK"]],$alang[$aval["ATTRIBUTES"]["TEXT"]]);
																		$item['type']="action";
																		$item['ctype']="";
																		$item['index']="\'".$aval["ATTRIBUTES"]["NAME"]."\'";
																		$item['index2']=$item['index'];
																		$this->Data[$count++]=$item;
																	}

																}

																
																function getObjectJS($selector,$vindex){
																	global$skin_dir,$sGridItem,$gObj;
																	$arr["dname"]=$this->Name;
																	
																	if($this->Data)foreach($this->Data as$key2=>$val2){
																		foreach($vindex as$key3=>$val3){
																			$val=strtolower($val3);
																			$item=eregi_replace("([\\\'\"])","\\\\1",$val2[$val3]);
																			$arr["items"]["num"][$key2]['item']["num"][$key3]['label']=str_replace(CRLF,";",$item);
																			$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=str_replace(CRLF,";",$item);
																		}

																		$arr["items"]["num"][$key2]["cislo"]=$key2;
																		$arr["items"]["num"][$key2]["index"]=$val2["index"];
																		$arr["items"]["num"][$key2]["index2"]=$val2["index2"];
																		$arr["items"]["num"][$key2]["type"]=$val2["type"];
																		$arr["items"]["num"][$key2]["ctype"]=$val2["ctype"];
																		$arr["items"]["num"][$key2]["action"]=$val2["action"];
																		
																		if($val2["selected"]==1)$arr["items"]["num"][$key2]["selected"]=1; else $arr["items"]["num"][$key2]["selected"]=0;
																	}

																	$arr["selector"]=$selector;
																	$arr["onclick"]=1;
																	return template($skin_dir."dgridjs2.tpl",$arr);
																}

																
																function Save(){
																}

															}

															
															class cCFEditGrid extends cStdGrid{
																function cCFEditGrid($option,$name){
																	$this->Name=$name;
																}

																
																function Load($gObj,$array){
																	global$alang;
																	$parser=&new ParseXML();
																	$actionXML=$parser->GetXMLTree("xml/cf/actions.xml");
																	$conditionXML=$parser->GetXMLTree("xml/cf/conditions.xml");
																	$count=0;
																	
																	if($gObj->Base["condition"])foreach($gObj->Base["condition"]as$ck=>$cv){
																		$item="";
																		
																		if($cv["expression"]){
																			$item['selected']=1;
																			$item['type']="condition";
																			$item['ctype']="expression";
																			$item['index']=$ck;
																			$item['index2']=$cv['expression'];
																		}

																		
																		if($cv["headertype"]){
																			$item['selected']=1;
																			$item['type']="condition";
																			$item['ctype']="headertype";
																			$item['index']=$ck;
																			$item['index2']=$cv['headertype'];
																		}

																		
																		if(!$cv["headertype"]&&!$cv["expression"]){
																			$item['type']="condition";
																			$item['ctype']="headertype";
																			$item['index']=$ck;
																			$item['index2']=0;
																		}

																		$val=0;
																		foreach($conditionXML["CONDITIONS"][0]["CONDITION"]as$cval){
																			
																			if($val)break;
																			
																			if($cval["ATTRIBUTES"]["EXPRESSION"]==$item['index2']&&$item['ctype']=='expression')$val=$cval;
																			
																			if(($cval["ATTRIBUTES"]["HTYPE"]==$item['index2']&&$item['ctype']=='headertype'))$val=$cval;
																		}

																		$andor=$gObj->Base["condition"][$item['index']]["and"]==1?strtolower($alang["TStrings_hland"]):
																		strtolower($alang["TStrings_hlor"]);
																		
																		if($item['index']==0)$andor=""; else $andor='<a style="display:inline;width:30px;" href="javascript:processdatagrid(\'cfitem\',\'cf_andor\',\'condition\','.$item['index'].',640,480,\'\','.$this->count.',0,\'\',\''.$this->uid.'\');">'.$andor.'</a>';
																		$item['bracketsleft']=$gObj->Base["condition"][$item['index']]["bracketsleft"];
																		$item['bracketsright']=$gObj->Base["condition"][$item['index']]["bracketsright"];
																		$item['logicalnot']=$gObj->Base["condition"][$item['index']]["logicalnot"];
																		$item['description']=$this->getLinkText($gObj->Base["condition"],$item,$val,$andor,$item['index']);
																		$this->Data[$item['index']]=$item;
																	}

																	$clength=$clength0=count($this->Data);
																	foreach($actionXML["ACTIONS"][0]["ACTION"]as$aval){
																		$item="";
																		
																		if($gObj->Base["action"][strtolower($aval["ATTRIBUTES"]["NAME"])])$item["selected"]=1; else {
																			$item['selected']=cfisselected($aval["ATTRIBUTES"]["NAME"]);
																			
																			if(!$item['selected'])continue;
																		}

																		
																		if($clength==$clength0)$andor=""; else $andor=strtolower($alang["TStrings_hland"]);
																		$item['type']="action";
																		$item['ctype']="cfitem";
																		$item['index']="'".$aval["ATTRIBUTES"]["NAME"]."'";
																		$item['index2']=0;
																		$item['description']=$this->getLinkText($gObj->Base["action"],$item,$aval,$andor,$clength);
																		$this->Data[]=$item;
																		$clength++;
																	}

																	@ksort($this->Data);
																}

																
																function getLinkText($base,$item,$ditem,$andor,$count){
																	global$alang,$sGridItem;
																	$name=strtolower($ditem["ATTRIBUTES"]["NAME"]);
																	$text=$alang[$ditem["ATTRIBUTES"]["TEXT"]];
																	$link=$alang[$ditem["ATTRIBUTES"]["LINK"]];
																	$index=$item['index'];
																	switch($name){
																		case"hpriority":
																			$labels=explode("|",$alang["TContentPriorityForm_PriorityList"]);
																			$value=$labels[$base[$item['index']]['contain']-1];
																			break;
																		case'esize':
																			$labels=explode("|",$alang["TConfigForm_MaxMailSizeEditUnits"]);
																			$val=$base[$item['index']]['messagesize'];
																			$opt["ATTRIBUTES"]["SAVEUNIT"]=0;
																			$units=formfunctionvalues('u_bytes',$val,true,$name,&$message,$opt,&$error);
																			$value=$base[$item['index']]['messagesizesmaller']?'< ':
																				'> ';
																				$value.=$val?$val:
																					0;
																					$value.=' '.$labels[$units-1];
																					break;
																				case"priority":
																					$labels=explode("|",$alang["TContentPriorityForm_PriorityList"]);
																					$value=$labels[$base[$name]-1];
																					$index="'donotmove'";
																					break;
																				case"bayes":
																					case"sascore":
																						$value=$base[$item['index']]['messagesizesmaller']?"<":
																							">";
																							$value.=' '.$base[$item['index']]['messagesize']/100;
																							break;
																						case"ard":
																							
																							if($base['reject']==1)$value=$alang['TStrings_messageactionreject'];
																							
																							if($base['accept']==1)$value=$alang['TStrings_messageactionaccept'];
																							
																							if($base['delete']==1)$value=$alang['TStrings_messageactiondelete'];
																							
																							if($base['markspam']==1)$value=$alang['TStrings_messageactionspam'];
																							
																							if($base['markspam']==2)$value=$alang['TStrings_messageactionquarantine'];
																							$index="'donotmove'";
																							break;
																						case"markgs":
																							
																							if($base['markgenuine']==1)$value=$alang['TStrings_messageactionquarantine'];
																							
																							if($base['markspam']==1)$value=$alang['TStrings_messageactionspam'];
																							$index="'donotmove'";
																							break;
																						case'db':
																							$value=$base[$name]["sql"];
																							
																							if(!$value)$value=$link;
																							break;
																						case"copymessage":
																							$value=$base[$name]["copymessageto"];
																							
																							if(!$value)$value=$link;
																							break;
																						case"forward":
																							
																							if($name=="forward")$value=$base[$name];
																							
																							if(!$value)$value=$link;
																							$index="'donotmove'";
																							break;
																						case"execute":
																							$value=$base['executefilter'];
																							
																							if(!$value)$value=$link;
																							$index="'donotmove'";
																							break;
																						case"respond":
																							$value=$link;
																							break;
																						case"smtpresponse":
																							$value=$base["smtpmessage"];
																							
																							if(!$value)$value=$link;
																							$index="'donotmove'";
																							break;
																						case"append":
																							$value=$base[$name]["appendtext"];
																							
																							if(!$value)$value=$link;
																							break;
																						case"extract":
																							$value=$base[$name]["extractto"];
																							
																							if(!$value)$value=$link;
																							break;
																						case"append":
																							$value=$base[$name]["appendtext"];
																							break;
																						case'score':
																							$value=$base["score"]/100;
																							$index="'donotmove'";
																							break;
																						case"sendmessage":
																							case"header":
																								case"headerfooter":
																									case"ltime":
																										$value=$link;
																										break;
																									default:
																										$not_val='';
																										
																										if(is_numeric($item['index'])){
																											$NotArray=array(8=>0,9=>1,4=>0,5=>1,10=>0,11=>1,2=>0,6=>1,3=>0,7=>1,0=>0,1=>1,13=>1,12=>0);
																											$not_val=$NotArray[$base[$item['index']]["containtype"]];
																											$not_val=$not_val?($alang['TContentHeader_NotBox'].' '):
																												'';
																											}

																											
																											if(isset($base[$item['index']]["dummystring"]))$value=$not_val.$base[$item['index']]["dummystring"]; else
																											if(isset($base[$item['index']]["contain"]))$value=$not_val.$base[$item['index']]["contain"]; else $value=$link;
																											break;
																								}

																								$lb="";
																								$rb="";
																								for($lbc=0;$lbc<$item['bracketsleft'];$lbc++)$lb.="(";
																								for($rbc=0;$rbc<$item['bracketsright'];$rbc++)$rb.=")";
																								$ln=$item['logicalnot']?" ! ":
																								"";
																								
																								if($item['focus'])$class="selectedcf"; else $class="unselectedcf";
																								$divb='<div id="cf_edit_'.$count.'" onclick="selectcfitem(1,this,'.$item['index'].','.$item['index2'].',\''.$item['type'].'\',\''.$item['ctype'].'\');" class="'.$class.'" style="width:100%;height:100%;">';
																								$dive='</div>';
																								
																								if($value=="")$value=$link;
																								$return=str_replace("&lt;a&gt;%s&lt;/a&gt;",'<a style="display:inline;" href="javascript:processdatagrid(\''.$item['ctype'].'\',\''.getfilevarpath($ditem['ATTRIBUTES']['DIALOG'],"").'\',\''.$item['type'].'\','.$index.',640,480,\'\','.$this->count.',0,\'\',\''.$this->uid.'\');" >'.$value.'</a>',$text);
																								return$divb.$andor." ".$lb.$ln.$return.$rb.$dive;
																							}

																							
																							function getObjectJS($selector,$vindex){
																								global$skin_dir,$sGridItem;
																								$arr["dname"]=$this->Name;
																								
																								if($this->Data)foreach($this->Data as$key2=>$val2){
																									$arr["items"]["num"][$key2]['item']["num"][0]['label']="";
																									$arr["items"]["num"][$key2]['item']["num"][0]['sort']="";
																									$arr["items"]["num"][$key2]['item']["num"][1]['label']=eregi_replace("([\\\'\"])","\\\\1",str_replace(CRLF,";",$val2["description"]));
																									$arr["items"]["num"][$key2]['item']["num"][1]['sort']=eregi_replace("([\\\'\"])","\\\\1",str_replace(CRLF,";",$val2["description"]));
																									$arr["items"]["num"][$key2]["cislo"]=$key2;
																									$arr["items"]["num"][$key2]["index"]=$val2["index"];
																									$arr["items"]["num"][$key2]["index2"]=$val2["index2"];
																									$arr["items"]["num"][$key2]["type"]=$val2["type"];
																									$arr["items"]["num"][$key2]["ctype"]=$val2["ctype"];
																									$arr["items"]["num"][$key2]["ctype"]=$val2["focu"];
																								}

																								return template($skin_dir."dgridjs2.tpl",$arr);
																							}

																							
																							function getGridButtons($option,$type){
																								global$alang;
																								$item["onclick"]='cfbuttons("cf_logicalnot");';
																								$item["label"]="!";
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cf_leftbracket");';
																								$item["label"]="(";
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cf_rightbracket");';
																								$item["label"]=")";
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cf_up");';
																								$item["label"]=$alang["TStrings_buttonup"];
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cf_down");';
																								$item["label"]=$alang["TStrings_buttondown"];
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cfdel2");';
																								$item["label"]=$alang["TConfigForm_DeleteItem"];
																								$item["type"]="edit";
																								$items[]=$item;
																								return$items;
																							}

																							
																							function Save(){
																							}

																						}

																						?>