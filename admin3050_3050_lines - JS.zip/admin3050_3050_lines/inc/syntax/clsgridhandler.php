﻿<?php 
	require_once"inc/include.php";
	require_once"inc/syntax/clsrblgrid.php";
	class cGridHandler{
		var$PName;
		var$PItem;
		function cGridHandler($multigrid=false,$pitem=0,$pname="",$puid="",$location="",$submit=false){
			global$editform;
			$this->PItem=$pitem;
			$this->PName=$pname;
			$this->PUID=$_REQUEST['puid']?$_REQUEST['puid']:
			$puid;
			$this->Multigrid=$multigrid;
			$this->Location=$location;
			
			if($multigrid)$this->Base=&cGridHandler::GetBase($this->Location); else $this->Base=&$_SESSION["griddata"]["grids"][$this->PUID];
		}

		
		function&GetBase($location){
			global$formapi;
			
			if(substr_count($location,"|")>0){
				$pom=&$_SESSION["griddata"]["grids"];
				$lindex=0;
				$levels=explode("|",$location);
				$uid=$this->PUID;
				$pom=&$pom[$uid];
				foreach($levels as$level){
					$info=explode("-",$level);
					$name=$info[0];
					$index=$info[1];
					
					if($index=="donotmove")$pom=&$pom[strtolower($name)]; else $pom=&$pom[strtolower($name)][$index];
				}

				return$pom;
			} else {
				return$_SESSION["griddata"]["grids"][$this->PUID][$this->PName][$this->PItem];
			}

		}

		
		function Save(){
			
			if($this->Grids)foreach($this->Grids as$grid)$grid->Save();
		}

		
		function LoadData(){
			
			if($this->Grids)foreach($this->Grids as$gkey=>$grid){
				$this->Grids[$gkey]->LoadFromSession($this);
			}

		}

		
		function AddGrid($type,$name,$option,$array,$count,$uid){
			switch(strtolower($type)){
				case"structured":
					require_once"inc/syntax/clsstructuredgrid.php";
					$this->Grids[$name]=new cStructuredGrid($option);
					break;
				case"relaygrid":
					require_once"inc/syntax/clstarpitrelaygrid.php";
					$this->Grids[$name]=new cRelayGrid($name);
					break;
				case"tarpit":
					require_once"inc/syntax/clstarpitrelaygrid.php";
					$this->Grids[$name]=new cTarpitGrid($name);
					break;
				case"contentfilters":
					require_once"inc/syntax/clscontentgrid.php";
					$this->Grids[$name]=new cContentFiltersGrid($name,$option);
					break;
				case"ftp":
					require_once"inc/syntax/clsftpgrid.php";
					$this->Grids[$name]=new cFTPGrid($option);
					break;
				case"ftpsync":
					require_once"inc/syntax/clsftpsyncgrid.php";
					$this->Grids[$name]=new cFTPSyncGrid($option);
					break;
				case"webservice":
					require_once"inc/syntax/clswebservicegrid.php";
					$this->Grids[$name]=new cWebserviceGrid($option);
					break;
				case"sipsub":
					case"ftpsub":
						case"webservicesub":
							case"session":
								require_once"inc/syntax/clssessiongrid.php";
								$this->Grids[$name]=new cSessionGrid($option,$name);
								break;
							case"cfconditions":
								require_once"inc/syntax/clscontentgrid.php";
								$this->Grids[$name]=new cCFConditionsGrid($option,$name);
								break;
							case"cfactions":
								require_once"inc/syntax/clscontentgrid.php";
								$this->Grids[$name]=new cCFActionsGrid($option,$name);
								break;
							case"cfedit":
								require_once"inc/syntax/clscontentgrid.php";
								$this->Grids[$name]=new cCFEditGrid($option,$name);
								break;
							case"cf_header":
								require_once"inc/syntax/clscf_headergrid.php";
								$this->Grids[$name]=new cCFHeaderGrid($option,$name);
								break;
							case"schedule":
								require_once"inc/syntax/clsschedulegrid.php";
								$this->Grids[$name]=new cScheduleGrid($name);
								break;
							case"servicebind":
								require_once"inc/syntax/clssbindgrid.php";
								$this->Grids[$name]=new cServiceBindGrid($name,$_REQUEST["value"],$option);
								break;
							case"taskevent":
								require_once"inc/syntax/clstaskeventgrid.php";
								$this->Grids[$name]=new cTaskEventGrid($name,$option);
								break;
							case"members":
								require_once"inc/syntax/clsmembersgrid.php";
								$this->Grids[$name]=new cMembersGrid($name,$_REQUEST["fileid"],$_REQUEST["args"],$option,$this);
								break;
							case"members2":
								require_once"inc/syntax/clsmembers2grid.php";
								$this->Grids[$name]=new cMembers2Grid($name,$_REQUEST["fileid"],$_REQUEST["param"],$option,$this,$uid);
								break;
							case"listmembers":
								require_once"inc/syntax/clslistmembergrid.php";
								$this->Grids[$name]=new cListMemberGrid($name,$option,$this);
								break;
							case"siprules":
								require_once"inc/syntax/clssiprulesgrid.php";
								$this->Grids[$name]=new cSIPRulesGrid($option);
								break;
							case"sipusers":
								require_once"inc/syntax/clssipusersgrid.php";
								$this->Grids[$name]=new cSIPUsersGrid($option);
								break;
							case"sipdevices":
								require_once"inc/syntax/clssipdevicesgrid.php";
								$this->Grids[$name]=new cSIPDevicesGrid($option);
								break;
							case"sipgateways":
								require_once"inc/syntax/clssipgatewaysgrid.php";
								$this->Grids[$name]=new cSIPGatewaysGrid($option);
								break;
							case"externalav":
								require_once"inc/syntax/clsexternalavgrid.php";
								$this->Grids[$name]=new cExternalAVGrid($option);
								break;
							case'challenge':
								require_once"inc/syntax/clsquarantinegrid.php";
								$prefix=substr(strtolower($name),0,1).'_';
								$top=$_REQUEST[$prefix.'top'];
								
								if(!$top){
									$top=100;
								}

								$sender=$_REQUEST[$prefix.'sender'];
								$owner=$_REQUEST[$prefix.'owner'];
								$domain=$_REQUEST[$prefix.'domain'];
								$this->Grids[$name]=new cChallengeGrid($option,$name,$top,$sender,$owner,$domain);
								break;
							case'greylist':
								$top=$_REQUEST['g_top'];
								$type=$_REQUEST['g_status'];
								$owner=$_REQUEST['g_owner'];
								$value=$_REQUEST['g_value'];
								require_once"inc/syntax/clsgreylistgrid.php";
								$this->Grids[$name]=new cGreyListGrid($option,$name,$top,$type,$owner,$value);
								break;
							case'rules':
								require_once"inc/syntax/clsrulesgrid.php";
								$this->Grids[$name]=new cRulesGrid($option,$name);
								break;
							case"rulesconditions":
								require_once"inc/syntax/clsrulesgrid.php";
								$this->Grids[$name]=new cRulesConditionsGrid($option,$name);
								break;
							case"rulesactions":
								require_once"inc/syntax/clsrulesgrid.php";
								$this->Grids[$name]=new cRulesActionsGrid($option,$name);
								break;
							case"rulesedit":
								require_once"inc/syntax/clsrulesgrid.php";
								$this->Grids[$name]=new cRulesEditGrid($option,$name);
								break;
							case"wordsgrid":
								require_once"inc/syntax/clswordsgrid.php";
								$this->Grids[$name]=new cWordsGrid($option,$name);
								break;
							case"indexgrid":
								require_once"inc/syntax/clsindexinggrid.php";
								$this->Grids[$name]=new cIndexingQueueGrid($option,$name);
								break;
							case"rblgrid":
								require_once"inc/syntax/clsrblgrid.php";
								$this->Grids[$name]=new cRBLGrid($option,$name);
								break;
							case"publicfolder":
								require_once"inc/syntax/clspublicfolder.php";
								$this->Grids[$name]=new cPublicFolderGrid($option,$name);
								break;
							case"sharedfolder":
								require_once"inc/syntax/clssharedfolder.php";
								$this->Grids[$name]=new cSharedFolderGrid($option,$name);
								break;
							case"xml":
								require_once"inc/syntax/clsxmlgrid.php";
								$this->Grids[$name]=new cXMLGrid($option,$name);
								break;
							case"push_accounts":
								require_once"inc/syntax/clspushgrid.php";
								$this->Grids[$name]=new cPushAccountsGrid($option,$name);
								break;
							case"certificates":
								require_once"inc/syntax/clscertificatesgrid.php";
								$this->Grids[$name]=new cCertificatesGrid($option,$name);
								break;
							case'tunnel':
								require_once"inc/syntax/clstunnelgrid.php";
								$this->Grids[$name]=new cTunnelGrid($option,$name);
								break;
							case'network':
								require_once"inc/syntax/clsnetworkgrid.php";
								$this->Grids[$name]=new cNetworkGrid($option,$name);
								break;
							case'subdomains':
								require_once"inc/syntax/clssubdomainsgrid.php";
								$this->Grids[$name]=new cSubdomainsGrid($option,$name);
								break;
							case"etrndownload":
								require_once"inc/syntax/clsetrngrid.php";
								$this->Grids[$name]=new cETRNGrid($option,$name);
								break;
							case"standard":
								default:
									require_once"inc/syntax/clsstdgrid.php";
									$this->Grids[$name]=new cStdGrid($option);
									break;
						}

						$this->Grids[$name]->count=$count;
						$this->Grids[$name]->uid=$uid;
						$this->Grids[$name]->Load($this,$array);
					}

					
					function getGridItemData($vindex){
						
						if(intval($vindex)!=0)$vindex--; else $vindex=strtolower($vindex);
						$return=$this->Base[$vindex];
						$return=eregi_replace('"','&quot;',$return);
						return$return;
					}

					
					function setGridItemData($vindex,$vvalue){
						
						if(intval($vindex)!=0)$vindex--; else $vindex=strtolower($vindex);
						
						if(!$vindex)$this->Base[intval($vindex)]=$vvalue; else $this->Base[$vindex]=$vvalue;
						return true;
					}

					
					function processGridButtons($menulink,$grid,$action,$object){
						global$sGridItem;
						$uid=$_REQUEST['puid'];
						$api=createobject("api");
						$grid=strtolower($grid);
						
						if($menulink==1){
							unset($_SESSION["griddata"]);
						} else {
							switch($action){
								case'rblset':
									$id=$_REQUEST['index'];
									$state=$_REQUEST['index2']=="true"?true:
										false;
										
										if($state)cRBLGrid::turnOnRBL($id); else cRBLGrid::turnOffRBL($id);
										break;
									case'delete':
										$baseIndex=$grid;
										
										if($grid=='header'){
											$baseIndex='val';
										}

										
										if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival)unset($this->Base[$baseIndex][$ival]);
										break;
									case'ftpsyncnow':
										$result=true;
										
										if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival)$result=$result&&$api->FTPSyncNow($ival); else $result=false;
										
										if($result)echo'<div class="infomessage">FTP Syncronization successfull</div>'; else echo'<div class="errormessage">FTP Syncronization failed</div>';
										break;
									case'up':
										
										if(isset($_REQUEST['sel_'.$grid][0])){
											$gi=$_REQUEST['sel_'.$grid][0];
											
											if(isset($this->Base[$grid][$gi-1])){
												switchval($this->Base[$grid][$gi],$this->Base[$grid][$gi-1]);
												$sGridItem=$grid.($gi-1);
											} else $sGridItem=$grid.$gi;
										} else {
											
											if(isset($this->Base[$grid][$gi-1])){
												switchval($this->Base[$grid][$gi],$this->Base[$grid][$gi-1]);
												$sGridItem=$grid.($gi-1);
											} else $sGridItem=$grid.$gi;
										}

										break;
									case'down':
										
										if(isset($_REQUEST['sel_'.$grid][0])){
											$gi=$_REQUEST['sel_'.$grid][0];
											
											if($object=="datagrid"){
												
												if(isset($this->Base[$grid][$gi+1])){
													switchval($this->Base[$grid][$gi],$this->Base[$parent][$grid][$gi+1]);
													$sGridItem=$grid.($gi+1);
												} else $sGridItem=$grid.$gi;
											} else {
												
												if(isset($this->Base[$grid][$gi+1])){
													switchval($this->Base[$grid][$gi],$this->Base[$grid][$gi+1]);
													$sGridItem=$grid.($gi+1);
												} else $sGridItem=$grid.$gi;
											}

										}

										break;
									case'removeall':
										unset($this->Base[$grid]);
										break;
									case"cfadd":
										
										if($grid=="action"){
											switch($_REQUEST['index']){
												case"ard":
													$this->Base[$grid]["reject"]=1;
													break;
												case"markgs":
													$this->Base[$grid]["markspam"]=1;
													break;
												case"smtpresponse":
													$this->Base[$grid]["smtpresponse"]=1;
													$this->Base[$grid]["smtpmessage"]="";
													break;
												case"respond":
													case"sendmessage":
														$item['FROM']="";
														$item['TO']="";
														$item['SUBJECT']="";
														$item['TYPE']="0";
														$item['MSG']="";
														$this->Base[$grid][$_REQUEST['index']]=$item;
														break;
													case"header":
														$this->Base[$grid][$_REQUEST['index']]='';
														break;
													case"headerfooter":
														$item['HEADERFILE']="";
														$item['FOOTERFILE']='';
														$this->Base[$grid][$_REQUEST['index']]=$item;
														break;
													case"extract":
														$this->Base[$grid][$_REQUEST['index']]["extractto"]="";
														break;
													case"copymessage":
														$this->Base[$grid][$_REQUEST['index']]["copymessageto"]="";
														break;
													case"append":
														$this->Base[$grid]["append"]["appendtext"]="";
														$this->Base[$grid]["append"]["appendfile"]="";
														$this->Base[$grid]["append"]["appendrewrite"]=0;
														break;
													case"forward":
														$this->Base[$grid]["forward"]='mail';
														break;
													case"priority":
														$this->Base[$grid]["priority"]=2;
														break;
													case"score":
														$this->Base[$grid]["score"]=100;
														break;
													default:
														$this->Base[$grid][$_REQUEST['index']]=1;
														break;
												}

											} else {
												$count=count($this->Base[$grid]);
												$this->Base[$grid][$count][$_REQUEST['ctype']]=$_REQUEST['index2'];
												$this->Base[$grid][$count]['and']=1;
												
												if($_REQUEST['index2']==30)$this->Base[$grid][$count]['contain']=0;
												$array=array(0=>1,1=>1,2=>1,3=>1,7=>1,5=>1,20=>1,6=>1,11=>1,12=>1,8=>1,10=>1,9=>1,15=>1,19=>1,29=>1);
												
												if($array[$_REQUEST['index2']])$this->Base[$grid][$count]['containtype']=4;
											}

											break;
											case"cfdel2":
												case"cfdel":
													
													if($grid=="action"){
														switch($_REQUEST['index']){
															case"ard":
																unset($this->Base[$grid]["reject"]);
																unset($this->Base[$grid]["accept"]);
																unset($this->Base[$grid]["delete"]);
																unset($this->Base[$grid]["spam"]);
																unset($this->Base[$grid]["quarantine"]);
																break;
															case"markgs":
																unset($this->Base[$grid]["markspam"]);
																unset($this->Base[$grid]["markgenuine"]);
																break;
															case"smtpresponse":
																unset($this->Base[$grid]["smtpresponse"]);
																unset($this->Base[$grid]["smtpmessage"]);
																break;
															default:
																unset($this->Base[$grid][$_REQUEST['index']]);
																break;
														}

													} else {
														
														if($this->Base[$grid])
														if($action!="cfdel2"){
															foreach($this->Base[$grid]as$key=>$value)
															if(($value[$_REQUEST['ctype']]==$_REQUEST['index2'])||($_REQUEST['index2']==0&&!isset($value["headertype"])&&!isset($value["expression"])))unset($this->Base[$grid][$key]);
														} else {
															unset($this->Base[$grid][$_REQUEST['index']]);
														}

														
														if($this->Base[$grid])foreach($this->Base[$grid]as$ckey=>$cval)$sorted[]=$cval;
														$this->Base[$grid]=$sorted;
													}

													break;
													case"cf_logicalnot":
														$this->Base[$grid][$_REQUEST['index']]['logicalnot']=1;
														break;
													case"cf_leftbracket":
														$this->Base[$grid][$_REQUEST['index']]['bracketsleft']+=1;
														break;
													case"cf_rightbracket":
														$this->Base[$grid][$_REQUEST['index']]['bracketsright']+=1;
														break;
													case"cf_up":
														$gi=$_REQUEST['index'];
														
														if(isset($this->Base[$grid][$gi-1])){
															switchval($this->Base[$grid][$gi],$this->Base[$grid][$gi-1]);
															$sGridItem=($gi-1);
														} else $sGridItem=$gi;
														break;
													case"cf_down":
														$gi=$_REQUEST['index'];
														
														if(isset($this->Base[$grid][$gi+1])){
															switchval($this->Base[$grid][$gi],$this->Base[$grid][$gi+1]);
															$sGridItem=($gi+1);
														} else $sGridItem=$gi;
														break;
													case'ch_deliver':
														
														if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival){
															$api->QuarantineAuthorize($this->Base[$grid][$ival][2]);
															$api->QuarantineDelete($this->Base[$grid][$ival][4],$this->Base[$grid][$ival][0],$this->Base[$grid][$ival][2]);
														}

														break;
													case'ch_delete':
														
														if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival)$api->QuarantineDelete($this->Base[$grid][$ival][4],$this->Base[$grid][$ival][0],$this->Base[$grid][$ival][2]);
														break;
													case'ch_blacklist':
														
														if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival){
															$api->QuarantineSet($this->Base[$grid][$ival][4],$this->Base[$grid][$ival][0],0);
														}

														break;
													case'ch_whitelist':
														
														if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival)$api->QuarantineAuthorize($this->Base[$grid][$ival][2]);
														$api->QuarantineSet($this->Base[$grid][$ival][4],$this->Base[$grid][$ival][0],1);
														break;
													case'bw_blacklist':
														
														if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival)$api->QuarantineSet($this->Base[$grid][$ival][4],$this->Base[$grid][$ival][0],0);
														break;
													case'bw_whitelist':
														
														if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival)$api->QuarantineSet($this->Base[$grid][$ival][4],$this->Base[$grid][$ival][0],1);
														break;
													case'g_authorize':
														
														if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival){
															$api->GLSet($this->Base[$grid][$ival][0],$this->Base[$grid][$ival][1],1);
														}

														break;
													case'g_delete':
														
														if(is_array($_REQUEST['sel_'.$grid]))foreach($_REQUEST['sel_'.$grid]as$ival){
															$api->GLDelete($this->Base[$grid][$ival][0],$this->Base[$grid][$ival][1],$this->Base[$grid][$ival][2]);
														}

														break;
											}

										}

									}

								}

								?>