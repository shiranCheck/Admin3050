﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	class cETRNGrid extends cStdGrid{
		function cETRNGrid($option){
			$this->Item=new cStdItem($option["SYNTAX"][0]["OBJECT"][0]["ATTRIBUTES"]["LENGTH"],$option["SYNTAX"][0]["OBJECT"][0]["SEPS"][0]["VALUE"]);
			$this->Filename=$_SESSION["INSTALLPATH"].securepath($option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"]);
			$this->Name=$option["SYNTAX"][0]["OBJECT"][0]["ATTRIBUTES"]["NAME"];
		}

		
		function loadFromBuffer(){
			
			if($this->Buffer){
				$ic=0;
				$lines=explode(CRLF,$this->Buffer);
				for($i=0;$i<count($lines);$i++){
					$item=array();
					
					if($lines[$i]=="")continue;
					
					if($this->Item->Length==1)$item[0]=$lines[$i]; else {
						$pom=$lines[$i];
						for($j=0;$j<$this->Item->Length-1;$j++){
							$pom=explode($this->Item->Seps[$j],$pom,2);
							$item[$j]=urldecode($pom[0]);
							$pom=$pom[1];
						}

						$item[$j]=urldecode($pom);
					}

					$items[$ic++]=$item;
				}

				$this->Data=$items;
			} else {
				$this->Data=$this->DefaultData;
			}

		}

		
		function saveToBuffer(){
			$buffer="";
			
			if($this->Data)foreach($this->Data as$i=>$val){
				
				if($this->Item->Length==1)$buffer.=$this->Data[$i][0].CRLF; else {
					for($j=0;$j<$this->Item->Length-1;$j++){
						$buffer.=urlencode($this->Data[$i][$j]).$this->Item->Seps[$j];
					}

					$buffer.=urlencode($this->Data[$i][$j]).CRLF;
				}

			}

			$this->Buffer=$buffer;
			return$buffer;
		}

	}

	?>