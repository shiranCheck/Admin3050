﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	class cIndexingQueueGrid extends cStdGrid{
		function cIndexingQueueGrid($option){
			@$item=$option["SYNTAX"][0]["OBJECT"][0];
			@$length=$item["ATTRIBUTES"]["LENGTH"];
			@$seps=$item["SEPS"][0]["VALUE"];
			@$this->showFunction=$item["ATTRIBUTES"]["SHOW"];
			
			if(!$this->showFunction)$this->showFunction=false;
			$this->Item=new cStdItem($length,$seps);
			$this->Filename=$_SESSION["INSTALLPATH"].securepath($option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"]);
			@$this->Name=$option["ATTRIBUTES"]["NAME"];
		}

		
		function getObjectJS($selector,$vindex,$aFunction=false,$option){
			global$skin_dir,$sGridItem,$alang;
			$arr["dname"]=$this->Name;
			$labels_jakub=array(0=>1,1=>0,2=>4,3=>5,4=>3,5=>2);
			@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
			@$dialog=$files["DIALOG"];
			@$file=$files["NAME"];
			@$comment=$files["COMMENT"];
			@$width=$option["ATTRIBUTES"]["WIDTH"];
			
			if(@!$width)$width=640;
			@$height=$option["ATTRIBUTES"]["HEIGHT"];
			
			if(@!$height)$height=480;
			
			if($this->Data)foreach($this->Data as$key2=>$val2){
				foreach($vindex as$key3=>$val3){
					$item=eregi_replace("([\\\'\"])","\\\\1",$val2[strtolower($val3)]);
					
					if($this->showFunction){
						$func=$this->showFunction;
						$arr["items"]["num"][$key2]['item']["num"][$key3]['value']=$func($item);
					} else $arr["items"]["num"][$key2]['item']["num"][$key3]['value']=str_replace(CRLF,";",$item);
					$arr["items"]["num"][$key2]['item']["num"][$key3]['label']='<a href="javascript:processdatagrid(\\\'edit\\\',\\\''.$dialog.'\\\',\\\''.$this->Name.'\\\',\\\'\\\','.$width.','.$height.',\\\'\\\',\\\''.$this->count.'\\\',0,\\\''.$key2.'\\\',\\\''.$this->uid.'\\\');">'.$arr["items"]["num"][$key2]['item']["num"][$key3]['value'].'</a>';
					$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=$arr["items"]["num"][$key2]['item']["num"][$key3]['value'];
				}

				$labels=explode("|",$alang["TASQueueItemForm_QueueList"]);
				$arr["items"]["num"][$key2]["cislo"]=$key2;
				
				if($this->Name.$key2==$sGridItem)$arr["items"]["num"][$key2]["selected"]=1;
			}

			$arr["selector"]=$selector;
			return template($skin_dir."dgridjs2.tpl",$arr);
		}

	}

	?>