﻿<?php
	
	function cfisselected($name){
		global$gObj;
		$selected=0;
		switch(strtolower($name)){
			case"ard":
				
				if($gObj->Base["action"]["accept"]==1||$gObj->Base["action"]["reject"]==1||$gObj->Base["action"]["delete"]==1||$gObj->Base["action"]["markspam"]!=0)$selected=1; else $selected=0;
				break;
			case"markgs":
				
				if($gObj->Base["action"]["markgenuine"]==1||$gObj->Base["action"]["markspam"]==1)$selected=1; else $selected=0;
				break;
			case"smtpresponsetext":
				
				if($gObj->Base["action"]["smtpresponse"]==1)$selected=1; else $selected=0;
				break;
			case"forward":
				
				if(isset($gObj->Base["action"]["forward"]))$selected=1; else $selected=0;
				break;
			case"score":
				case"priority":
					$selected=$gObj->Base[strtolower($name)]==0?false:
						true;
						break;
					case"respond":
						case"sendmessage":
							case"header":
								case"copymessage":
									case"headerfooter":
										case"extract":
											case"smartattach":
												case"db":
													$selected=0;
													
													if($gObj->Base["action"])
													if(array_key_exists(strtolower($name),$gObj->Base["action"])){
														$selected=1;
													}

													break;
										}

										return$selected;
									}

									?>