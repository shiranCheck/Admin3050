﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	class cTarpitGrid extends cStdGrid{
		function cTarpitGrid($name){
			$this->Name=$name;
			$this->Filename=$_SESSION["CONFIGPATH"]."tarpit.dat";
		}

		
		function loadFromBuffer(){
			$i=0;
			while(($pom=substr($this->Buffer,64*$i,64))&&$i*64<=strlen($this->Buffer)){
				$record=unpack("h1length/A54ip/areason/dexpire",$pom);
				$record['expirel']=date("Y/m/d H:i:s",floor(convertdelphidatetotime($record['expire'])));
				$record['host']='';
				$record['length']=hexdec($record['length']);
				$record['ip']=substr($record['ip'],0,$record['length']);
				$this->Data[]=$record;
				$i++;
			}

		}

		
		function saveToBuffer(){
			$return='';
			
			if($this->Data)foreach($this->Data as$val){
				$length=dechex(strlen($val['ip']));
				$reason=$val['reason']?$val['reason']:
				'U';
				$expire=$val['expire']?$val['expire']:
				converttimetodelphi(time()+1800);
				$record=pack("h1A54ad",$length,$val['ip'],$reason,$expire);
				$return.=$record;
			}

			return$return;
		}

	}

	
	class cRelayGrid extends cStdGrid{
		function cRelayGrid($name){
			$this->Item=new cStdItem(1,0);
			$this->Name=$name;
			$this->Filename=$_SESSION["CONFIGPATH"]."relay.dat";
		}

		
		function LoadFromAPI(){
			$api=createobject("api");
			$list=$api->GetProperty("C_Mail_Security_Relay_IPList");
			$items=explode(";",$list);
			for($i=0;$i<count($items)-1;$i++){
				$return[$i][0]=$items[$i];
				$this->APIIndex[]=$i;
			}

			return$return;
		}

		
		function loadFromSession(){
			$this->Data=$_SESSION["griddata"]["grids"][$this->uid][$this->Name];
			$this->APIIndex=$_SESSION["griddata"]["gridinfo"][$this->uid][$this->Name]["APIIndex"];
		}

		
		function Load($gObj,$array){
			
			if(!$array)$this->GetBuffer($gObj->Buffer);
			$this->LoadFromBuffer();
			$apiIPs=$this->LoadFromAPI();
			$fileIPs=$this->Data;
			
			if(!is_array($apiIPs))$apiIPs=array();
			
			if(!is_array($fileIPs))$fileIPs=array();
			$this->Data=array_merge($apiIPs,$fileIPs);
			
			if(!$array)$this->SaveToSession($gObj);
		}

		
		function saveToSession(){
			$_SESSION["griddata"]["grids"][$this->uid][$this->Name]=$this->Data;
			$_SESSION["griddata"]["gridinfo"][$this->uid][$this->Name]["APIIndex"]=$this->APIIndex;
		}

		
		function saveToBuffer(&$apibuffer){
			$buffer="";
			$apibuffer="";
			
			if($this->Data)foreach($this->Data as$i=>$val){
				
				if($this->Item->Length==1){
					
					if(is_array($this->APIIndex)&&in_array($i,$this->APIIndex))$apibuffer.=$this->Data[$i][0].";"; else $buffer.=$this->Data[$i][0].CRLF;
				} else {
					for($j=0;$j<$this->Item->Length-1;$j++){
						
						if(is_array($this->APIIndex)&&in_array($i,$this->APIIndex))$apibuffer.=$this->Data[$i][$j].$this->Item->Seps[$j]; else $buffer.=$this->Data[$i][$j].$this->Item->Seps[$j];
					}

					
					if(is_array($this->APIIndex)&&in_array($i,$this->APIIndex))$apibuffer.=$this->Data[$i][$j].";"; else $buffer.=$this->Data[$i][$j].CRLF;
				}

			}

			$this->Buffer=$buffer;
			return$buffer;
		}

		
		function Save(){
			$return=$this->saveToBuffer($iplist);
			
			if($return!=""){
				$fp=fopen($this->Filename,"w");
				fwrite($fp,$return,strlen($return));
				fclose($fp);
				unset($api);
			} else {
				@unlink($this->Filename);
			}

			$api=createobject("api");
			$api->SetProperty("C_Mail_Security_Relay_IPList",$iplist);
			$api->Save();
		}

	}

	?>