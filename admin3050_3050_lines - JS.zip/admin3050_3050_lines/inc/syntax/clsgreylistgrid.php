﻿<?php 
	require_once"inc/syntax/clsstdgrid.php";
	require_once"inc/api/gw.php";
	class cGreyListGrid extends cStdGrid{
		function cGreyListGrid($option,$name,$count=0,$type=false,$owner=false,$value=false){
			$this->Name=$name;
			$this->Item=new cStdItem(8,";SEP;SEP;SEP;SEP;SEP;SEP;");
			$this->type=intval($type);
			$this->owner=$owner;
			$this->value=$value;
			$this->counter=intval($count);
			
			if(!$this->counter){
				$this->counter=100;
			}

			$this->noLink=true;
		}

		
		function getBuffer(){
			global$api;
			$query=' ';
			$spam_settings=parsedatfile('spam.dat','spam2');
			$pending_hours=$spam_settings['SpamGLPending'];
			$t=time();
			$this->d_day=MerakGWAPI::unix2calendarDate($t);
			$this->d_time=MerakGWAPI::unix2calendarTime($t);
			$this->d_time=$this->d_time*60;
			$this->d_daytosecond=86400;
			$this->d_pending=$pending_hours*3600;
			$this->expired='AND ((ipCreationDate-%d)*%d+ (ipCreationTime - %d)+%d <=0) ';
			$this->pending='AND ((ipCreationDate-%d)*%d + (ipCreationTime - %d)+%d >0) ';
			$expired=sprintf($this->expired,$this->d_day,$this->d_daytosecond,$this->d_time,$this->d_pending);
			$pending=sprintf($this->pending,$this->d_day,$this->d_daytosecond,$this->d_time,$this->d_pending);
			switch($this->type){
				case 0:
					$query.="WHERE (ipAuthorized = '0') ".$pending;
					break;
				case 1:
					$query.="WHERE (ipAuthorized = '1') ";
					break;
				case 2:
					$query="WHERE (ipAuthorized = '0') ".$expired;
					break;
				case 3:
					$query="WHERE (ipAuthorized = '1' OR ipAuthorized = '0') ";
					break;
		}

		
		if($_SESSION['ACCOUNT']=='DOMAINADMIN'){
			
			if(strpos($this->owner,"@")!==false){
				$owner=substr($this->owner,0,strpos($this->owner,"@"));
			}

			$list=getdomainlist();
			$ownerquery='(';
			foreach($list as$dom){
				$ownerquery.=" ipEmail LIKE '".$owner."%".$dom['DOMAIN']."'";
				
				if($count++<count($list)-1)$ownerquery.=" OR ";
			}

			$ownerquery.=')';
			$query.="AND ".$ownerquery;
		}

		
		if($this->value){
			$query.=($query==' '?'WHERE':
			'AND')." ipAddress LIKE '".$this->value."%'";
		}

		$this->Buffer=$api->GLList('',$query,$this->counter);
	}

	
	function loadFromBuffer(){
		
		if($this->Buffer){
			$ic=0;
			$lines=explode(CRLF,$this->Buffer);
			for($i=0;$i<count($lines);$i++){
				$item=array();
				
				if($lines[$i]=="")continue;
				
				if($this->Item->Length==1)$item[0]=$lines[$i]; else {
					$pom=$lines[$i];
					for($j=0;$j<$this->Item->Length-1;$j++){
						$pom=explode($this->Item->Seps[$j],$pom,2);
						
						if($j==3){
							$day=$pom[0];
							$time=$pom[1];
							
							if($this->type==2){
								$item[2]=2;
							} else
							if($this->type==3){
								
								if(($day-$this->d_day)*$this->d_daytoseconds+($time-$this->d_time)+$this->d_pending<=0){
									$item[2]=2;
								}

							}

							$date=getDate(jdtounix($pom[0]));
							$hours=intval($pom[1]/3600).":";
							$time=$hours.intval(($pom[1]-$hours*3600)/60);
							$pom[0]=$date['year'].'-'.$date['mon'].'-'.$date['mday'].' '.$time;
						}

						$item[$j]=$pom[0];
						$pom=$pom[1];
					}

					$item[$j]=str_replace(";","",$pom);
				}

				$items[$ic++]=$item;
			}

			$this->Data=$items;
		}

	}

	
	function Save(){
		$noSaveActions=array(0=>'ch_whitelist',1=>'ch_blacklist',2=>'ch_delete',3=>'ch_deliver',4=>'ch_refresh',4=>'g_refresh',4=>'g_delete',5=>'g_authorize');
	}

	
	function getGridButtons($option,$type){
		global$alang,$_REQUEST,$formapi,$value;
		@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
		@$dialog=$files["DIALOG"];
		@$file=$files["NAME"];
		@$comment=$files["COMMENT"];
		
		if($option["BUTTONS"][0]["BUTTON"])foreach($option["BUTTONS"][0]["BUTTON"]as$bk=>$bv){
			unset($item);
			@$item["type"]=$bv["ATTRIBUTES"]["TYPE"];
			@$item["label"]=$alang[$bv["ATTRIBUTES"]["LABEL"]];
			@$width=$option["ATTRIBUTES"]["WIDTH"];
			
			if(@!$width)$width=640;
			@$height=$option["ATTRIBUTES"]["HEIGHT"];
			
			if(@!$height)$height=480;
			$item["onclick"]='processdatagrid("'.$item["type"].'","'.$dialog.'","'.$this->Name.'","",'.$width.','.$height.',"",'.$this->count.',0,\'\',\''.$this->uid.'\');';
			switch($item["type"]){
				case'removeall':
					case'g_authorize':
						case'g_delete':
							case'g_refresh':
								
								if($type=="datagrid")$nr='document.getElementById("noreload").value=1;'; else $nr='';
								$item["onclick"]=$nr.'document.getElementById("gridval").value="'.$this->Name.'";document.getElementById("gridaction").value="'.$item["type"].'";document.forms[0].submit();';
								break;
					}

					$items[]=$item;
				}

				return$items;
			}

		}

		?>