﻿<?php
	require_once"inc/syntax/clsitem.php";
	require_once"inc/include.php";
	class cXMLGrid extends cStdGrid{
		function getBuffer(){
			@$this->Buffer=simplexml_load_file($this->Filename);
		}

		
		function loadFromBuffer(){
			
			if($this->Buffer){
				$ic=0;
				@$xml=simplexml_load_string($this->Buffer);
				foreach($this->Buffer->GATEWAY as$gateway){
					foreach($gateway as$prop=>$val){
						$this->Data[$ic][strtolower($prop)]=strval($val);
					}

					$ic++;
				}

			}

		}

		
		function saveToBuffer(){
			$sBuffer="<LIST>\r\n";
			
			if($this->Data){
				foreach($this->Data as$aRecord){
					$sBuffer.="\t<GATEWAY>\r\n";
					foreach($aRecord as$property=>$value){
						$sBuffer.=($value!=='')?("\t\t<".strtoupper($property).">".htmlspecialchars($value)."</".strtoupper($property).">"):
						("\t\t<".strtoupper($property)." />");
					}

					$sBuffer.="\t</GATEWAY>\r\n";
				}

				$sBuffer.="</LIST>\r\n";
			}

			return$sBuffer;
		}

	}

	?>