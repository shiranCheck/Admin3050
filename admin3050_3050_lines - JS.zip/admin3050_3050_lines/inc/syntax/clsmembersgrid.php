﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	class cMembersGrid extends cStdGrid{
		function cMembersGrid($name,$group,$file,$option,$gridhandler){
			
			if(!$list_file=$option['ATTRIBUTES']['LIST_FILE']){
				$list_file='G_ListFile';
			}

			global$formapi;
			$this->Name=$name;
			$this->Item=new cMemberItem();
			
			if(substr_count($_REQUEST['value'],'@')>0){
				$val=explode("@",$_REQUEST['value']);
				$gname=$val[0];
				$domain=$val[1];
			} else {
				$gname=substr($formapi->EmailAddress,0,strpos($formapi->EmailAddress,"@"));
				$domain=$formapi->Domain;
			}

			$listfile=$formapi->GetProperty($list_file);
			
			if(($listfile[1]!=":")&&($listfile[1]!="\\")&&($listfile[0]!="/")){
				$this->Filename=$_SESSION['CONFIGPATH'].$listfile;
			} else {
				$this->Filename=$listfile;
			}

		}

		
		function loadFromBuffer(){
			$lines=explode(CRLF,$this->Buffer);
			for($i=0;$i<count($lines);$i++){
				
				if($lines[$i]=="")continue;
				$pom=explode(";",$lines[$i]);
				$items[$i]["member"]=$pom[0];
				$items[$i]["rights"]=$pom[1];
			}

			$this->Data=$items;
		}

		
		function saveToBuffer(){
			
			if($this->Data)foreach($this->Data as$data)$return.=$data["member"].";".$data["rights"].";".CRLF;
			return$return;
		}

		
		function Save(){
			global$formtype;
			$return=$this->saveToBuffer();
			
			if($return!=""){
				
				if(!file_exists($this->Filename)||$formtype=='edit'){
					$fp=fopen($this->Filename,"w+");
					fwrite($fp,$return);
					fclose($fp);
				} else return false;
			} else @unlink($this->Filename);
		}

		
		function getObjectJS($selector,$vindex,$aFunction=false,$option){
			global$skin_dir,$sGridItem,$alang;
			$rights=Array(0=>$alang["TStrings_pread"],3=>$alang["TStrings_pread"]." ".$alang["TStrings_pwrite"],4=>$alang["TStrings_pread"]." ".$alang["TStrings_pwrite"]." ".$alang["TStrings_pmodify"],1=>$alang["TStrings_pread"]." ".$alang["TStrings_pwrite"]." ".$alang["TStrings_pmodify"]." ".$alang["TStrings_pdelete"],2=>$alang["TStrings_powner"]);
			$arr["dname"]=$this->Name;
			@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
			@$dialog=$files["DIALOG"];
			@$file=$files["NAME"];
			@$comment=$files["COMMENT"];
			@$width=$option["ATTRIBUTES"]["WIDTH"];
			
			if(@!$width)$width=640;
			@$height=$option["ATTRIBUTES"]["HEIGHT"];
			
			if(@!$height)$height=480;
			
			if($this->Data)foreach($this->Data as$key2=>$val2){
				foreach($vindex as$key3=>$val3){
					$item=eregi_replace("([\\\'\"])","\\\\1",$val2[strtolower($val3)]);
					
					if($key3==1)$arr["items"]["num"][$key2]['item']["num"][$key3]['value']=$rights[str_replace(CRLF,";",$item)]; else $arr["items"]["num"][$key2]['item']["num"][$key3]['value']=str_replace(CRLF,";",$item);
					$arr["items"]["num"][$key2]['item']["num"][$key3]['label']='<a href="javascript:processdatagrid(\\\'edit\\\',\\\''.$dialog.'\\\',\\\''.$this->Name.'\\\',\\\'\\\','.$width.','.$height.',\\\'\\\',\\\''.$this->count.'\\\',0,\\\''.$key2.'\\\',\\\''.$this->uid.'\\\');">'.$arr["items"]["num"][$key2]['item']["num"][$key3]['value'].'</a>';
					$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=$arr["items"]["num"][$key2]['item']["num"][$key3]['value'];
				}

				$arr["items"]["num"][$key2]["cislo"]=$key2;
				
				if($this->Name.$key2==$sGridItem)$arr["items"]["num"][$key2]["selected"]=1;
			}

			$arr["selector"]=$selector;
			return template($skin_dir."dgridjs2.tpl",$arr);
		}

	}

	?>