﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	class cPublicFolderGrid extends cStdGrid{
		function cPublicFolderGrid($option,$name){
			global$api;
			$this->Name=$name;
			$this->Option=$option;
			$this->account=new MerakAccount();
			$this->gwapi=new MerakGWAPI();
			$this->gwapi->user=$api->GetProperty("C_GW_SuperUser");
			$this->gwapi->pass=$api->GetProperty("C_GW_SuperPass");
			$this->gwapi->login();
			$this->ownerList();
		}

		
		function ownerList(){
			$owners=$this->gwapi->ParseParamLine($this->gwapi->FunctionCall("getownerlist",$this->gwapi->sessid));
			foreach($owners as$owner)$this->owners[$owner['OWN_ID']]=$owner;
		}

		
		function createOwner($email){
			$id=$this->gwapi->FunctionCall("CreateUser",$this->gwapi->sessid,$email);
			$this->ownerList();
			return$id;
		}

		
		function loadFromBuffer(){
			$this->Data=$this->getGwGroups();
		}

		
		function saveToBuffer(){
			$aExisting=$this->getGwGroups();
			
			if($this->Data)foreach($this->Data as$key=>$group){
				
				if(isset($aExisting[$group['grp_id']])){
					
					if($aExisting[$group['grp_id']]!=$group)$this->editGroup($group,$group['grp_id']);
				} else {
					$this->addGroup($group);
				}

				unset($aExisting[$group['grp_id']]);
			}

			
			if($aExisting)foreach($aExisting as$toDelete)$this->deleteGroup($toDelete['grp_id']);
		}

		private
		function getGwGroups(){
			$groups=$this->gwapi->FunctionCall('GetGlobalGroupList',$this->gwapi->sessid);
			$groups=$this->gwapi->ParseParamLine($groups);
			
			if($groups)foreach($groups as$group)foreach($group as$property=>$value)$aReturn[$group['GRP_ID']][strtolower($property)]=$value;
			print_R($groups);
			return$aReturn;
		}

		private
		function getGroups($email){
			$groups=$this->gwapi->FunctionCall('GetGroupList',$this->gwapi->sessid,$email);
			$groups=$this->gwapi->ParseParamLine($groups);
			
			if($groups)foreach($groups as$key=>$group)foreach($group as$property=>$value)$aReturn[$key][strtolower($property)]=$value;
			return$aReturn[0];
		}

		public
		function deleteGroup($id){
			$this->gwapi->CloseGroup($id);
			$result=$this->gwapi->FunctionCall('DeleteGroup',$this->gwapi->sessid,$id);
			return$result;
		}

		public
		function addGroup($group){
			$email=$group['own_email'];
			
			if(!$owner=$this->owners[$email]){
				
				if($this->account->open($email))$own_id=$this->createOwner($email);
			} else $own_id=$owner['own_id'];
			$primarygroup=$this->getGroups($email);
			
			if($primarygroup)$groupid=$primarygroup['grp_id']; else $groupid='';
			
			if($group)foreach($group as$key=>$value)$group[$key]=$value;
			$group["grpown_id"]=$own_id;
			$group["grpglobal"]=1;
			$sParameters=$this->gwapi->CreateParamLine($group);
			$result=$this->gwapi->FunctionCall("AddGroup",$this->gwapi->sessid,$sParameters,$groupid);
			return$result;
		}

		public
		function editGroup($group,$id){
			foreach($group as$key=>$val)$group[$key]=$val;
			$sParameters=$this->gwapi->CreateParamLine($group);
			$result=$this->gwapi->FunctionCall("AddGroup",$this->gwapi->sessid,$sParameters,$id);
			return$result;
		}

	}

	?>