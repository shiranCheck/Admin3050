﻿<?php 
	require_once"inc/syntax/clswebservicegrid.php";
	class cSIPGatewaysGrid extends cWebserviceGrid{
		function cSIPGatewaysGrid($option){
			$this->Name="sip_gateways";
			$this->Filename=$_SESSION["INSTALLPATH"].securepath($option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"]);
		}

		
		function LoadFromXML(){
			
			if(file_exists($this->Filename)){
				$parser=new ParseXML();
				$xml=$parser->GetXMLTree($this->Filename);
				$items=$xml["GATEWAYS"][0]["GATEWAY"];
				unset($parser);
			}

			
			if($items)foreach($items as$index=>$host)
			if($host)foreach($host as$var=>$value)$return[$index][strtolower($var)]=$this->xml2arr($value,$var);
			$this->Data=$return;
		}

		
		function saveToXML(){
			
			if($this->Data)foreach($this->Data as$index=>$host)
			if($host)foreach($host as$var=>$value){
				
				if(!($var=='value'&&!isset($value[0]["VALUE"])))$return[$index][strtoupper($var)]=$this->arr2xml($value,strtolower($var));
			}

			return$return;
		}

		
		function Save(){
			$arr=$this->SaveToXML();
			$xml["GATEWAYS"][0]["GATEWAY"]=$arr;
			$parser=new ParseXML();
			$xmlstr=$parser->Array2XML($xml,true);
			
			if($xmlstr!=""){
				$fp=@fopen($this->Filename,'w');
				fwrite($fp,trim($xmlstr));
				@fclose($fp);
			} else @unlink($this->Filename);
		}

		
		function xml2arr($item,$key){
			$m=0;
			switch(strtolower($key)){
				case'rules':
					
					if(is_array($item)&&is_array($item[0]['ITEM'])){
						foreach($item[0]['ITEM']as$key=>$rule){
							$return[$key]["condition"]=$rule['CONDITION'][0]['VALUE'];
							$return[$key]["rewrite"]=$rule['REWRITE'][0]['VALUE'];
						}

					}

					break;
				case'targetusers':
					case'restrictedusers':
						
						if(is_array($item)&&trim($item[0]["VALUE"])!=""){
							$members=explode(";",$item[0]["VALUE"]);
							
							if($members)foreach($members as$member)
							if($member)$return[$m++]["member"]=$member;
						}

						break;
					case'value':
						default:
							
							if(is_array($item)&&trim($item[0]["VALUE"])!="")$return=$item[0]["VALUE"];
							break;
				}

				return$return;
			}

			
			function arr2xml($value,$key){
				switch(strtolower($key)){
					case'rules':
						
						if($value)foreach($value as$k=>$v){
							$return[0]["ITEM"][$k]["CONDITION"][0]["VALUE"]=$v["condition"];
							$return[0]["ITEM"][$k]["REWRITE"][0]["VALUE"]=$v["rewrite"];
						}

						break;
					case"restrictedusers":
						case"targetusers":
							
							if($value)foreach($value as$k=>$v)$return[0]["VALUE"].=$v["member"].";";
							break;
						default:
							$return[0]['VALUE']=$value;
							break;
				}

				return$return;
			}

		}

		?>