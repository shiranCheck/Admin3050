﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	class cNetworkGrid extends cStdGrid{
		function cNetworkGrid($option,$name){
			$this->Name=$name;
			$this->Option=$option;
		}

		
		function getBuffer(){
			com_load_typelib("Microsoft WMI Scripting V1.1 Library");
			$wmi=new COM("WinMgmts:{impersonationLevel=impersonate}");
			$registry=new COM(("WinMgmts:root/default:StdRegProv"));
			$adapters=$wmi->ExecQuery("SELECT * 
			FROM Win32_NetworkAdapter");
			foreach($adapters as$adapter){
				$adapterConfig=$wmi->ExecQuery("SELECT * FROM Win32_NetworkAdapterConfiguration WHERE Index = '".$adapter->Index."'");
				foreach($adapterConfig as$config){
					$configuration=$config;
					break;
				}

				$data=array();
				
				if($adapter->NetConnectionID&&$configuration->IPEnabled){
					$data['index']=$configuration->Index;
					$data['label']=iconv('','UTF-8',$adapter->NetConnectionID);
					$data['name']=iconv('','UTF-8',$adapter->Name);
					$data['status']=$configuration->IPEnabled;
					$data['dhcp']=$configuration->DHCPEnabled?1:
					0;
					
					if(!$data['dhcp']){
						
						if($data['status']){
							$data['ip']=$configuration->IPAddress(0);
							$data['mask']=$configuration->IPSubnet(0);
							$data['gateway']=$configuration->DefaultIPGateway(0);
						}

						
						if($configuration->DNSServerSearchOrder)foreach($configuration->DNSServerSearchOrder as$dns){
							$data['dnss'][]=$dns;
						}

						
						if($data['dnss'][0]){
							$data['primary_dns']=$data['dnss'][0];
							unset($data['dnss'][0]);
							$data['dns']=1;
						}

						
						if($data['dnss'][1]){
							$data['secondary_dns']=$data['dnss'][1];
							unset($data['dnss'][1]);
							$data['dns']=1;
						}

						unset($data['dnss']);
					}

					$this->Data[]=$data;
				}

			}

		}

		
		function loadFromBuffer(){
			return$this->Data;
		}

		
		function saveToBuffer(){
			
			if(is_array($this->Data)&&!empty($this->Data)){
				foreach($this->Data as$connection){
					
					if($connection['changed']){
						
						if(!$configuration){
							com_load_typelib("Microsoft WMI Scripting V1.1 Library");
							$wmi=new COM("WinMgmts:{impersonationLevel=impersonate}");
							$configurator=$wmi->ExecQuery("SELECT * 
			FROM Win32_NetworkAdapterConfiguration WHERE Index = ".$connection['index']);
							foreach($configurator as$config){
								$configuration=$config;
							}

						}

						
						if($connection['dhcp']){
							$configuration->EnableDHCP();
							
							if($connection['dns']){
								$configuration->SetDNSServerSearchOrder(array($connection['primary_dns'],$connection['secondary_dns']));
							} else {
								$configuration->SetDNSServerSearchOrder();
							}

						} else {
							$ips[]=$connection['ip'];
							$masks[]=$connection['mask'];
							$gateways[]=$connection['gateway'];
							$configuration->EnableStatic($ips,$masks);
							$configuration->SetGateways($gateways);
							$res=$configuration->SetDNSServerSearchOrder(array($connection['primary_dns'],$connection['secondary_dns']));
						}

					}

				}

			}

		}

	}

	?>