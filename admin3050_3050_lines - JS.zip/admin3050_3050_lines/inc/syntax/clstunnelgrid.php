﻿<?php
	require_once"inc/syntax/clsitem.php";
	require_once"inc/include.php";
	class cTunnelGrid extends cStdGrid{
		var$Item;
		var$Data;
		var$Itemlength;
		var$Name;
		var$Filename;
		var$Buffer;
		function cTunnelGrid($option){
			@$item=$option["SYNTAX"][0]["OBJECT"][0];
			@$length=$item["ATTRIBUTES"]["LENGTH"];
			@$seps=$item["SEPS"][0]["VALUE"];
			@$this->showFunction=$item["ATTRIBUTES"]["SHOW"];
			
			if(!$this->showFunction)$this->showFunction=false;
			$this->Item=new cStdItem($length,$seps);
			$filename=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"];
			$commentfile=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["COMMENT"];
			
			if($commentfile){
				$this->commentFile=$commentfile;
			}

			
			if(strpos($filename,'config/')!==false){
				$filename=str_replace('config/',$_SESSION['CONFIGPATH'],$filename);
			} else
			if(strpos($filename,'spam/')!==false){
				$filename=str_replace('spam/',$_SESSION['SPAMPATH'],$filename);
			} else {
				$filename=$_SESSION['INSTALLPATH'].securepath($filename);
			}

			$this->Filename=$filename;
			@$this->Name=$option["ATTRIBUTES"]["NAME"];
			
			if($option['DEFAULT'][0]['ITEM']){
				foreach($option['DEFAULT'][0]['ITEM']as$key=>$val){
					$this->DefaultData[$key][$val['FIELD'][0]['ATTRIBUTES']['INDEX']]=$val['FIELD'][0]['VALUE'];
				}

			}

		}

		
		function loadFromBuffer(){
			
			if($this->Buffer){
				$ic=0;
				$lines=explode(CRLF,$this->Buffer);
				for($i=0;$i<count($lines);$i++){
					
					if(!$lines[$i]){
						continue;
					}

					$item=array();
					$item[5]=0;
					$item[7]=0;
					$rules=array();
					$line=$lines[$i];
					$line=explode(',',$line);
					
					if(strpos($line[0],';')!==false){
						$v=explode(';',$line[0]);
						$item[0]=$v[0];
						$item[1]=$v[1];
					} else {
						$item[0]=$line[0];
						$item[1]='';
					}

					
					if(strpos($line[1],';')!==false){
						$v=explode(';',$line[1]);
						$item[2]=$v[0];
						$item[3]=$v[1];
					} else {
						$item[2]=$line[0];
						$item[3]='';
					}

					$v=explode(';',$line[2]);
					foreach($v as$key=>$val){
						
						if($val==5){
							$item[5]=1;
							continue;
						}

						
						if(preg_match('/(([0-9^:]*):([^;]*))/i',$val,$matches)){
							
							if($matches[2]==1||$matches[2]==0){
								$rules[]=$matches[1];
							}

							
							if($matches[2]==2){
								$item[7]=1;
								$item[8]=$matches[3];
							}

						}

					}

					$item[6]=implode(';',$rules);
					$item[9]=$line[3];
					ksort($item);
					$items[]=$item;
				}

				$this->Data=$items;
			} else {
				$this->Data=$this->DefaultData;
			}

		}

		
		function saveToBuffer(){
			$buffer="";
			
			if($this->Data)foreach($this->Data as$i=>$val){
				$buffer=$val[0];
				
				if($val[1]){
					$buffer.=';'.$val[1];
				}

				$buffer.=',';
				$buffer.=$val[2];
				
				if($val[3]){
					$buffer.=';'.$val[3];
				}

				$buffer.=',';
				$v=explode(';',$val[6]);
				foreach($v as$k=>$vl){
					
					if(preg_match('/((1|0):([^;]*))/i',$vl,$matches)){
						
						if($matches[2]==1||$matches[2]==0){
							$rules[]=$matches[1];
						}

					}

				}

				
				if($rules){
					$rules=implode(';',$rules);
					$buffer.=$rules.';';
				}

				
				if($val[5]){
					$buffer.='5;';
				}

				
				if($val[7]){
					$buffer.='2:'.$val[8];
				}

				$buffer.=',';
				$buffer.=$val[9];
				$buffer.=CRLF;
			}

			$this->Buffer=$buffer;
			return$buffer;
		}

	}

	?>