﻿<?php 
	require_once"inc/syntax/clswebservicegrid.php";
	class cPushAccountsGrid extends cWebserviceGrid{
		function cPushAccountsGrid($option,$name){
			$this->Name=$name;
			$this->Filename=$_SESSION["CONFIGPATH"].'push_accounts.xml';
		}

		
		function LoadFromXML(){
			
			if(file_exists($this->Filename)){
				$parser=new ParseXML();
				$this->xml=$parser->GetXMLTree($this->Filename);
				$items=$this->xml["ACCOUNTS"][0]["ACCOUNT"];
				unset($parser);
			}

			
			if($items)foreach($items as$index=>$account){
				$return[$index]=array();
				
				if($account)foreach($account as$var=>$value){
					
					if(strtolower($var)=='attributes'){
						$return[$index]=array_merge($return[$index],$this->xml2arr($value,$var));
					} else
					if(strtolower($var)!='value'){
						$return[$index][strtolower($var)]=$this->xml2arr($value,$var);
					}

				}

			}

			$this->Data=$return;
		}

		
		function saveToXML(){
			
			if($this->Data)foreach($this->Data as$index=>$host)
			if($host)foreach($host as$var=>$value){
				
				if($var=='id'||$var=='enabled'){
					$return[$index]["ATTRIBUTES"][$var]=$value;
				} else
				if(!($var=='value'&&!isset($value[0]["VALUE"])))$return[$index][strtolower($var)]=$this->arr2xml($value,strtolower($var));
			}

			return$return;
		}

		
		function Save(){
			$arr=$this->saveToXML();
			$parser=new ParseXML();
			unset($this->xml);
			$this->xml["accounts"][0]["account"]=$arr;
			$xmlstr=$parser->Array2XML($this->xml,0);
			
			if($xmlstr!=""){
				file_put_contents($this->Filename,$xmlstr);
			} else @unlink($this->Filename);
		}

		
		function xml2arr($item,$key){
			switch(strtolower($key)){
				case'attributes':
					foreach($item as$attr=>$value)$return[strtolower($attr)]=$value;
					break;
				case'folder':
					foreach($item as$index=>$deviceValue){
						$return[$index]=array();
						foreach($deviceValue as$var=>$value){
							
							if(strtolower($var)!='value'){
								$return[$index]=$this->xml2arr($value,$var);
							} else {
								$return[$index]['fdr_'.strtolower($var)]=$value;
							}

						}

					}

					break;
				case'folders':
					foreach($item as$index=>$deviceValue){
						$return[$index]=array();
						foreach($deviceValue as$var=>$value){
							
							if(strtolower($var)!='value')$return=$this->xml2arr($value,$var);
						}

					}

					break;
				case'notification':
					foreach($item as$index=>$deviceValue){
						foreach($deviceValue as$var=>$value){
							
							if(strtolower($var)!='value')$return[strtolower($key).'_'.strtolower($var)]=$this->xml2arr($value,$var);
							
							if(is_array($value)){
								
								if($value[0]['ATTRIBUTES']['SSL']){
									$return[strtolower($key).'_ssl']=1;
								}

							}

						}

					}

					break;
				case'device':
					foreach($item as$index=>$deviceValue){
						$return[$index]=array();
						foreach($deviceValue as$var=>$value){
							
							if(strtolower($var)=='attributes'){
								$return[$index]=array_merge($return[$index],$this->xml2arr($value,$var));
							} else
							if(strtolower($var)=='notification'){
								$return[$index]=array_merge($return[$index],$this->xml2arr($value,$var));
							} else
							if(strtolower($var)=='enabled'){
								$return[$index]["ATTRIBUTES"][$var]=$value;
							} else
							if(strtolower($var)!='value'){
								$return[$index][strtolower($var)]=$this->xml2arr($value,$var);
							}

						}

					}

					break;
				case'value':
					default:
						
						if(is_array($item)&&trim($item[0]["VALUE"])!="")$return=$item[0]["VALUE"];
						break;
			}

			return$return;
		}

		
		function arr2xml($value,$key){
			switch(strtolower($key)){
				case'device':
					
					if($value)foreach($value as$k=>$v){
						foreach($v as$kk=>$vv){
							
							if($kk=='enabled'){
								$return[$k]["ATTRIBUTES"]['enabled']=$vv;
							} else
							if(strpos($kk,'notification')===0){
								
								if(strtolower($kk)=='notification_ssl'){
									
									if($vv==1){
										$return[$k]["notification"][0]["transport"][0]["ATTRIBUTES"]["ssl"]=1;
									}

								} else $return[$k]["notification"][0][strtolower(str_replace('notification_','',$kk))][0]["VALUE"]=$vv;
							} else {
								$return[$k][strtolower($kk)]=$this->arr2xml($vv,$kk);
							}

						}

					}

					break;
				case'folders':
					
					if($value)foreach($value as$k=>$v){
						foreach($v as$kk=>$vv){
							
							if(strtolower($kk)=='fdr_value'){
								$return[0]["folder"][$k]['VALUE']=$vv;
							} else
							if(strtolower($kk)=='active'){
								$return[0]["folder"][$k]["ATTRIBUTES"][strtolower($kk)]=intval($vv);
							} else {
								$return[0]["folder"][$k]["ATTRIBUTES"][strtolower($kk)]=$vv;
							}

						}

					}

					break;
				default:
					$return[0]['VALUE']=$value;
					break;
		}

		return$return;
	}

}

?>