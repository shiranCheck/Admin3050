﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	class cScheduleGrid extends cStdGrid{
		function cScheduleGrid($name){
			global$remote;
			$this->Name=strtolower($name);
			
			if($this->Name=="ra_schedule"){
				$this->RA_Schedule=true;
				$remote->Open($_REQUEST['fileid']);
			}

			
			if($this->Name=="taskeventschedule"||$this->Name=="remotewatchdogschedule"){
				$aInfo=explode("|",$_REQUEST['fileid']);
				$aName=explode("-",$aInfo[1]);
				$this->scheduleBackupPointer=&$_SESSION['griddata']['grids'][$aInfo[2]][$aName[0]][$aName[1]];
				$this->Index=$aInfo[3];
				$this->TaskEvent=true;
			}

		}

		
		function LoadFromAPI(){
			global$days,$formapi,$remote,$_REQUEST;
			
			if($this->RA_Schedule)$schedule=$remote->GetSchedule($this->Name); else
			if($this->TaskEvent){
				$schedule=createobject('schedule');
				$schedule->SetProperty('s_backup',$this->scheduleBackupPointer[$this->Index]);
			} else $schedule=$formapi->GetSchedule($this->Name);
			for($i=0;$i<$schedule->Count;$i++){
				$schedule->Select($i);
				$item=array();
				$item["s_scheduletype"]=$schedule->GetProperty("s_scheduletype");
				$item["s_schedulewhen"]=$schedule->GetProperty("s_schedulewhen");
				
				if($item["s_scheduletype"]==0){
					$val=$schedule->GetProperty("s_every");
					$item["s_every"]=parseTime($val);
				}

				elseif($item["s_scheduletype"]==1){
					$val=$schedule->GetProperty("s_onceat");
					$item["s_onceat"]=parseTime($val);
				}

				
				if($item['s_schedulewhen']==1){
					$item["s_daysinmonth"]=$schedule->GetProperty("s_daysinmonth");
				}

				
				if($item['s_schedulewhen']==0){
					for($j=0;$j<7;$j++)$bin[$j]=!$schedule->GetProperty("s_weekdays_".$days[$j]);
					$item["s_weekdays"]=binary2decimal($bin);
				}

				$item["s_wholeday"]=$schedule->GetProperty("S_WholeDay");
				
				if($item["s_wholeday"]==0){
					$item["s_betweenfrom"]=parseTime($schedule->GetProperty("S_BetweenFrom"));
					$item["s_betweento"]=parseTime($schedule->GetProperty("S_BetweenTo"));
				}

				$items[]=$item;
			}

			$this->Data=$items;
		}

		
		function SaveToAPI(){
			global$days,$formapi,$remote;
			$schedule=createobject("schedule");
			
			if($this->Data)foreach($this->Data as$key=>$item){
				$schedule->Add();
				
				if($item["s_scheduletype"]==0){
					$schedule->SetProperty("s_every",intval(parseTime($item["s_every"],true)));
				}

				
				if($item["s_scheduletype"]==1)$schedule->SetProperty("s_onceat",intval(parseTime($item["s_onceat"],true)));
				
				if($item['s_schedulewhen']==0){
					$bin=decimal2binary($item["s_weekdays"]);
					for($j=0;$j<7;$j++){
						$schedule->SetProperty("s_weekdays_".$days[$j],!$bin[$j]);
					}

				}

				
				if($item['s_schedulewhen']==1){
					$schedule->SetProperty("s_daysinmonth",$item['s_daysinmonth']);
				}

				$schedule->SetProperty("s_scheduletype",$item["s_scheduletype"]);
				$schedule->SetProperty("s_schedulewhen",$item["s_schedulewhen"]);
				$schedule->SetProperty("s_wholeday",$item["s_wholeday"]);
				
				if(!$item["s_wholeday"]){
					$schedule->SetProperty("s_betweenfrom",intval(parseTime($item["s_betweenfrom"],true)));
					$schedule->SetProperty("s_betweento",intval(parseTime($item["s_betweento"],true)));
				}

			}

			
			if($this->RA_Schedule){
				$remote->SetSchedule($this->Name,$schedule);
				$remote->Save();
			} else
			if($this->TaskEvent){
				$this->scheduleBackupPointer[$this->Index]=$schedule->getProperty("s_backup");
			} else {
				$api=createobject("api");
				$api->SetSchedule($this->Name,$schedule);
				$api->Save();
			}

			unset($_SESSION["griddata"]["grids"][$this->uid][$this->Name]);
		}

		
		function load($gObj,$array){
			
			if(is_array($gObj->Base[$this->Name])){
				$this->LoadFromSession($gObj);
			} else {
				$this->LoadFromAPI();
			}

			
			if(!$array)$this->saveToSession($gObj);
		}

		
		function loadFromSession($gObj){
			$this->Data=$_SESSION["griddata"]["grids"][$this->uid][$this->Name];
		}

		
		function getObjectJS($selector,$vindex,$aFunction=false,$option){
			global$alang,$skin_dir,$sGridItem,$days,$dayslang;
			$arr["dname"]=$this->Name;
			@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
			@$dialog=$files["DIALOG"];
			@$file=$files["NAME"];
			@$comment=$files["COMMENT"];
			@$width=$option["ATTRIBUTES"]["WIDTH"];
			
			if(@!$width)$width=640;
			@$height=$option["ATTRIBUTES"]["HEIGHT"];
			
			if(@!$height)$height=480;
			
			if($this->Data)foreach($this->Data as$key2=>$val2){
				$label="";
				
				if($val2["s_scheduletype"]==0){
					
					if($val2["s_schedulewhen"]==2){
						$label.=$alang["TScheduleTaskForm_Disabled"];
					} else {
						$label.=sprintf($alang["TStrings_stseveryminutes"],$val2["s_every"]);
					}

				}

				elseif($val2["s_scheduletype"]==1){
					$label.=$alang["TScheduleTaskForm_Once"]." ".$val2["s_onceat"];
				}

				
				if(!$val2["s_wholeday"]&&$val2["s_schedulewhen"]!=2)$label.=" ".$alang["TScheduleTaskForm_Between"]." ".$val2["s_betweenfrom"]."-".$val2["s_betweento"];
				
				if($val2["s_schedulewhen"]!=2){
					$label.="[";
					$bin=decimal2binary($val2["s_weekdays"]);
					$count=0;
					$count2=0;
					for($i=0;$i<7;$i++){
						
						if(!$bin[$i])$count++;
					}

					for($i=0;$i<7;$i++){
						
						if(!$bin[$i]){
							$count2++;
							$label.=$alang[$dayslang[$i]];
							
							if($i!=6&&$count!=$count2)$label.=",";
						}

					}

					$label.="]";
				}

				$arr["items"]["num"][$key2]['item']["num"][0]['label']=$label;
				$arr["items"]["num"][$key2]['item']["num"][0]['sort']=$label;
				$arr["items"]["num"][$key2]["cislo"]=$key2;
				
				if($this->Name.$key2==$sGridItem)$arr["items"]["num"][$key2]["selected"]=1;
			}

			$arr["selector"]=$selector;
			return template($skin_dir."dgridjs2.tpl",$arr);
		}

		
		function Save(){
			$this->saveToAPI();
		}

	}

	?>