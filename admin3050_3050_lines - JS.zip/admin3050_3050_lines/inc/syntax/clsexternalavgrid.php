﻿<?php
	require_once"inc/syntax/clswebservicegrid.php";
	class cExternalAVGrid extends cWebserviceGrid{
		function cExternalAVGrid($option){
			$this->Name="ftp";
			$this->Filename=$_SESSION["INSTALLPATH"].securepath($option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"]);
		}

		
		function LoadFromXML(){
			
			if(file_exists($this->Filename)){
				$parser=new ParseXML();
				$xml=$parser->GetXMLTree($this->Filename);
				$items=$xml["FILTERS"][0]["FILTER"];
				unset($parser);
			}

			
			if($items)foreach($items as$index=>$av)
			if($av)foreach($av as$var=>$value){
				
				if(is_array($value[0]))$return[$index][strtolower($var)]=$value[0]['VALUE'];
			}

			$this->Data=$return;
		}

		
		function saveToXML(){
			
			if($this->Data[0])foreach($this->Data as$index=>$av)foreach($av as$var=>$value){
				
				if(!($var=='value'&&!isset($value[0]["VALUE"])))$return[$index][strtoupper($var)][0]['VALUE']=$value;
			}

			return$return;
		}

		
		function Save(){
			$arr=$this->SaveToXML();
			$xml["FILTERS"][0]["FILTER"]=$arr;
			$parser=new ParseXML();
			$xmlstr=$parser->Array2XML($xml,true);
			
			if($xmlstr!=""){
				$fp=@fopen($this->Filename,'w');
				fwrite($fp,trim($xmlstr));
				@fclose($fp);
			} else @unlink($this->Filename);
		}

	}

	?>