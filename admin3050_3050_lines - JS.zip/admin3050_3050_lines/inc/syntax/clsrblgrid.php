﻿<?php
	require_once"inc/syntax/clsstdgrid.php";
	class cRBLGrid extends cStdGrid{
		function cRBLGrid($option,$name){
			$this->Name=$name;
		}

		
		function LoadFromFile(){
			$lines=file($_SESSION['SPAMPATH'].'rules/rbl.list');
			foreach($lines as$line){
				$data=explode(";",$line,2);
				$pom['domain']=trim($data[1]);
				$pom['uid']=$data[0];
				$pom['selected']=self::getSelected($pom['uid']);
				$this->Data[]=$pom;
			}

		}

		static
		function getSelected($id){
			static$aSelectedRBL;
			
			if(!$aSelectedRBL){
				foreach($_SESSION['rawdata']as$pos=>$line){
					
					if(preg_match("#(score)([\s]{1,})(.*)([\s]{1,})(0)#i",$line,$matches))$aSelectedRBL[$matches[3]]=true; else $aSelectedRBL[$matches[3]]=false;
				}

			}

			
			if($aSelectedRBL[$id]===true)return 0; else return 1;
		}

		static
		function turnOnRBL($id){
			global$rawdata;
			foreach($_SESSION['rawdata']as$pos=>$line){
				
				if(preg_match("#(score)([\s]{1,})(".$id.")([\s]{1,})(0)#i",$line))$_SESSION['rawdata'][$pos]='';
			}

			$rawdata=$_SESSION['rawdata'];
		}

		static
		function turnOffRBL($id){
			global$rawdata;
			$_SESSION['rawdata'][]='score '.$id.' 0';
			$rawdata=$_SESSION['rawdata'];
		}

		
		function Load($gObj,$array){
			$this->LoadFromFile();
			
			if(!$array)$this->SaveToSession($gObj);
		}

		
		function Save(){
		}

		
		function getObjectJS($selector,$vindex,$function=false,$option){
			global$skin_dir,$sGridItem;
			$arr["dname"]=$this->Name;
			@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
			@$dialog=$files["DIALOG"];
			@$file=$files["NAME"];
			@$comment=$files["COMMENT"];
			@$width=$option["ATTRIBUTES"]["WIDTH"];
			
			if(@!$width)$width=640;
			@$height=$option["ATTRIBUTES"]["HEIGHT"];
			
			if(@!$height)$height=480;
			
			if($this->Data)foreach($this->Data as$key2=>$val2){
				foreach($vindex as$key3=>$val3){
					$item=eregi_replace("([\\\'\"])","\\\\1",$val2[strtolower($val3)]);
					
					if($this->showFunction){
						$func=$this->showFunction;
						$arr["items"]["num"][$key2]['item']["num"][$key3]['value']=$func($item);
					} else $arr["items"]["num"][$key2]['item']["num"][$key3]['value']=str_replace(CRLF,";",$item);
					
					if($function[$val3]){
						$function[$val3]['option']['ATTRIBUTES']['COUNT']=$key3;
						formfunctionvalues($function[$val3]['function'],$arr["items"]["num"][$key2]["num"][$key3],true,$function[$val3]['option']['ATTRIBUTES']['VINDEX'],$error,$function[$val3]['option']);
					}

					$arr["items"]["num"][$key2]["item"]["num"][$key3]['search']=$arr["items"]["num"][$key2]["item"]["num"][$key3]['value'];
					$arr["items"]["num"][$key2]["item"]["num"][$key3]["label"]=$arr["items"]["num"][$key2]["item"]["num"][$key3]['value'];
				}

				$arr["items"]["num"][$key2]["onclick2"]="javascript:setRBLAction(\'".$this->Name."\',".$key2.",\'".$this->Data[$key2]["uid"]."\');";
				$arr["items"]["num"][$key2]["cislo"]=$key2;
				$arr["items"]["num"][$key2]["selected"]=$this->Data[$key2]["selected"]?true:
				false;
				
				if($this->Name.$key2==$sGridItem)$arr["items"]["num"][$key2]["selected"]=1;
			}

			$arr["selector"]=$selector;
			return template($skin_dir."dgridjs2.tpl",$arr);
		}

	}

	?>