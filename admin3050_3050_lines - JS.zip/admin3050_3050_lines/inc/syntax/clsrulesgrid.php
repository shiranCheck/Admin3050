﻿<?php
	require_once"inc/syntax/clswebservicegrid.php";
	require_once"inc/syntax/cfvariablefunctions.php";
	class cRulesGrid extends cWebserviceGrid{
		function cRulesGrid($option,$name){
			global$formapi;
			$this->Name=$name;
			switch(strtolower($name)){
				case'u_rules':
					$this->variableName="U_RulesContentXML";
					$this->Filename=$formapi->GetProperty("u_fullmailboxpath").'filter.dat';
					$this->Fileid='user_rules';
					$this->Objectid=$formapi->EmailAddress;
					break;
				case'd_rules':
					$this->variableName="D_RulesContentXML";
					$this->Filename=$_SESSION['CONFIGPATH'].$formapi->Name.'/filter.dat';
					$this->Fileid='domain_rules';
					$this->Objectid=$formapi->Name;
					break;
				case'g_rules':
					$this->variableName="C_Mail_Filter_RulesContentXML";
					$this->Fileid=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"]["NAME"];
					$this->Objectid="filters";
					break;
				case'r_rules':
					$this->variableName="RA_RulesContentXML";
					$this->Filename=$formapi->GetProperty("RA_LeaveMessageFile").'rules.dat';
					$this->Fileid='remote_rules';
					$this->Objectid=$_REQUEST['value'];
					break;
		}

		$this->Fileid=addslashes($this->Fileid);
		$this->Objectid=addslashes($this->Objectid);
		$this->Filename=addslashes($this->Filename);
	}

	
	function getGridButtons($option,$type){
		global$alang,$_REQUEST,$formapi,$value;
		@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
		@$dialog=$files["DIALOG"];
		@$file=$files["NAME"];
		@$comment=$files["COMMENT"];
		
		if($option["BUTTONS"][0]["BUTTON"])foreach($option["BUTTONS"][0]["BUTTON"]as$bk=>$bv){
			unset($item);
			@$item["type"]=$bv["ATTRIBUTES"]["TYPE"];
			@$item["label"]=$alang[$bv["ATTRIBUTES"]["LABEL"]];
			@$width=$option["ATTRIBUTES"]["WIDTH"];
			
			if(@!$width)$width=640;
			@$height=$option["ATTRIBUTES"]["HEIGHT"];
			
			if(@!$height)$height=480;
			$item["onclick"]='processdatagrid("'.$item["type"].'","'.$dialog.'","'.$this->Name.'","",'.$width.','.$height.',"","'.$this->count.'","","","'.$this->uid.'");';
			switch($item["type"]){
				case'removeall':
					case'delete':
						case'up':
							case'ftpsyncnow':
								case'down':
									
									if($type=="datagrid")$nr='document.getElementById("noreload").value=1;'; else $nr='';
									$item["onclick"]=' '.$nr.'document.getElementById("gridval").value="'.$this->Name.'";document.getElementById("gridaction").value="'.$item["type"].'";document.forms[0].submit();';
									break;
								case'editfile':
									
									if(!$this->Filename)$this->Filename=$file;
									$item["onclick"]=' buttonedit("textfile","'.$this->Objectid.'","'.$this->Fileid.'","datagrid|'.$this->Name.'|'.$this->uid.'");';
									break;
						}

						$items[]=$item;
					}

					return$items;
				}

				
				function LoadFromXML(){
					global$formapi;
					$parser=new ParseXML();
					$xml=$parser->GetXMLTreeFromString($formapi->GetProperty($this->variableName));
					$items=$xml["CONTENTFILTER"][0]["FILTER"];
					unset($parser);
					
					if($items)foreach($items as$index=>$filter)
					if($filter)foreach($filter as$var=>$value)
					if($var!="VALUE"){
						
						if($var=="CONDITION"||$var=="READONLY"||$var=="ACTIVE"||$var=="TITLE")$return[$index][strtolower($var)]=$this->xml2arr($value,$var); else $return[$index]['action'][strtolower($var)]=$this->xml2arr($value,$var);
					}

					$this->Data=$return;
				}

				
				function saveToXML(){
					
					if($this->Data)foreach($this->Data as$index=>$filter)
					if($filter)foreach($filter as$var=>$value){
						
						if(!($var=='value'&&!isset($value[0]["VALUE"]))&&$var!="action")$return[$index][strtoupper($var)]=$this->arr2xml($value,strtolower($var));
						
						if($var=='action')
						if($value)foreach($value as$vkey=>$vval)$return[$index][strtoupper($vkey)]=$this->arr2xml($vval,strtolower($vkey));
					}

					return$return;
				}

				
				function Load($gObj,$array){
					$this->LoadFromXML();
					
					if(!$array)$this->SaveToSession($gObj);
				}

				
				function Save(){
					global$error,$formapi;
					$arr=$this->saveToXML();
					$xml["CONTENTFILTER"][0]["FILTER"]=$arr;
					$parser=new ParseXML();
					$xmlstr=$parser->Array2XML($xml,true);
					$formapi->SetProperty($this->variableName,$xmlstr);
				}

				
				function arr2xml($item,$key){
					switch(strtolower($key)){
						case'condition':
							
							if($item)foreach($item as$ckey=>$condition)
							if($condition)foreach($condition as$vkey=>$vval)
							if($vkey)$return[strtoupper($ckey)][strtoupper($vkey)]=$this->arr2xml($vval,$vkey);
							break;
						case'header':
							$ret='';
							
							if(is_array($item["val"])){
								foreach($item["val"]as$val){
									
									if($val['regex']){
										$ret.=$val["action"]."^".htmlspecialchars(trim($val["header"])).": ".htmlspecialchars(trim($val["regex_value"]))."|| ".htmlspecialchars(trim($val["header_value"]))."&#13;&#10;";
									} else {
										$ret.=$val["action"].htmlspecialchars(trim($val["header"])).": ".htmlspecialchars(trim($val["header_value"]))."&#13;&#10;";
									}

								}

								
								if($ret!='')$return[0]["VAL"][0]["VALUE"]=$ret;
							} else {
								$return[0]["VAL"][0]["VALUE"]=str_replace("\r\n","&#13;&#10;",$item["val"]);
							}

							break;
						case'headerfooter':
							case'copymessage':
								case'append':
									case'extract':
										case'respond':
											case'sendmessage':
												
												if($item)foreach($item as$vkey=>$vval)
												if($vkey)$return[0][strtoupper($vkey)]=$this->arr2xml($vval,$vkey);
												default:
													
													if(!is_array($item))$return[0]["VALUE"]=htmlspecialchars($item);
													break;
										}

										return$return;
									}

									
									function xml2arr($item,$key){
										switch(strtolower($key)){
											case'condition':
												
												if($item)foreach($item as$ckey=>$condition)
												if($condition)foreach($condition as$vkey=>$vval){
													$pom=$this->xml2arr($vval,$vkey);
													
													if($pom!="")$return[strtolower($ckey)][strtolower($vkey)]=$this->xml2arr($vval,$vkey);
												}

												break;
											case'header':
												
												if($item[0])foreach($item[0]as$vkey=>$vval){
													
													if($vkey!="VALUE")$return[strtolower($vkey)]=$this->xml2arr($vval,$vkey);
												}

												break;
											case'headerfooter':
												case'copymessage':
													case'append':
														case'extract':
															case'respond':
																case'sendmessage':
																	
																	if($item[0])foreach($item[0]as$vkey=>$vval)
																	if($vkey!="VALUE")$return[strtolower($vkey)]=$this->xml2arr($vval,$vkey);
																	default:
																		
																		if(is_array($item)&&trim($item[0]["VALUE"])!="")$return=$item[0]["VALUE"];
																		break;
															}

															return$return;
														}

														
														function getObjectJS($selector,$vindex,$aFunction=false,$option){
															global$skin_dir,$sGridItem,$alang;
															$parser=&new ParseXML();
															$condXML=$parser->GetXMLTree("xml/rules/conditions.xml");
															@$files=$option["SOURCE"][0]["FILE"][0]["ATTRIBUTES"];
															@$dialog=$files["DIALOG"];
															@$file=$files["NAME"];
															@$comment=$files["COMMENT"];
															@$width=$option["ATTRIBUTES"]["WIDTH"];
															
															if(@!$width)$width=640;
															@$height=$option["ATTRIBUTES"]["HEIGHT"];
															
															if(@!$height)$height=480;
															$arr["dname"]=$this->Name;
															
															if($this->Data)foreach($this->Data as$key2=>$val2){
																$cv=$val2["condition"][0];
																$item=array();
																
																if($cv["expression"]){
																	$item['selected']=1;
																	$item['type']="condition";
																	$item['ctype']="expression";
																	$item['index']=0;
																	$item['index2']=$cv['expression'];
																}

																
																if($cv["headertype"]){
																	$item['selected']=1;
																	$item['type']="condition";
																	$item['ctype']="headertype";
																	$item['index']=0;
																	$item['index2']=$cv['headertype'];
																}

																
																if(!$cv["headertype"]||!isset($cv["headertype"])&&!$cv["expression"]){
																	$item['type']="condition";
																	$item['ctype']="headertype";
																	$item['index']=0;
																	$item['index2']=0;
																}

																foreach($condXML["CONDITIONS"][0]["CONDITION"]as$condition){
																	
																	if(($item['ctype']=='headertype')&&($condition["ATTRIBUTES"]["HTYPE"]==$item['index2'])){
																		$ditem=$condition;
																	} else
																	if(($item['ctype']=='expression')&&($condition["ATTRIBUTES"]["EXPRESSION"]==$item['index2'])){
																		$ditem=$condition;
																	}

																}

																$text=cRulesEditGrid::getLinkText($val2['condition'],$item,$ditem,$andor,$count,$this->count,$this->uid,true);
																foreach($vindex as$key3=>$val3){
																	$val=strtolower($val3);
																	
																	if($val=="active")$item=$val2[$val3]?"Y":
																	"N"; else
																	if($val=="icon")$item=$this->getIcon($val2['action']); else $item=eregi_replace("([\\\'\"])","\\\\1",$val2[$val3]);
																	$arr["items"]["num"][$key2]['item']["num"][$key3]['value']=str_replace(CRLF,";",$item)?str_replace(CRLF,";",$item):
																	eregi_replace("([\\\'\"])","\\\\1",$text);
																	$arr["items"]["num"][$key2]['item']["num"][$key3]['label']='<a href="javascript:processdatagrid(\\\'edit\\\',\\\''.$dialog.'\\\',\\\''.$this->Name.'\\\',\\\'\\\','.$width.','.$height.',\\\'\\\',\\\''.$this->count.'\\\',0,\\\''.$key2.'\\\',\\\''.$this->uid.'\\\');">'.$arr["items"]["num"][$key2]['item']["num"][$key3]['value'].'</a>';
																	$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=$arr["items"]["num"][$key2]['item']["num"][$key3]['value'];
																}

																$arr["items"]["num"][$key2]["cislo"]=$key2;
																
																if($this->Name.$key2==$sGridItem)$arr["items"]["num"][$key2]["selected"]=1;
															}

															$arr["selector"]=$selector;
															return template($skin_dir."dgridjs2.tpl",$arr);
														}

														
														function getIcon($data){
															global$skin_dir;
															$icon=1;
															
															if($data['accept'])$icon=1;
															
															if($data['reject'])$icon=0;
															
															if($data['delete'])$icon=2;
															
															if($data['markspam']!=0)$icon=3;
															$icon="<img src=\"".$skin_dir."images/as_".$icon.".gif\"/>";
															return$icon;
														}

														
														function loadFromSession(){
															$this->Data=$_SESSION["griddata"]["grids"][$this->uid][$this->Name];
														}

														
														function saveToSession(){
															$_SESSION["griddata"]["grids"][$this->uid][$this->Name]=$this->Data;
														}

													}

													
													class cRulesConditionsGrid extends cStdGrid{
														function cRulesConditionsGrid($option,$name){
															$this->Name=$name;
														}

														
														function Load($gObj,$array){
															global$alang;
															$parser=&new ParseXML();
															$actionXML=$parser->GetXMLTree("xml/rules/conditions.xml");
															$count=0;
															$this->HeaderType=array();
															$this->Expression=array();
															
															if($gObj->Base[strtolower($this->Name)])foreach($gObj->Base[strtolower($this->Name)]as$ck=>$cv){
																
																if($cv["expression"])$this->Expression[$ck]=$cv["expression"];
																
																if($cv["headertype"])$this->HeaderType[$ck]=$cv["headertype"];
																
																if(!$cv["headertype"]&&!$cv["expression"])$this->HeaderType[$ck]=0;
															}

															foreach($actionXML["CONDITIONS"][0]["CONDITION"]as$akey=>$aval){
																$sText='';
																
																if(@in_array($aval["ATTRIBUTES"]["HTYPE"],$this->HeaderType)&&isset($aval["ATTRIBUTES"]["HTYPE"])){
																	$item['selected']=1;
																	$item['type']="condition";
																	$item['ctype']="headertype";
																	$item['index']=0;
																	$item['index2']=$aval["ATTRIBUTES"]["HTYPE"];
																} else
																if(@in_array($aval["ATTRIBUTES"]["EXPRESSION"],$this->Expression)&&isset($aval["ATTRIBUTES"]["EXPRESSION"])){
																	$item['selected']=1;
																	$item['type']="condition";
																	$item['ctype']="expression";
																	$item['index']=0;
																	$item['index2']=$aval["ATTRIBUTES"]["EXPRESSION"];
																} else {
																	$item['selected']=0;
																	$item['type']='condition';
																	
																	if(isset($aval["ATTRIBUTES"]["HTYPE"])){
																		$item['ctype']="headertype";
																		$item['index2']=$aval["ATTRIBUTES"]["HTYPE"];
																		$item['index']=-1;
																	} else {
																		$item['ctype']="expression";
																		$item['index2']=$aval["ATTRIBUTES"]["EXPRESSION"];
																		$item['index']=-1;
																	}

																}

																$sText=$alang[$aval["ATTRIBUTES"]["TEXT"]];
																$item['action']=$item['selected']?"cfdel":
																"cfadd";
																$item['description']='<div style="whitespaces:nowrap;" id="cf_condition_'.$count.'" onclick="selectcfitem(0,this);" class="unselectedcf" style="width:100%;height:100%;" ondblclick="setCFAction('.$item['index'].','.$item['index2'].',\'cfadd\',\'condition\',\''.$item['ctype'].'\');">'.str_replace("&lt;a&gt;%s&lt;/a&gt;",$alang[$aval["ATTRIBUTES"]["LINK"]],$sText).'</div>';
																$this->Data[$count++]=$item;
															}

														}

														
														function getObjectJS($selector,$vindex){
															global$skin_dir,$sGridItem;
															$arr["dname"]=$this->Name;
															
															if($this->Data)foreach($this->Data as$key2=>$val2){
																foreach($vindex as$key3=>$val3){
																	$val=strtolower($val3);
																	$item=eregi_replace("([\\\'\"])","\\\\1",$val2[$val3]);
																	$arr["items"]["num"][$key2]['item']["num"][$key3]['label']=str_replace(CRLF,";",$item);
																	$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=str_replace(CRLF,";",$item);
																}

																$arr["items"]["num"][$key2]["cislo"]=$key2;
																$arr["items"]["num"][$key2]["index"]=$val2["index"];
																$arr["items"]["num"][$key2]["index2"]=$val2["index2"];
																$arr["items"]["num"][$key2]["type"]=$val2["type"];
																$arr["items"]["num"][$key2]["ctype"]=$val2["ctype"];
																$arr["items"]["num"][$key2]["action"]=$val2["action"];
																
																if($val2["selected"]==1)$arr["items"]["num"][$key2]["selected"]=1; else $arr["items"]["num"][$key2]["selected"]=0;
															}

															$arr["selector"]=$selector;
															$arr["onclick"]=1;
															return template($skin_dir."dgridjs2.tpl",$arr);
														}

														
														function Save(){
														}

														
														function loadFromSession(){
															$this->Data=$_SESSION["griddata"]["grids"][$this->uid][$this->Name];
														}

														
														function saveToSession(){
															$_SESSION["griddata"]["grids"][$this->uid][$this->Name]=$this->Data;
														}

													}

													
													class cRulesActionsGrid extends cStdGrid{
														function cRulesActionsGrid($option,$name){
															$this->Name=$name;
														}

														
														function Load($gObj,$array){
															global$alang;
															$parser=&new ParseXML();
															$actionXML=$parser->GetXMLTree("xml/rules/actions.xml");
															$count=0;
															foreach($actionXML["ACTIONS"][0]["ACTION"]as$aval){
																
																if($gObj->Base[strtolower($this->Name)][strtolower($aval["ATTRIBUTES"]["NAME"])])$item["selected"]=1; else $item['selected']=cfisselected($aval["ATTRIBUTES"]["NAME"]);
																$item['action']=$item['selected']?"cfdel":
																"cfadd";
																$item['description']=str_replace("&lt;a&gt;%s&lt;/a&gt;",$alang[$aval["ATTRIBUTES"]["LINK"]],$alang[$aval["ATTRIBUTES"]["TEXT"]]);
																$item['type']="action";
																$item['ctype']="";
																$item['index']="\'".$aval["ATTRIBUTES"]["NAME"]."\'";
																$item['index2']=$item['index'];
																$this->Data[$count++]=$item;
															}

														}

														
														function getObjectJS($selector,$vindex){
															global$skin_dir,$sGridItem,$gObj;
															$arr["dname"]=$this->Name;
															
															if($this->Data)foreach($this->Data as$key2=>$val2){
																foreach($vindex as$key3=>$val3){
																	$val=strtolower($val3);
																	$item=eregi_replace("([\\\'\"])","\\\\1",$val2[$val3]);
																	$arr["items"]["num"][$key2]['item']["num"][$key3]['label']=str_replace(CRLF,";",$item);
																	$arr["items"]["num"][$key2]['item']["num"][$key3]['sort']=str_replace(CRLF,";",$item);
																}

																$arr["items"]["num"][$key2]["cislo"]=$key2;
																$arr["items"]["num"][$key2]["index"]=$val2["index"];
																$arr["items"]["num"][$key2]["index2"]=$val2["index2"];
																$arr["items"]["num"][$key2]["type"]=$val2["type"];
																$arr["items"]["num"][$key2]["ctype"]=$val2["ctype"];
																$arr["items"]["num"][$key2]["action"]=$val2["action"];
																
																if($val2["selected"]==1)$arr["items"]["num"][$key2]["selected"]=1; else $arr["items"]["num"][$key2]["selected"]=0;
															}

															$arr["selector"]=$selector;
															$arr["onclick"]=1;
															return template($skin_dir."dgridjs2.tpl",$arr);
														}

														
														function Save(){
														}

													}

													
													class cRulesEditGrid extends cStdGrid{
														function cRulesEditGrid($option,$name){
															$this->Name=$name;
														}

														
														function Load($gObj,$array){
															global$alang;
															$parser=&new ParseXML();
															$actionXML=$parser->GetXMLTree("xml/rules/actions.xml");
															$conditionXML=$parser->GetXMLTree("xml/rules/conditions.xml");
															
															if($gObj->Base["condition"])foreach($gObj->Base["condition"]as$ck=>$cv){
																$item="";
																
																if($cv["expression"]){
																	$item['selected']=1;
																	$item['type']="condition";
																	$item['ctype']="expression";
																	$item['index']=$ck;
																	$item['index2']=$cv['expression'];
																}

																
																if($cv["headertype"]){
																	$item['selected']=1;
																	$item['type']="condition";
																	$item['ctype']="headertype";
																	$item['index']=$ck;
																	$item['index2']=$cv['headertype'];
																}

																
																if(!$cv["headertype"]||!isset($cv["headertype"])&&!$cv["expression"]){
																	$item['type']="condition";
																	$item['ctype']="headertype";
																	$item['index']=$ck;
																	$item['index2']=0;
																}

																$val=0;
																foreach($conditionXML["CONDITIONS"][0]["CONDITION"]as$cval){
																	
																	if($val)break;
																	
																	if($cval["ATTRIBUTES"]["EXPRESSION"]==$item['index2']&&$item['ctype']=='expression')$val=$cval;
																	
																	if(($cval["ATTRIBUTES"]["HTYPE"]==$item['index2']&&$item['ctype']=='headertype'))$val=$cval;
																}

																$andor=$gObj->Base["condition"][$item['index']]["and"]==1?mb_strtolower($alang["TStrings_hland"],'UTF-8'):
																mb_strtolower($alang["TStrings_hlor"],'UTF-8');
																
																if($item['index']==0)$andor=""; else $andor='<a style="display:inline;width:30px;" href="javascript:processdatagrid(\'cfitem\',\'cf_andor\',\'condition\','.$item['index'].',640,480,\'\','.$this->count.',\'\',\'\',\''.$this->uid.'\');">'.$andor.'</a>';
																$item['bracketsleft']=$gObj->Base["condition"][$item['index']]["bracketsleft"];
																$item['bracketsright']=$gObj->Base["condition"][$item['index']]["bracketsright"];
																$item['logicalnot']=$gObj->Base["condition"][$item['index']]["logicalnot"];
																$item['description']=self::getLinkText($gObj->Base["condition"],$item,$val,$andor,$item['index'],$this->count,$this->uid);
																$this->Data[$item['index']]=$item;
															}

															$clength=$clength0=count($this->Data);
															foreach($actionXML["ACTIONS"][0]["ACTION"]as$aval){
																$item="";
																
																if($gObj->Base["action"][strtolower($aval["ATTRIBUTES"]["NAME"])])$item["selected"]=1; else {
																	$item['selected']=cfisselected($aval["ATTRIBUTES"]["NAME"]);
																	
																	if(!$item['selected'])continue;
																}

																
																if($clength==$clength0)$andor=""; else $andor=mb_strtolower($alang["TStrings_hland"],'UTF-8');
																$item['type']="action";
																$item['ctype']="cfitem";
																$item['index']="'".$aval["ATTRIBUTES"]["NAME"]."'";
																$item['index2']=0;
																$item['description']=self::getLinkText($gObj->Base["action"],$item,$aval,$andor,$clength,$this->count,$this->uid);
																$this->Data[]=$item;
																$clength++;
															}

															@ksort($this->Data);
														}

														static public
														function getLinkText($base,$item,$ditem,$andor,$count,$itemCount,$uid,$forceOnlyText=false){
															global$alang,$sGridItem;
															$name=strtolower($ditem["ATTRIBUTES"]["NAME"]);
															$text=$alang[$ditem["ATTRIBUTES"]["TEXT"]];
															$link=$alang[$ditem["ATTRIBUTES"]["LINK"]];
															$index=$item['index'];
															switch($name){
																case"hpriority":
																	$labels=explode("|",$alang["TContentPriorityForm_PriorityList"]);
																	$value=$labels[$base[$item['index']]['contain']-1];
																	break;
																case'esize':
																	$labels=explode("|",$alang["TConfigForm_MaxMailSizeEditUnits"]);
																	$val=$base[$item['index']]['messagesize'];
																	$opt["ATTRIBUTES"]["SAVEUNIT"]=0;
																	$units=formfunctionvalues('u_bytes',$val,true,$name,&$message,$opt,&$error);
																	$value=$base[$item['index']]['messagesizesmaller']?'< ':
																		'> ';
																		$value.=$val?$val:
																			0;
																			$value.=' '.$labels[$units-1];
																			break;
																		case"priority":
																			$labels=explode("|",$alang["TContentPriorityForm_PriorityList"]);
																			$value=$labels[$base[$name]-1];
																			$index="'donotmove'";
																			break;
																		case"spamscore":
																			$value=$base[$item['index']]['messagesizesmaller']?"<":
																				">";
																				$value.=' '.$base[$item['index']]['messagesize']/100;
																				break;
																			case"ard":
																				
																				if($base['reject']==1)$value=$alang['TStrings_messageactionreject'];
																				
																				if($base['accept']==1)$value=$alang['TStrings_messageactionaccept'];
																				
																				if($base['delete']==1)$value=$alang['TStrings_messageactiondelete'];
																				
																				if($base['markspam']==1)$value=$alang['TStrings_messageactionspam'];
																				
																				if($base['markspam']==2)$value=$alang['TStrings_messageactionquarantine'];
																				$index="'donotmove'";
																				break;
																			case"markgs":
																				
																				if($base['markspam']==2)$value=$alang['TStrings_messageactionquarantine'];
																				
																				if($base['markspam']==1)$value=$alang['TStrings_messageactionspam'];
																				$index="'donotmove'";
																				break;
																			case"copymessage":
																				$value=$base[$name]["copymessageto"];
																				
																				if(!$value)$value=$link;
																				break;
																			case"forward":
																				
																				if($name=="forward")$value=$base[$name];
																				
																				if(!$value)$value=$link;
																				$index="'donotmove'";
																				break;
																			case"execute":
																				$value=$base['executefilter'];
																				
																				if(!$value)$value=$link;
																				$index="'donotmove'";
																				break;
																			case"respond":
																				$value=$link;
																				break;
																			case"smtpresponse":
																				$value=$base["smtpmessage"];
																				
																				if(!$value)$value=$link;
																				$index="'donotmove'";
																				break;
																			case"append":
																				$value=$base[$name]["appendtext"];
																				
																				if(!$value)$value=$link;
																				break;
																			case"extract":
																				$value=$base[$name]["extractto"];
																				
																				if(!$value)$value=$link;
																				break;
																			case"append":
																				$value=$base[$name]["appendtext"];
																				break;
																			case"flags":
																				$index="'donotmove'";
																				$value=$link;
																				break;
																			case"sendmessage":
																				case"header":
																					case"headerfooter":
																						case"ltime":
																							case"spam":
																								$value=$link;
																								break;
																							case"copytofolder":
																								case"movetofolder":
																									$value=$base[$name];
																									
																									if(!$value)$value=$link;
																									$index="'donotmove'";
																									break;
																								case"ipsender":
																									default:
																										$not_val='';
																										
																										if(is_numeric($item['index'])){
																											$NotArray=array(8=>0,9=>1,4=>0,5=>1,10=>0,11=>1,2=>0,6=>1,3=>0,7=>1,0=>0,1=>1,13=>1,12=>0);
																											$not_val=$NotArray[$base[$item['index']]["containtype"]];
																											$not_val=$not_val?($alang['TContentHeader_NotBox'].' '):
																												'';
																											}

																											
																											if(isset($base[$item['index']]["contain"]))$value=$not_val.$base[$item['index']]["contain"]; else $value=$link;
																											break;
																								}

																								
																								if($forceOnlyText){
																									return str_replace("&lt;a&gt;%s&lt;/a&gt;",$value?$value:
																									$alang[$ditem["ATTRIBUTES"]["LINK"]],$text);
																								}

																								$lb="";
																								$rb="";
																								for($lbc=0;$lbc<$item['bracketsleft'];$lbc++)$lb.="(";
																								for($rbc=0;$rbc<$item['bracketsright'];$rbc++)$rb.=")";
																								$ln=$item['logicalnot']?" ! ":
																								"";
																								
																								if($item['focus'])$class="selectedcf"; else $class="unselectedcf";
																								$divb='<div id="cf_edit_'.$count.'" onclick="selectcfitem(1,this,'.$item['index'].','.$item['index2'].',\''.$item['type'].'\',\''.$item['ctype'].'\');" class="'.$class.'" style="width:100%;height:100%;">';
																								$dive='</div>';
																								
																								if(!$ditem["ATTRIBUTES"]["LINK"])$js='return false;'; else $js='';
																								$return=str_replace("&lt;a&gt;%s&lt;/a&gt;",'<a style="display:inline;" href="javascript:processdatagrid(\''.$item['ctype'].'\',\''.getfilevarpath($ditem['ATTRIBUTES']['DIALOG'],"").'\',\''.$item['type'].'\','.$index.',640,480,\'\','.$itemCount.',\'\',\'\',\''.$uid.'\');'.$js.'" >'.(isset($value)?$value:
																								$alang[$ditem["ATTRIBUTES"]["LINK"]]).'</a>',$text);
																								return$divb.$andor." ".$lb.$ln.$return.$rb.$dive;
																							}

																							
																							function getObjectJS($selector,$vindex){
																								global$skin_dir,$sGridItem;
																								$arr["dname"]=$this->Name;
																								
																								if($this->Data)foreach($this->Data as$key2=>$val2){
																									$arr["items"]["num"][$key2]['item']["num"][0]['label']="";
																									$arr["items"]["num"][$key2]['item']["num"][0]['sort']="";
																									$arr["items"]["num"][$key2]['item']["num"][1]['label']=eregi_replace("([\\\'\"])","\\\\1",str_replace(CRLF,";",$val2["description"]));
																									$arr["items"]["num"][$key2]['item']["num"][1]['sort']=eregi_replace("([\\\'\"])","\\\\1",str_replace(CRLF,";",$val2["description"]));
																									$arr["items"]["num"][$key2]["cislo"]=$key2;
																									$arr["items"]["num"][$key2]["index"]=$val2["index"];
																									$arr["items"]["num"][$key2]["index2"]=$val2["index2"];
																									$arr["items"]["num"][$key2]["type"]=$val2["type"];
																									$arr["items"]["num"][$key2]["ctype"]=$val2["ctype"];
																									$arr["items"]["num"][$key2]["ctype"]=$val2["focu"];
																								}

																								return template($skin_dir."dgridjs2.tpl",$arr);
																							}

																							
																							function getGridButtons($option,$type){
																								global$alang;
																								$item["onclick"]='cfbuttons("cf_logicalnot");';
																								$item["label"]="!";
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cf_leftbracket");';
																								$item["label"]="(";
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cf_rightbracket");';
																								$item["label"]=")";
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cf_up");';
																								$item["label"]=$alang["TStrings_buttonup"];
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cf_down");';
																								$item["label"]=$alang["TStrings_buttondown"];
																								$item["type"]="edit";
																								$items[]=$item;
																								$item["onclick"]='cfbuttons("cfdel2");';
																								$item["label"]=$alang["TConfigForm_DeleteItem"];
																								$item["type"]="edit";
																								$items[]=$item;
																								return$items;
																							}

																							
																							function Save(){
																							}

																						}

																						?>