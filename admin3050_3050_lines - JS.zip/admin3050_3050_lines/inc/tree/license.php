﻿<?php
	require_once'inc/licence/ltranslatetables.php';
	function processLicences($showall){
		global$api,$xml;
		$api=createobject("api");
		$xml=$api->GetProperty("C_License_XML");
		$xmlparse=&new ParseXML();
		$xml=$xmlparse->GetXMLTreeFromString($xml);
		return getProducts($xml,$showall);
	}

	
	function getProducts($xml,$showall){
		global$api,$alang,$rsa,$T_T2;
		
		if($xml["LICENSE"][0]["PRODUCTS"][0]["ITEM"])foreach($xml["LICENSE"][0]["PRODUCTS"][0]["ITEM"]as$product){
			$prod=$product["PRODUCT"][0]["VALUE"];
			$id=$T_T2[$prod];
			$item['product']=$alang["TStrings_cl_".$id];
			
			if($product["DEMO"][0]["VALUE"]){
				$item['type']=(string)$alang["TStrings_clicenseeval"];
			} else {
				$item['type']=(string)$alang["TStrings_cfull"];
			}

			$item['accounts']=(string)$product["ACCOUNTS"][0]["VALUE"]==0?$alang["TStrings_cunlimited"]:
			$product["ACCOUNTS"][0]["VALUE"];
			$delphi_today=converttimetodelphi(mktime());
			$using_time=$delphi_today-$product['CREATIONDATE'][0]['VALUE'];
			$item['renewal']=(string)ceil($product['EXPIRESAFTER'][0]['VALUE']-$using_time)." ".$alang["TStrings_cldays"];
			$item['exceed']="";
			$items[$id]=$item;
		}

		$ret=$items;
		return$ret;
	}

	
	function getAllProducts($items,$showall,$xml){
		global$api,$alang,$registered,$T_T;
		$pids=array("mailserver","webmail","ftp","spamengine","antivirus","instantmessaging","calendaring","syncml","sip","caldav","antispamlive","loganalyzer","activesync");
		
		if(!$items){
			$registered=false;
			foreach($pids as$pid){
				$item['product']=$alang["TStrings_cl_".$pid];
				$item['type']=$alang["TStrings_clicenseeval"];
				$item['accounts']=$alang["TStrings_cunlimited"];
				$delphi_today=converttimetodelphi(mktime(0,0,0));
				$using_time=$delphi_today-$xml['LICENSE'][0]['TIMESTAMP'][0]['VALUE'];
				$item['expiresin']=(string)ceil(30-$using_time)." ".$alang["TStrings_cldays"];
				$item['renewal']=$item['expiresin'];
				$item['exceed']="";
				$items[$pid]=$item;
			}

			return$items;
		} else {
			$registered=true;
			foreach($pids as$pid){
				
				if(!$items[$pid]){
					$item['product']=$alang["TStrings_cl_".$pid];
					$item['type']=$alang["TStrings_clicenseeval"];
					$item['accounts']=$alang["TStrings_cunlimited"];
					$delphi_today=converttimetodelphi(mktime(0,0,0));
					$using_time=$delphi_today-$xml['LICENSE'][0]['TIMESTAMP'][0]['VALUE'];
					$item['expiresin']=$alang["TStrings_clicenseeval"];
					$item['renewal']=$item['expiresin'];
					$item['exceed']="";
					
					if($showall)$items[]=$item;
				}

			}

			return$items;
		}

	}

	
	function xmltotext($xml){
		return$text;
	}

	?>