﻿<?php 
	require_once("inc/formvariables.php");
	function getstats(){
		global$alang;
		checksession();
		$stat=createobject("statistics");
		$services=Array("SMTP","POP3","IMAP","IM","GW","FTP","Control","SIP");
		$i=0;
		foreach($services as$v){
			$stat->Poll($v);
			$i++;
			unset($item);
			$item["service"]=$v;
			$item["even"]=$i%2;
			$item["running"]=0;
			
			if(@$v==@$service){
				$item["s"]=$v;
				$skindata["s"]=$v;
			}

			
			if($stat->IsRunning($v)==1){
				$item["running"]=1;
				$item["rtimev"]=timetostr($stat->GetProperty("ST_RunningTime"));
				$item["clientinv"]=(string)round($stat->GetProperty("ST_ClientIn")/1024,2);
				$item["clientoutv"]=(string)round($stat->GetProperty("ST_ClientOut")/1024,2);
				$item["serverinv"]=(string)round($stat->GetProperty("ST_ServerIn")/1024,2);
				$item["serveroutv"]=(string)round($stat->GetProperty("ST_ServerOut")/1024,2);
				$item["conntotalv"]=(string)$stat->GetProperty("ST_ServerConns");
				$item["sconnv"]=(string)$stat->GetProperty("ST_Server");
				$item["speakv"]=(string)$stat->GetProperty("ST_ServerPeak");
				$item["cconnv"]=(string)$stat->GetProperty("ST_Client");
				$item["cpeakv"]=(string)$stat->GetProperty("ST_ClientPeak");
				$item["servertotalv"]=(string)$stat->GetProperty("ST_ServerIn")+$stat->GetProperty("ST_ServerOut");
				$item["ctotalv"]=(string)round(($stat->GetProperty("ST_ClientIn")+$stat->GetProperty("ST_ClientOut"))/1024,2);
				$item["pwssv"]=(string)round($stat->GetProperty("ST_PeakWorkingSetSize")/(1024*1024),2);
				$item["wssv"]=(string)round($stat->GetProperty("ST_WorkingSetSize")/(1024*1024),2);
				
				if($v=='SMTP'){
					$item["messages"]=1;
					$item["recievedv"]=(string)$stat->GetProperty("ST_SMTP_MessageIn");
					$item["sentv"]=(string)$stat->GetProperty("ST_SMTP_MessageOut");
					$item["failedv"]=(string)$stat->GetProperty("ST_SMTP_MessageFailed");
					$item["spamv"]=(string)$stat->GetProperty("ST_SMTP_FailedSpam");
					$item["virusv"]=(string)$stat->GetProperty("ST_SMTP_FailedVirus");
					$item["cfilterv"]=(string)$stat->GetProperty("ST_SMTP_FailedCF");
					$item["bwfilterv"]=(string)$stat->GetProperty("ST_SMTP_FailedFilter");
					$item["efilterv"]=(string)$stat->GetProperty("ST_SMTP_FailedStaticFilter");
					$item["dnsblv"]=(string)$stat->GetProperty("ST_SMTP_FailedRBL");
					$item["tarpitv"]=(string)$stat->GetProperty("ST_SMTP_FailedTarpit");
					$item["maxsizev"]=(string)$stat->GetProperty("ST_SMTP_FailedGL");
				}

				
				if($v=='SIP'){
					$item["sip"]=1;
					$item["packets_recieved"]=(string)$stat->GetProperty("ST_SIP_PacketsIn");
					$item["packets_sent"]=(string)$stat->GetProperty("ST_SIP_PacketsOut");
					$item["rtppackets_recieved"]=(string)$stat->GetProperty("ST_SIP_RTPPacketsIn");
					$item["rtppackets_sent"]=(string)$stat->GetProperty("ST_SIP_RTPPacketsOut");
				}

			} else $item["info"]=$v.' '.$alang["TStrings_servicenotrunning"];
			$items[]=$item;
		}

		return$items;
	}

	?>