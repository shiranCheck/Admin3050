﻿<?php 
	require_once"inc/api/statistics.php";
	require_once"inc/clsparsexml.php";
	require_once"inc/formvariables.php";
	function getSessions($service,$history){
		$stat=createobject("statistics");
		$items=$stat->GetSessions($service,true);
		$parser=new ParseXML();
		$sessions=$parser->GetXMLTreeFromString($items);
		
		if($sessions["SESSIONS"][0]["ITEM"])foreach($sessions["SESSIONS"][0]["ITEM"]as$key=>$itm){
			$item["id"]=$itm["ATTRIBUTES"]["ID"];
			$item["handle"]=$itm["ATTRIBUTES"]["HANDLE"];
			$item["ip"]=$itm["ATTRIBUTES"]["IP"];
			$t=getDate($itm["ATTRIBUTES"]["TIME"]);
			$item["time"]=$t["year"]."/".$t["mon"]."/".$t["mday"]." ".$t["hours"].":".$t["minutes"].":".$t["seconds"];
			$time=mktime();
			$time=abs($time-$itm["ATTRIBUTES"]["TIME"]);
			$item["duration"]=timetostr($time);
			$item["volume"]=$itm["ATTRIBUTES"]["VOLUME"];
			$item["val"]=$itm["ATTRIBUTES"]["VAL"];
			$return[]=$item;
		}

		return$return;
	}

	?>