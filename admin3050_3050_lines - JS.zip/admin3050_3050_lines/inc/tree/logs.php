﻿<?php 
	
	function getserviceid($service){
		$aServiceID=array('smtp'=>0,'pop3'=>1,'imap'=>2,'control'=>3,'av'=>4,'im'=>5,'ima'=>6,'gw'=>7,'ftp'=>8,'as'=>9,'sip'=>10,'main'=>11,'error'=>12,'reports'=>13,'webmail'=>14,'syncml'=>15,'imp'=>16,'webdav'=>17,'none'=>18,'other'=>19,'mailqueue'=>20,'sms'=>21,'ldap'=>22,'phperror'=>23,'gwpush'=>24,'activesync'=>25,'loganalyzer'=>26,'sipcalls'=>27,'minger'=>31);
		return$aServiceID[strtolower($service)];
	}

	
	function getfilename($service,$date){
		checksession();
		global$api;
		$api=createobject("api");
		$logdir=$api->GetProperty("C_System_Storage_Dir_LogPath");
		$serverid=$api->GetProperty("C_PathServiceID");
		$date=str_replace('/','',$date);
		
		if($date=='')$date=date("Y/m/d",time());
		$whole=false;
		switch(strtolower($service)){
			case'smtp':
				$tempfile="s";
				break;
			case'av':
				$tempfile="antivirus/";
				break;
			case'as':
				$tempfile="antispam/";
				break;
			case'sreport':
				$tempfile="reports/";
				break;
			case'main':
				$tempfile="maintenance/";
				break;
			case'webmail':
				$tempfile="webmail/";
				break;
			case'sip':
				$tempfile="sip/";
				break;
			case'syncml':
				$tempfile="syncml/";
				break;
			case'syncmlpush':
				$tempfile="syncmlpush/";
				break;
			case'sms':
				$tempfile="sms/";
				break;
			case'caldav':
				$tempfile="webdav/";
				break;
			case'gw':
				$tempfile="g";
				break;
			case'control':
				$tempfile="c";
				break;
			case'ftp':
				$tempfile="f";
				break;
			case'pop3':
				$tempfile="p";
				break;
			case'im':
				$tempfile="i";
				break;
			case'imap':
				$tempfile="m";
				break;
			case'error':
				$tempfile="e";
				break;
			case'phperror':
				$tempfile='phperror';
				$whole=true;
				break;
			case'caldav':
				$tempfile="webdav/";
				break;
			case'reports':
				$tempfile="reports/";
				break;
			case'ima':
				$tempfile="im/";
				break;
			case'imp':
				$tempfile="im-presence/";
				break;
			case'ldap':
				$logdir=$_SESSION['INSTALLPATH'];
				$tempfile="ldap/var/slapd";
				$whole=true;
				break;
	}

	
	if($whole)return$logdir.$tempfile;
	return$logdir.$tempfile.$serverid.$date;
}


function getlogs($service,$date,$from,$to){
	$api=new MerakAPI();
	$skip=false;
	checksession();
	$ret='';
	$serviceID=getserviceid($service);
	$date=explode('/',$date);
	$year=$date[0];
	$month=$date[1];
	$day=$date[2];
	$unixdate=mktime(12,0,0,$month,$day,$year);
	$timef=$from.'-'.$to;
	$logs=$api->GetLogRecords($serviceID,$unixdate,$timef);
	return nl2br(htmlspecialchars($logs));
}

?>