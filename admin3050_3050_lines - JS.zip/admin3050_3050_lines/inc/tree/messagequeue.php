﻿<?php 
	require_once("inc/formvariables.php");
	require_once("inc/statistics.php");
	require_once("inc/mailbox.php");
	require_once("inc/editfile.php");
	$object=$_REQUEST['object'];
	$type=$_REQUEST['type'];
	$s_type=$_REQUEST['s_type'];
	function getmessages($object,$type,$s_type,&$skindata,$u_spamfolder=0){
		$stat=createobject("statistics");
		
		if($type=='server'){
			$object='';
			$skindata['server']=1;
			switch($s_type){
				case'serverin':
					$fileid='server_in';
					processmailboxaction($object,$fileid);
					@$items=processmailbox($object,$fileid);
					$skindata['sin']=1;
					break;
				case'serverout':
					$fileid='server_out';
					processmailboxaction($object,$fileid);
					@$itemsout=processmailbox($object,$fileid);
					$fileid='server_outretry';
					processmailboxaction($object,$fileid);
					@$itemsretry=processmailbox($object,$fileid);
					$items=array_merge($itemsretry,$itemsout);
					$skindata['sout']=1;
					break;
				case'serversms':
					$fileid='server_sms';
					processmailboxaction($object,$fileid);
					@$items=processmailbox($object,$fileid);
					$skindata['ssms']=1;
					break;
				case'servermda':
					$fileid='server_mda';
					processmailboxaction($object,$fileid);
					@$itemsmda=processmailbox($object,$fileid);
					$items=array_merge($itemsin,$itemsout,$itemsretry);
					$skindata['smda']=1;
					break;
		}

		$skindata['items']['num']=$items;
	} else {
		$skindata['mbox']=1;
		$fileid=(!$u_spamfolder)?'mailbox_view':
		'spambox_view';
		
		if(!isset($object))$object=$_SESSION["EMAIL"];
		processmailboxaction($object,$fileid);
		@$skindata['items']['num']=processmailbox($object,$fileid,$u_spamfolder);
	}

	$skindata['object']=$object;
	$skindata['fileid']=$fileid;
}

?>