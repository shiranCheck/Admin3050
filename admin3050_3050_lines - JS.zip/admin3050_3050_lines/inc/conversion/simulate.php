﻿<?php
	require_once('../inc/api/api.php');
	require_once('../inc/api/domain.php');
	require_once('../inc/api/account.php');
	require_once('../inc/api/gwapi.php');
	require_once('../inc/conversion/defines.php');
	class Simulate{
		static$aProperties=array("NAME","ORGANIZATION","NICK","EMAIL","STREETB","CITYB","ZIPB","COUNTRYB","PHONE1","PHONE4","BIRTH","SEX","NOTE","PHONE2","PHONE3","CATEGORY","NAME1","NAME2","NAME3","EMAIL2","EMAIL3","JOB","PROFESSION","DEPARTMENT","OFFICE","ASISTENT","PHONE1T","PHONE2T","PHONE3T","PHONE4T","URL","CALENDARURL","SPOUS","ANNIVERSARY","TITLE","MANAGER","STATEB","STREETH","CITYH","ZIPH","COUNTRYH","STATEH","STREETO","CITYO","ZIPO","COUNTRYO","STATEO","CERTIFICATE","PHONE1TYPE","PHONE2TYPE","PHONE3TYPE","PHONE4TYPE");
		public
		function __construct(){
			$this->oAPI=IcewarpAPI::instance();
			$this->oDomain=new MerakDomain();
			$this->oAccount=new MerakAccount();
			$sPath=$this->oAPI->getProperty("C_InstallPath");
			$this->sPath=$sPath.OLD_WM_USERPATH;
			$this->sNewPath=$sPath.NEW_WM_STORAGE;
			
			if(!is_dir($this->sPath))Tools::mkdir_r($this->sPath);
		}

		public
		function createMailStorage($iDomainCount,$iUserCount,$iMailCount){
		}

		public
		function createContactsStorage($iDomainCount,$iUserCount,$iContactCount,$iComplexicity=100){
			$this->dCount=$iDomainCount;
			$this->aCount=$iUserCount;
			$this->cCount=$iContactCount;
			$this->iComplexicity=$iComplexicity;
			$this->create();
		}

		public
		function create(){
			for($iD=0;$iD<$this->dCount;$iD++){
				$this->oDomain->New_("domain".$iD);
				$this->oDomain->Save();
				Tools::mkdir_r($this->sNewPath."domain".$iD);
				$this->createAccounts("domain".$iD);
			}

		}

		public
		function createAccounts($domain){
			for($iA=0;$iA<$this->aCount;$iA++){
				$this->oAccount->New_("account".$iA."@".$domain);
				$this->oAccount->Save();
				Tools::mkdir_r($this->sNewPath."domain".$iD."/".$account.$iA);
				$this->createContacts($domain,"account".$iA."@".$domain);
			}

		}

		public
		function createContacts($domain,$account){
			$info=explode("@",$account,2);
			$domain=$info[1];
			$alias=$info[0];
			$path=$this->sPath.$domain."/".$alias."/";
			
			if(!is_dir($path))Tools::mkdir_r($path);
			$file=fopen($path.ADDRESS_FILE,"w+");
			for($iC=0;$iC<$this->cCount;$iC++){
				$string=$iC;
				foreach(self::$aProperties as$sProperty)
				if(rand(0,100)<=$this->iComplexicity)$string.=DELIMITER_CHAR.$sProperty.$iC;
				fwrite($file,$string."\r\n");
			}

			fclose($file);
		}

	}

	?>