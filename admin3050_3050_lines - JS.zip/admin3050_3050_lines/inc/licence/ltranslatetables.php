﻿<?php 
	$TranslateTable[0][0]='MMPS';
	$TranslateTable[0][1]='MMPSP';
	$TranslateTable[0][2]='MMPPP';
	$TranslateTable[0][3]='MMPP';
	$TranslateTable[1][0]='MMT';
	$TranslateTable[2][0]='MIAV';
	$TranslateTable[3][0]='MMIM';
	$TranslateTable[4][0]='MIAS';
	$TranslateTable[5][0]='MMGW';
	$TranslateTable[7][0]='MMPW';
	$T_T=array('MMPL'=>'Merak Mail Server Lite','MMPLP'=>'Merak Mail Server Power Pack Lite','MMPP'=>'Merak Mail Server Professional','MMPPP'=>'Merak Mail Server Professional Power Pack','MMPS'=>'Merak Mail Server Standard','MMPSP'=>'Merak Mail Server Standard Power Pack','MMT'=>'Migration Tool','MIAV'=>'Antivirus','MMIM'=>'Instant Messaging','MIAS'=>'SpamEngine','MIASL'=>'Anti-Spam Live','MMGW'=>'GroupWare & Calendaring','MMPW'=>'Webmail','MENS'=>'Merak Ensim Connector','MMFTP'=>'Merak FTP Service','MMS'=>'Merak Mail Server');
	$T_T2=array('Mail Server Lite'=>'mailserver','Mail Server Professional'=>'mailserver','Mail Server Standard'=>'mailserver','Mail Server'=>'mailserver','Migration Tool'=>'mailserver','Anti-Virus'=>'antivirus','Instant Messaging'=>'instantmessaging','Anti-Spam'=>'spamengine','GroupWare'=>'calendaring','WebMail'=>'webclient','FTP'=>'ftp','SyncML'=>'syncml','SIP'=>'sip','Anti-Spam Live'=>'antispamlive','CalDAV'=>'caldav','Outlook Connector'=>'outlookconnector','Outlook-Connector'=>'outlookconnector','Log Analyzer'=>'loganalyzer','SMS'=>'sms','ActiveSync'=>'activesync','Desktop Client'=>'desktopclient');
	?>